# ClipForge — Content Production Pipeline

A self-hosted content management platform for restaurant video marketing. Editors log in, see assigned work organized by client portals, and produce video deliverables with AI-powered hook generation and voiceover synthesis.

## Quick Start

### 1. Unzip and navigate to the project
```bash
cd ~/Projects/clipforge
```

### 2. Copy environment file
```bash
cp .env.example .env
```
Edit `.env` and add your API keys (optional for first run — app works without them in demo mode).

### 3. Start everything with Docker
```bash
docker compose up --build
```

Wait for all 3 services to start. You'll see:
- `clipforge-db` — PostgreSQL database
- `clipforge-api` — Backend API on port 4000
- `clipforge-ui` — Frontend on port 3000

### 4. Open the app
Go to **http://localhost:3000** in your browser.

### 5. Login
- **Username:** `CF_Admin`
- **Password:** `admin123`

## First Steps After Login

1. **Create editors** — Go to User Management → Add User with role "Editor"
2. **Create a client portal** — Go to Clients → New Client (upload logo)
3. **Add burner accounts** — Open client → Add Account (TikTok, IG, Facebook)
4. **Register templates** — Go to Templates → New Template (add your CapCut template codes)
5. **Add hooks to library** — Go to Hook Library → New Hook (include menu items)
6. **Create monthly folder + campaign** — Inside client portal
7. **Add deliverables** — Inside campaign, add sets of 4 (select template + hook)
8. **Assign editors** — From deliverables or kanban board

## Architecture

```
clipforge/
├── docker-compose.yml      # Orchestrates all services
├── .env.example             # API keys template
├── backend/
│   ├── Dockerfile
│   ├── package.json
│   ├── uploads/             # Logos, videos, voiceovers
│   └── src/
│       ├── server.js        # Express entry point
│       ├── config/
│       │   ├── database.js  # PostgreSQL connection
│       │   └── init.sql     # Database schema + seed data
│       ├── middleware/
│       │   └── auth.js      # JWT authentication
│       ├── routes/
│       │   ├── auth.js      # Login, password management
│       │   ├── users.js     # User CRUD (admin)
│       │   ├── clients.js   # Client portals + burner accounts
│       │   ├── folders.js   # Monthly folders + campaigns
│       │   ├── templates.js # Template registry
│       │   ├── hooks.js     # Hook library
│       │   ├── deliverables.js  # Deliverables + video upload
│       │   ├── reviews.js   # Timestamped video comments
│       │   ├── ai.js        # Claude + ElevenLabs generation
│       │   ├── analytics.js # Scoring + dashboards
│       │   └── notifications.js # In-app + email
│       └── services/
│           ├── claude.js     # Hook variant generation
│           ├── elevenlabs.js # Voiceover generation
│           └── notifications.js # Email via Gmail
└── frontend/
    ├── Dockerfile
    ├── package.json
    ├── vite.config.js
    ├── index.html
    └── src/
        ├── main.jsx
        ├── App.jsx          # Main router
        ├── contexts/
        │   └── AuthContext.jsx
        ├── services/
        │   └── api.js       # API client
        ├── styles/
        │   └── global.css   # Dark theme
        ├── components/
        │   └── common/
        │       ├── Sidebar.jsx
        │       └── Topbar.jsx
        └── pages/
            ├── LoginPage.jsx
            ├── DashboardPage.jsx
            ├── ClientsPage.jsx
            ├── ClientDetailPage.jsx
            ├── UsersPage.jsx
            ├── TemplatesPage.jsx
            ├── HooksPage.jsx
            ├── KanbanPage.jsx
            ├── AnalyticsPage.jsx
            └── SettingsPage.jsx
```

## User Roles

| Role | Can See |
|------|---------|
| **Admin** | Everything + User Management + Password Resets |
| **Project Manager** | Clients, Kanban, Templates, Hooks, Analytics |
| **Lead Editor** | Clients, Templates, Hooks, Analytics, Review Queue |
| **Editor** | Assigned tasks only |

## API Keys

| Service | Purpose | Get it from |
|---------|---------|-------------|
| Claude API | Hook variant + script generation | console.anthropic.com |
| ElevenLabs | Voiceover generation | elevenlabs.io |
| Gmail App Password | Email notifications | myaccount.google.com → App Passwords |

## Deploying to Synology NAS

1. Copy the entire `clipforge` folder to your NAS (via SMB or SCP)
2. SSH into your NAS
3. Navigate to the folder and run: `docker compose up -d --build`
4. Access at `http://YOUR_NAS_IP:3000`

## Stopping the App
```bash
docker compose down
```

## Resetting the Database
```bash
docker compose down -v   # removes the database volume
docker compose up --build
```
