const express = require('express');
const cors = require('cors');
const path = require('path');
const fs = require('fs');
const { initMailer } = require('./services/notifications');

const app = express();
const PORT = process.env.PORT || 4000;

// Middleware
app.use(cors());
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// Serve uploaded files
app.use('/uploads', express.static(path.join(__dirname, '..', 'uploads')));

// Ensure upload directories exist
const uploadDirs = ['logos', 'templates', 'videos', 'voiceovers'];
uploadDirs.forEach(dir => {
  const dirPath = path.join(__dirname, '..', 'uploads', dir);
  if (!fs.existsSync(dirPath)) fs.mkdirSync(dirPath, { recursive: true });
});

// Routes
app.use('/api/auth', require('./routes/auth'));
app.use('/api/users', require('./routes/users'));
app.use('/api/clients', require('./routes/clients'));
app.use('/api/folders', require('./routes/folders'));
app.use('/api/templates', require('./routes/templates'));
app.use('/api/hooks', require('./routes/hooks'));
app.use('/api/deliverables', require('./routes/deliverables'));
app.use('/api/reviews', require('./routes/reviews'));
app.use('/api/ai', require('./routes/ai'));
app.use('/api/analytics', require('./routes/analytics'));
app.use('/api/notifications', require('./routes/notifications'));
app.use('/api/publishing', require('./routes/publishing'));

// Health check
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// Initialize services
initMailer();

app.listen(PORT, '0.0.0.0', () => {
  console.log(`
  ╔═══════════════════════════════════════╗
  ║   ClipForge API running on port ${PORT}  ║
  ║   http://localhost:${PORT}/api/health   ║
  ╚═══════════════════════════════════════╝
  `);
});
