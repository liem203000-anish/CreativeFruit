const express = require('express');
const multer = require('multer');
const path = require('path');
const db = require('../config/database');
const { authenticate, authorize } = require('../middleware/auth');

const router = express.Router();

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, 'uploads/logos'),
  filename: (req, file, cb) => cb(null, `${Date.now()}-${file.originalname}`),
});
const upload = multer({ storage, fileFilter: (req, file, cb) => {
  const allowed = ['.png', '.jpg', '.jpeg', '.svg', '.webp'];
  cb(null, allowed.includes(path.extname(file.originalname).toLowerCase()));
}});

// Get all clients
router.get('/', authenticate, async (req, res) => {
  try {
    const result = await db.query(`
      SELECT c.*,
        (SELECT COUNT(*) FROM deliverables d WHERE d.client_id = c.id) as total_deliverables,
        (SELECT COUNT(*) FROM deliverables d WHERE d.client_id = c.id AND d.status = 'posted') as completed_deliverables
      FROM clients c WHERE c.is_active = true ORDER BY c.name
    `);
    res.json({ clients: result.rows });
  } catch (err) {
    console.error('Get clients error:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// Get single client with folders
router.get('/:id', authenticate, async (req, res) => {
  try {
    const client = await db.query('SELECT * FROM clients WHERE id = $1', [req.params.id]);
    if (client.rows.length === 0) return res.status(404).json({ error: 'Client not found' });

    const folders = await db.query(
      'SELECT * FROM monthly_folders WHERE client_id = $1 ORDER BY year DESC, month DESC',
      [req.params.id]
    );

    const accounts = await db.query(
      'SELECT * FROM burner_accounts WHERE client_id = $1 AND is_active = true ORDER BY platform, account_name',
      [req.params.id]
    );

    res.json({ client: client.rows[0], folders: folders.rows, burner_accounts: accounts.rows });
  } catch (err) {
    console.error('Get client error:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// Create client (admin only)
router.post('/', authenticate, authorize('admin'), upload.single('logo'), async (req, res) => {
  try {
    const { name } = req.body;
    const logo_url = req.file ? `/uploads/logos/${req.file.filename}` : null;

    const result = await db.query(
      'INSERT INTO clients (name, logo_url) VALUES ($1, $2) RETURNING *',
      [name, logo_url]
    );
    res.status(201).json({ client: result.rows[0] });
  } catch (err) {
    console.error('Create client error:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// Update client
router.put('/:id', authenticate, authorize('admin'), upload.single('logo'), async (req, res) => {
  try {
    const { name } = req.body;
    const logo_url = req.file ? `/uploads/logos/${req.file.filename}` : undefined;

    const result = await db.query(
      `UPDATE clients SET name = COALESCE($1, name), logo_url = COALESCE($2, logo_url), updated_at = NOW()
       WHERE id = $3 RETURNING *`,
      [name, logo_url, req.params.id]
    );
    res.json({ client: result.rows[0] });
  } catch (err) {
    console.error('Update client error:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// Add burner account to client
router.post('/:id/burner-accounts', authenticate, authorize('admin', 'project_manager'), async (req, res) => {
  try {
    const { platform, account_name, account_username } = req.body;
    const result = await db.query(
      `INSERT INTO burner_accounts (client_id, platform, account_name, account_username)
       VALUES ($1, $2, $3, $4) RETURNING *`,
      [req.params.id, platform, account_name, account_username]
    );
    res.status(201).json({ account: result.rows[0] });
  } catch (err) {
    console.error('Add burner account error:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// Delete burner account
router.delete('/burner-accounts/:id', authenticate, authorize('admin', 'project_manager'), async (req, res) => {
  try {
    await db.query('UPDATE burner_accounts SET is_active = false WHERE id = $1', [req.params.id]);
    res.json({ message: 'Account removed' });
  } catch (err) {
    console.error('Delete burner account error:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// Delete client (admin only)
router.delete('/:id', authenticate, authorize('admin'), async (req, res) => {
  try {
    await db.query('DELETE FROM review_comments WHERE deliverable_id IN (SELECT id FROM deliverables WHERE client_id = $1)', [req.params.id]);
    await db.query('DELETE FROM post_analytics WHERE deliverable_id IN (SELECT id FROM deliverables WHERE client_id = $1)', [req.params.id]);
    await db.query('DELETE FROM deliverables WHERE client_id = $1', [req.params.id]);
    await db.query('DELETE FROM campaigns WHERE client_id = $1', [req.params.id]);
    await db.query('DELETE FROM monthly_folders WHERE client_id = $1', [req.params.id]);
    await db.query('DELETE FROM burner_accounts WHERE client_id = $1', [req.params.id]);
    await db.query('DELETE FROM clients WHERE id = $1', [req.params.id]);
    res.json({ message: 'Client deleted' });
  } catch (err) {
    console.error('Delete client error:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;
