const express = require('express');
const db = require('../config/database');
const { authenticate, authorize } = require('../middleware/auth');

const router = express.Router();

// Get publish config for a deliverable
router.get('/config/:deliverableId', authenticate, async (req, res) => {
  try {
    const result = await db.query('SELECT * FROM publish_configs WHERE deliverable_id = $1', [req.params.deliverableId]);
    res.json({ config: result.rows[0] || null });
  } catch (err) {
    console.error('Get publish config error:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// Save publish config
router.post('/config/:deliverableId', authenticate, authorize('admin', 'project_manager', 'social_media_manager'), async (req, res) => {
  try {
    const { shared_caption, custom_captions, platforms, collab_accounts } = req.body;
    const result = await db.query(
      `INSERT INTO publish_configs (deliverable_id, shared_caption, custom_captions, platforms, collab_accounts, updated_by)
       VALUES ($1, $2, $3, $4, $5, $6)
       ON CONFLICT (deliverable_id) DO UPDATE SET
         shared_caption = $2, custom_captions = $3, platforms = $4, collab_accounts = $5, updated_by = $6, updated_at = NOW()
       RETURNING *`,
      [req.params.deliverableId, shared_caption, custom_captions, JSON.stringify(platforms), JSON.stringify(collab_accounts), req.user.id]
    );
    res.json({ config: result.rows[0] });
  } catch (err) {
    console.error('Save publish config error:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// Publish to a platform (placeholder - will connect to real APIs later)
router.post('/publish/:deliverableId', authenticate, authorize('admin', 'project_manager', 'social_media_manager'), async (req, res) => {
  try {
    const { platform, caption, account_id, collab_accounts } = req.body;

    // Log the publish attempt
    const result = await db.query(
      `INSERT INTO publish_log (deliverable_id, platform, account_id, caption, collab_accounts, status, published_by)
       VALUES ($1, $2, $3, $4, $5, 'pending', $6)
       RETURNING *`,
      [req.params.deliverableId, platform, account_id, caption, JSON.stringify(collab_accounts || []), req.user.id]
    );

    // TODO: Connect to actual platform APIs here
    // For now, mark as scheduled
    await db.query("UPDATE deliverables SET status = 'scheduled', platform = $1, updated_at = NOW() WHERE id = $2",
      [platform.split('_')[0], req.params.deliverableId]);

    res.json({ publish: result.rows[0], message: 'Scheduled for publishing (API integration pending)' });
  } catch (err) {
    console.error('Publish error:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// Get publish history for a deliverable
router.get('/history/:deliverableId', authenticate, async (req, res) => {
  try {
    const result = await db.query(
      `SELECT pl.*, u.full_name as published_by_name FROM publish_log pl
       LEFT JOIN users u ON u.id = pl.published_by
       WHERE pl.deliverable_id = $1 ORDER BY pl.created_at DESC`,
      [req.params.deliverableId]
    );
    res.json({ history: result.rows });
  } catch (err) {
    console.error('Get publish history error:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;
