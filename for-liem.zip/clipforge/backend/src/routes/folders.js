const express = require('express');
const db = require('../config/database');
const { authenticate, authorize } = require('../middleware/auth');

const router = express.Router();

// Create monthly folder
router.post('/monthly', authenticate, authorize('admin', 'project_manager'), async (req, res) => {
  try {
    const { client_id, name, month, year } = req.body;
    const result = await db.query(
      `INSERT INTO monthly_folders (client_id, name, month, year, created_by)
       VALUES ($1, $2, $3, $4, $5) RETURNING *`,
      [client_id, name, month, year, req.user.id]
    );
    res.status(201).json({ folder: result.rows[0] });
  } catch (err) {
    if (err.code === '23505') return res.status(400).json({ error: 'Monthly folder already exists for this period' });
    console.error('Create folder error:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// Get campaigns in monthly folder
router.get('/monthly/:id/campaigns', authenticate, async (req, res) => {
  try {
    const campaigns = await db.query(
      `SELECT c.*,
        (SELECT COUNT(*) FROM deliverables d WHERE d.campaign_id = c.id) as total_deliverables,
        (SELECT COUNT(*) FROM deliverables d WHERE d.campaign_id = c.id AND d.status = 'posted') as completed_deliverables
       FROM campaigns c WHERE c.monthly_folder_id = $1 ORDER BY c.created_at`,
      [req.params.id]
    );
    res.json({ campaigns: campaigns.rows });
  } catch (err) {
    console.error('Get campaigns error:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// Create campaign
router.post('/campaigns', authenticate, authorize('admin', 'project_manager'), async (req, res) => {
  try {
    const { monthly_folder_id, client_id, name, description, start_date, end_date, metadata } = req.body;
    const result = await db.query(
      `INSERT INTO campaigns (monthly_folder_id, client_id, name, description, start_date, end_date, metadata, created_by)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8) RETURNING *`,
      [monthly_folder_id, client_id, name, description, start_date, end_date, metadata || {}, req.user.id]
    );
    res.status(201).json({ campaign: result.rows[0] });
  } catch (err) {
    console.error('Create campaign error:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// Update campaign
router.put('/campaigns/:id', authenticate, authorize('admin', 'project_manager'), async (req, res) => {
  try {
    const { name, description, start_date, end_date, metadata } = req.body;
    const result = await db.query(
      `UPDATE campaigns SET name = COALESCE($1, name), description = COALESCE($2, description),
       start_date = COALESCE($3, start_date), end_date = COALESCE($4, end_date),
       metadata = COALESCE($5, metadata), updated_at = NOW()
       WHERE id = $6 RETURNING *`,
      [name, description, start_date, end_date, metadata, req.params.id]
    );
    res.json({ campaign: result.rows[0] });
  } catch (err) {
    console.error('Update campaign error:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// Delete campaign
router.delete('/campaigns/:id', authenticate, authorize('admin', 'project_manager'), async (req, res) => {
  try {
    const campId = req.params.id;
    // Get all deliverable IDs in this campaign
    const dels = await db.query('SELECT id FROM deliverables WHERE campaign_id = $1', [campId]);
    const ids = dels.rows.map(r => r.id);

    if (ids.length > 0) {
      await db.query('DELETE FROM review_comments WHERE deliverable_id = ANY($1)', [ids]);
      await db.query('DELETE FROM post_analytics WHERE deliverable_id = ANY($1)', [ids]);
      await db.query('DELETE FROM publish_configs WHERE deliverable_id = ANY($1)', [ids]);
      await db.query('DELETE FROM publish_log WHERE deliverable_id = ANY($1)', [ids]);
      await db.query('DELETE FROM deliverables WHERE campaign_id = $1', [campId]);
    }
    await db.query('DELETE FROM deliverable_sets WHERE campaign_id = $1', [campId]);
    await db.query('DELETE FROM campaigns WHERE id = $1', [campId]);
    res.json({ message: 'Campaign deleted' });
  } catch (err) {
    console.error('Delete campaign error:', err);
    res.status(500).json({ error: 'Server error' });
  }
});


router.delete('/monthly/:id', authenticate, authorize('admin', 'project_manager'), async (req, res) => {
  try {
    await db.query('DELETE FROM review_comments WHERE deliverable_id IN (SELECT id FROM deliverables WHERE campaign_id IN (SELECT id FROM campaigns WHERE monthly_folder_id = $1))', [req.params.id]);
    await db.query('DELETE FROM post_analytics WHERE deliverable_id IN (SELECT id FROM deliverables WHERE campaign_id IN (SELECT id FROM campaigns WHERE monthly_folder_id = $1))', [req.params.id]);
    await db.query('DELETE FROM deliverables WHERE campaign_id IN (SELECT id FROM campaigns WHERE monthly_folder_id = $1)', [req.params.id]);
    await db.query('DELETE FROM campaigns WHERE monthly_folder_id = $1', [req.params.id]);
    await db.query('DELETE FROM monthly_folders WHERE id = $1', [req.params.id]);
    res.json({ message: 'Folder deleted' });
  } catch (err) { console.error(err); res.status(500).json({ error: 'Server error' }); }
});

module.exports = router;
