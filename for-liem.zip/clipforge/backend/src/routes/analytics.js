const express = require('express');
const db = require('../config/database');
const { authenticate, authorize } = require('../middleware/auth');

const router = express.Router();

// Get template scorecard (all templates with scores)
router.get('/templates', authenticate, async (req, res) => {
  try {
    const result = await db.query(`
      SELECT t.id, t.code, t.name, t.photo_reference_url, t.times_used,
        COALESCE(AVG(pa.engagement_rate), 0) as avg_engagement,
        COALESCE(AVG(pa.three_second_retention), 0) as avg_3s_retention,
        COALESCE(AVG(pa.fifty_percent_dropoff_seconds), 0) as avg_50_dropoff,
        COALESCE(AVG(pa.avg_watch_time_seconds), 0) as avg_watch_time,
        COALESCE(AVG(pa.views), 0) as avg_views,
        COUNT(DISTINCT pa.id) as data_points,
        -- Calculate score: weighted combination
        COALESCE(
          (AVG(pa.three_second_retention) * 50) +
          (AVG(pa.engagement_rate) * 100 * 30) +
          (LEAST(AVG(pa.avg_watch_time_seconds) / 30.0, 1) * 20),
          0
        ) as score
      FROM templates t
      LEFT JOIN deliverables d ON d.template_id = t.id
      LEFT JOIN post_analytics pa ON pa.deliverable_id = d.id
      WHERE t.is_active = true
      GROUP BY t.id, t.code, t.name, t.photo_reference_url, t.times_used
      ORDER BY score DESC
    `);

    // Update scores in templates table
    for (const row of result.rows) {
      await db.query('UPDATE templates SET score = $1 WHERE id = $2', [row.score, row.id]);
    }

    res.json({ templates: result.rows });
  } catch (err) {
    console.error('Get template analytics error:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// Get variant comparison for a specific template
router.get('/templates/:id/variants', authenticate, async (req, res) => {
  try {
    const result = await db.query(`
      SELECT d.variant_number,
        COUNT(pa.id) as data_points,
        COALESCE(AVG(pa.views), 0) as avg_views,
        COALESCE(AVG(pa.likes), 0) as avg_likes,
        COALESCE(AVG(pa.shares), 0) as avg_shares,
        COALESCE(AVG(pa.comments), 0) as avg_comments,
        COALESCE(AVG(pa.engagement_rate), 0) as avg_engagement,
        COALESCE(AVG(pa.three_second_retention), 0) as avg_3s_retention,
        COALESCE(AVG(pa.fifty_percent_dropoff_seconds), 0) as avg_50_dropoff,
        COALESCE(AVG(pa.avg_watch_time_seconds), 0) as avg_watch_time
      FROM deliverables d
      LEFT JOIN post_analytics pa ON pa.deliverable_id = d.id
      WHERE d.template_id = $1
      GROUP BY d.variant_number
      ORDER BY d.variant_number
    `, [req.params.id]);

    res.json({ variants: result.rows });
  } catch (err) {
    console.error('Get variant analytics error:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// Get hook library scores
router.get('/hooks', authenticate, async (req, res) => {
  try {
    const result = await db.query(`
      SELECT h.id, h.name, h.hook_text, h.menu_items, h.times_used,
        COALESCE(AVG(pa.engagement_rate), 0) as avg_engagement,
        COALESCE(AVG(pa.three_second_retention), 0) as avg_3s_retention,
        COALESCE(AVG(pa.fifty_percent_dropoff_seconds), 0) as avg_50_dropoff,
        COALESCE(AVG(pa.avg_watch_time_seconds), 0) as avg_watch_time,
        COALESCE(AVG(pa.views), 0) as avg_views,
        COUNT(DISTINCT pa.id) as data_points,
        COALESCE(
          (AVG(pa.three_second_retention) * 50) +
          (AVG(pa.engagement_rate) * 100 * 30) +
          (LEAST(AVG(pa.avg_watch_time_seconds) / 30.0, 1) * 20),
          0
        ) as score
      FROM hooks h
      LEFT JOIN deliverables d ON d.hook_id = h.id
      LEFT JOIN post_analytics pa ON pa.deliverable_id = d.id
      WHERE h.is_active = true
      GROUP BY h.id, h.name, h.hook_text, h.menu_items, h.times_used
      ORDER BY score DESC
    `);

    // Update scores
    for (const row of result.rows) {
      await db.query('UPDATE hooks SET score = $1 WHERE id = $2', [row.score, row.id]);
    }

    res.json({ hooks: result.rows });
  } catch (err) {
    console.error('Get hook analytics error:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// Get account-level analytics
router.get('/accounts', authenticate, authorize('admin', 'project_manager', 'lead_editor'), async (req, res) => {
  try {
    const result = await db.query(`
      SELECT ba.id, ba.account_name, ba.account_username, ba.platform,
        cl.name as client_name,
        COUNT(DISTINCT d.id) as total_posts,
        COALESCE(AVG(pa.views), 0) as avg_views,
        COALESCE(AVG(pa.engagement_rate), 0) as avg_engagement,
        COALESCE(AVG(pa.three_second_retention), 0) as avg_3s_retention,
        COALESCE(SUM(pa.views), 0) as total_views,
        COALESCE(SUM(pa.likes), 0) as total_likes,
        COALESCE(SUM(pa.shares), 0) as total_shares
      FROM burner_accounts ba
      LEFT JOIN clients cl ON cl.id = ba.client_id
      LEFT JOIN deliverables d ON d.burner_account_id = ba.id AND d.status = 'posted'
      LEFT JOIN post_analytics pa ON pa.deliverable_id = d.id
      WHERE ba.is_active = true
      GROUP BY ba.id, ba.account_name, ba.account_username, ba.platform, cl.name
      ORDER BY avg_engagement DESC
    `);
    res.json({ accounts: result.rows });
  } catch (err) {
    console.error('Get account analytics error:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// Get template performance by platform
router.get('/platform', authenticate, async (req, res) => {
  try {
    const result = await db.query(
      "SELECT t.code as template_code, t.name as template_name, d.platform, " +
      "COUNT(DISTINCT pa.id) as post_count, " +
      "COALESCE(AVG(pa.views), 0) as avg_views, " +
      "COALESCE(AVG(pa.engagement_rate), 0) as avg_engagement, " +
      "COALESCE(AVG(pa.three_second_retention), 0) as avg_3s_retention, " +
      "COALESCE(AVG(pa.avg_watch_time_seconds), 0) as avg_watch_time, " +
      "COALESCE((AVG(pa.three_second_retention) * 50) + (AVG(pa.engagement_rate) * 100 * 30) + (LEAST(AVG(pa.avg_watch_time_seconds) / 30.0, 1) * 20), 0) as score " +
      "FROM templates t JOIN deliverables d ON d.template_id = t.id " +
      "JOIN post_analytics pa ON pa.deliverable_id = d.id " +
      "WHERE t.is_active = true AND d.platform IS NOT NULL " +
      "GROUP BY t.code, t.name, d.platform ORDER BY score DESC"
    );
    res.json({ data: result.rows });
  } catch (err) { console.error(err); res.status(500).json({ error: 'Server error' }); }
});

// Get overview stats for dashboard
router.get('/overview', authenticate, async (req, res) => {
  try {
    const stats = {};

    const clients = await db.query('SELECT COUNT(*) FROM clients WHERE is_active = true');
    stats.total_clients = parseInt(clients.rows[0].count);

    const deliverables = await db.query('SELECT status, COUNT(*) FROM deliverables GROUP BY status');
    stats.deliverables_by_status = {};
    deliverables.rows.forEach(r => { stats.deliverables_by_status[r.status] = parseInt(r.count); });

    const totalDel = await db.query('SELECT COUNT(*) FROM deliverables');
    stats.total_deliverables = parseInt(totalDel.rows[0].count);

    const posted = await db.query("SELECT COUNT(*) FROM deliverables WHERE status = 'posted'");
    stats.posted_deliverables = parseInt(posted.rows[0].count);

    const editors = await db.query("SELECT COUNT(*) FROM users WHERE role = 'editor' AND is_active = true");
    stats.active_editors = parseInt(editors.rows[0].count);

    const templates = await db.query('SELECT COUNT(*) FROM templates WHERE is_active = true');
    stats.total_templates = parseInt(templates.rows[0].count);

    const hooks = await db.query('SELECT COUNT(*) FROM hooks WHERE is_active = true');
    stats.total_hooks = parseInt(hooks.rows[0].count);

    const topTemplate = await db.query('SELECT code, name, score FROM templates WHERE is_active = true ORDER BY score DESC LIMIT 1');
    stats.top_template = topTemplate.rows[0] || null;

    const topHook = await db.query('SELECT name, score FROM hooks WHERE is_active = true ORDER BY score DESC LIMIT 1');
    stats.top_hook = topHook.rows[0] || null;

    res.json({ stats });
  } catch (err) {
    console.error('Get overview error:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;
