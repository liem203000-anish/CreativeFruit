const express = require('express');
const db = require('../config/database');
const { authenticate, authorize } = require('../middleware/auth');
const { generateHookVariants } = require('../services/claude');
const { getVoices, generateVoiceover } = require('../services/elevenlabs');

const router = express.Router();

router.post('/generate-hooks', authenticate, authorize('admin', 'project_manager', 'lead_editor'), async (req, res) => {
  try {
    const { deliverable_set_id, hook_id, template_id } = req.body;
    const hook = await db.query('SELECT * FROM hooks WHERE id = $1', [hook_id]);
    if (hook.rows.length === 0) return res.status(404).json({ error: 'Hook not found' });
    const template = await db.query('SELECT * FROM templates WHERE id = $1', [template_id]);

    const result = await generateHookVariants(hook.rows[0].hook_text, hook.rows[0].menu_items || [], template.rows[0]?.name || '');
    const voiceoverBody = result.voiceover_body || '';

    for (const variant of result.variants) {
      const fullVO = `${variant.voiceover_hook} ${voiceoverBody}`.trim();
      const mainText = variant.main_text || variant.hook_text;
      const subText = variant.sub_text || '';
      await db.query(
        `UPDATE deliverables SET hook_variant_text=$1, sub_text=$2, main_script=$3, voiceover_script=$4, voiceover_hook=$5, voiceover_body=$6, updated_at=NOW()
         WHERE deliverable_set_id=$7 AND variant_number=$8`,
        [mainText, subText, result.main_script, fullVO, variant.voiceover_hook, voiceoverBody, deliverable_set_id, variant.variant]
      );
    }

    const parentFullVO = `${result.parent_voiceover_hook || hook.rows[0].hook_text} ${voiceoverBody}`.trim();
    const parentMainText = result.parent_main_text || hook.rows[0].hook_text;
    const parentSubText = result.parent_sub_text || '';
    await db.query(
      `UPDATE deliverables SET hook_variant_text=$1, sub_text=$2, main_script=$3, voiceover_script=$4, voiceover_hook=$5, voiceover_body=$6, updated_at=NOW()
       WHERE deliverable_set_id=$7 AND variant_number=0`,
      [parentMainText, parentSubText, result.main_script, parentFullVO, result.parent_voiceover_hook || hook.rows[0].hook_text, voiceoverBody, deliverable_set_id]
    );

    await db.query('UPDATE deliverable_sets SET main_script=$1 WHERE id=$2', [result.main_script, deliverable_set_id]);
    res.json({ variants: result.variants, main_script: result.main_script, voiceover_body: voiceoverBody });
  } catch (err) {
    console.error('Generate hooks error:', err);
    res.status(500).json({ error: 'Failed to generate hook variants' });
  }
});

router.post('/regenerate-variant', authenticate, authorize('admin', 'project_manager', 'lead_editor'), async (req, res) => {
  try {
    const { deliverable_id } = req.body;
    const deliverable = await db.query(`SELECT d.*, h.hook_text, h.menu_items, t.name as template_name FROM deliverables d LEFT JOIN hooks h ON h.id=d.hook_id LEFT JOIN templates t ON t.id=d.template_id WHERE d.id=$1`, [deliverable_id]);
    if (deliverable.rows.length === 0) return res.status(404).json({ error: 'Deliverable not found' });
    const d = deliverable.rows[0];
    const result = await generateHookVariants(d.hook_text, d.menu_items || [], d.template_name);
    const vi = d.variant_number - 1;
    if (vi < 0 || vi >= result.variants.length) return res.status(400).json({ error: 'Cannot regenerate parent' });
    const nv = result.variants[vi];
    const body = d.voiceover_body || result.voiceover_body || '';
    const fullVO = `${nv.voiceover_hook} ${body}`.trim();
    const mainText = nv.main_text || nv.hook_text;
    const subText = nv.sub_text || '';
    await db.query(`UPDATE deliverables SET hook_variant_text=$1, sub_text=$2, voiceover_script=$3, voiceover_hook=$4, updated_at=NOW() WHERE id=$5`, [mainText, subText, fullVO, nv.voiceover_hook, deliverable_id]);
    res.json({ variant: nv });
  } catch (err) {
    console.error('Regenerate error:', err);
    res.status(500).json({ error: 'Failed to regenerate' });
  }
});

router.get('/voices', authenticate, async (req, res) => {
  try {
    const voices = await getVoices();
    for (const v of voices) {
      await db.query(`INSERT INTO voices (elevenlabs_voice_id,name,preview_url,category,labels) VALUES($1,$2,$3,$4,$5) ON CONFLICT(elevenlabs_voice_id) DO UPDATE SET name=$2,preview_url=$3,category=$4,labels=$5,cached_at=NOW()`, [v.voice_id, v.name, v.preview_url, v.category, v.labels]);
    }
    res.json({ voices });
  } catch (err) { res.status(500).json({ error: 'Failed to fetch voices' }); }
});

router.post('/generate-voiceover', authenticate, authorize('admin', 'project_manager', 'lead_editor'), async (req, res) => {
  try {
    const { deliverable_id, voice_id, mode } = req.body;
    const deliverable = await db.query(`SELECT d.*, t.has_voiceover FROM deliverables d LEFT JOIN templates t ON t.id=d.template_id WHERE d.id=$1`, [deliverable_id]);
    if (deliverable.rows.length === 0) return res.status(404).json({ error: 'Not found' });
    if (!deliverable.rows[0].has_voiceover) return res.status(400).json({ error: 'No voiceover needed' });

    const d = deliverable.rows[0];
    const effectiveMode = mode || 'auto';

    if (d.variant_number === 0 || effectiveMode === 'hook') {
      const hookText = (d.voiceover_hook || d.hook_variant_text || '').trim();
      if (!hookText) return res.status(400).json({ error: 'No hook text' });
      const hookAudioUrl = await generateVoiceover(hookText, voice_id);
      await db.query('UPDATE deliverables SET voiceover_url=$1, voice_id=$2, updated_at=NOW() WHERE id=$3', [hookAudioUrl, voice_id, deliverable_id]);
      if (d.variant_number === 0 && effectiveMode === 'auto' && d.voiceover_body) {
        const bodyText = d.voiceover_body.trim();
        if (bodyText) {
          const bodyAudioUrl = await generateVoiceover(bodyText, voice_id);
          await db.query('UPDATE deliverables SET voiceover_body_url=$1, updated_at=NOW() WHERE id=$2', [bodyAudioUrl, deliverable_id]);
        }
      }
      res.json({ voiceover_url: hookAudioUrl });
    } else if (effectiveMode === 'body') {
      const bodyText = (d.voiceover_body || '').trim();
      if (!bodyText) return res.status(400).json({ error: 'No body text' });
      const bodyAudioUrl = await generateVoiceover(bodyText, voice_id);
      await db.query('UPDATE deliverables SET voiceover_body_url=$1, voice_id=$2, updated_at=NOW() WHERE id=$3', [bodyAudioUrl, voice_id, deliverable_id]);
      res.json({ voiceover_body_url: bodyAudioUrl });
    } else {
      const hookText = (d.voiceover_hook || d.hook_variant_text || '').trim();
      if (!hookText) return res.status(400).json({ error: 'No hook text' });
      const hookAudioUrl = await generateVoiceover(hookText, voice_id);
      await db.query('UPDATE deliverables SET voiceover_url=$1, voice_id=$2, updated_at=NOW() WHERE id=$3', [hookAudioUrl, voice_id, deliverable_id]);
      res.json({ voiceover_url: hookAudioUrl });
    }
  } catch (err) {
    console.error('Voiceover error:', err);
    res.status(500).json({ error: 'Failed to generate voiceover' });
  }
});

router.post('/clear-voiceover', authenticate, authorize('admin', 'project_manager', 'lead_editor'), async (req, res) => {
  try {
    const { deliverable_id, clear_body } = req.body;
    if (clear_body) {
      await db.query('UPDATE deliverables SET voiceover_body_url=NULL, updated_at=NOW() WHERE id=$1', [deliverable_id]);
    } else {
      await db.query('UPDATE deliverables SET voiceover_url=NULL, updated_at=NOW() WHERE id=$1', [deliverable_id]);
    }
    res.json({ message: 'Cleared' });
  } catch (err) { res.status(500).json({ error: 'Server error' }); }
});

module.exports = router;
