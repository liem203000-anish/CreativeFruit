const express = require('express');
const db = require('../config/database');
const { authenticate } = require('../middleware/auth');

const router = express.Router();

// Get comments for a deliverable
router.get('/deliverable/:deliverableId', authenticate, async (req, res) => {
  try {
    const result = await db.query(`
      SELECT rc.*, u.full_name as author_name, u.username as author_username, u.role as author_role
      FROM review_comments rc
      JOIN users u ON u.id = rc.user_id
      WHERE rc.deliverable_id = $1
      ORDER BY rc.timestamp_seconds ASC, rc.created_at ASC
    `, [req.params.deliverableId]);
    res.json({ comments: result.rows });
  } catch (err) {
    console.error('Get comments error:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// Add comment
router.post('/', authenticate, async (req, res) => {
  try {
    const { deliverable_id, timestamp_seconds, comment_text } = req.body;
    const result = await db.query(
      `INSERT INTO review_comments (deliverable_id, user_id, timestamp_seconds, comment_text)
       VALUES ($1, $2, $3, $4) RETURNING *`,
      [deliverable_id, req.user.id, timestamp_seconds, comment_text]
    );

    // Notify the editor
    const deliverable = await db.query('SELECT assigned_editor_id FROM deliverables WHERE id = $1', [deliverable_id]);
    if (deliverable.rows[0]?.assigned_editor_id && deliverable.rows[0].assigned_editor_id !== req.user.id) {
      await db.query(
        `INSERT INTO notifications (user_id, type, title, message, reference_id, reference_type)
         VALUES ($1, 'comment_added', 'New review comment', $2, $3, 'deliverable')`,
        [deliverable.rows[0].assigned_editor_id, `Comment at ${timestamp_seconds}s: "${comment_text.substring(0, 50)}"`, deliverable_id]
      );
    }

    res.status(201).json({ comment: result.rows[0] });
  } catch (err) {
    console.error('Add comment error:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// Resolve comment
router.put('/:id/resolve', authenticate, async (req, res) => {
  try {
    const result = await db.query(
      'UPDATE review_comments SET is_resolved = true, updated_at = NOW() WHERE id = $1 RETURNING *',
      [req.params.id]
    );
    res.json({ comment: result.rows[0] });
  } catch (err) {
    console.error('Resolve comment error:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// Delete comment
router.delete('/:id', authenticate, async (req, res) => {
  try {
    await db.query('DELETE FROM review_comments WHERE id = $1 AND user_id = $2', [req.params.id, req.user.id]);
    res.json({ message: 'Comment deleted' });
  } catch (err) {
    console.error('Delete comment error:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;
