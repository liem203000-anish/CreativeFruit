const express = require('express');
const multer = require('multer');
const path = require('path');
const db = require('../config/database');
const { authenticate, authorize } = require('../middleware/auth');

const router = express.Router();

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, 'uploads/templates'),
  filename: (req, file, cb) => cb(null, `${Date.now()}-${file.originalname}`),
});
const upload = multer({ storage });

// Get all templates
router.get('/', authenticate, async (req, res) => {
  try {
    const result = await db.query(
      `SELECT t.*,
        (SELECT COUNT(*) FROM deliverables d WHERE d.template_id = t.id) as usage_count,
        (SELECT AVG(pa.engagement_rate) FROM post_analytics pa
         JOIN deliverables d ON d.id = pa.deliverable_id WHERE d.template_id = t.id) as avg_engagement
       FROM templates t WHERE t.is_active = true ORDER BY t.code`
    );
    res.json({ templates: result.rows });
  } catch (err) {
    console.error('Get templates error:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// Get single template with performance data
router.get('/:id', authenticate, async (req, res) => {
  try {
    const template = await db.query('SELECT * FROM templates WHERE id = $1', [req.params.id]);
    if (template.rows.length === 0) return res.status(404).json({ error: 'Template not found' });

    const analytics = await db.query(`
      SELECT d.variant_number,
        AVG(pa.views) as avg_views,
        AVG(pa.engagement_rate) as avg_engagement,
        AVG(pa.three_second_retention) as avg_3s_retention,
        AVG(pa.fifty_percent_dropoff_seconds) as avg_50_dropoff,
        AVG(pa.avg_watch_time_seconds) as avg_watch_time,
        COUNT(pa.id) as data_points
      FROM deliverables d
      JOIN post_analytics pa ON pa.deliverable_id = d.id
      WHERE d.template_id = $1
      GROUP BY d.variant_number
      ORDER BY d.variant_number
    `, [req.params.id]);

    res.json({ template: template.rows[0], variant_analytics: analytics.rows });
  } catch (err) {
    console.error('Get template error:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// Create template (admin, PM, lead)
router.post('/', authenticate, authorize('admin', 'project_manager', 'lead_editor'), upload.fields([{ name: 'photo_reference', maxCount: 1 }, { name: 'font_file', maxCount: 1 }]), async (req, res) => {
  try {
    const { code, name, description, ideal_use_case, font_name, font_style, text_position, has_voiceover } = req.body;
    const photoFile = req.files?.photo_reference?.[0];
    const fontFileUp = req.files?.font_file?.[0];
    const photo_reference_url = photoFile ? `/uploads/templates/${photoFile.filename}` : null;
    const font_file_url = fontFileUp ? `/uploads/templates/${fontFileUp.filename}` : null;
    const font_file_name = fontFileUp ? fontFileUp.originalname : null;

    const result = await db.query(
      `INSERT INTO templates (code, name, description, ideal_use_case, font_name, font_style, text_position, has_voiceover, photo_reference_url, font_file_url, font_file_name, created_by)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12) RETURNING *`,
      [code, name, description, ideal_use_case, font_name, font_style, text_position, has_voiceover === 'true', photo_reference_url, font_file_url, font_file_name, req.user.id]
    );
    res.status(201).json({ template: result.rows[0] });
  } catch (err) {
    if (err.code === '23505') return res.status(400).json({ error: 'Template code already exists' });
    console.error('Create template error:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// Update template
router.put('/:id', authenticate, authorize('admin', 'project_manager', 'lead_editor'), upload.fields([{ name: 'photo_reference', maxCount: 1 }, { name: 'font_file', maxCount: 1 }]), async (req, res) => {
  try {
    const { code, name, description, ideal_use_case, font_name, font_style, text_position, has_voiceover } = req.body;
    const photoFile = req.files?.photo_reference?.[0];
    const fontFileUp = req.files?.font_file?.[0];
    const photo_reference_url = photoFile ? `/uploads/templates/${photoFile.filename}` : undefined;
    const font_file_url = fontFileUp ? `/uploads/templates/${fontFileUp.filename}` : undefined;
    const font_file_name = fontFileUp ? fontFileUp.originalname : undefined;

    const result = await db.query(
      `UPDATE templates SET
        code = COALESCE($1, code), name = COALESCE($2, name), description = COALESCE($3, description),
        ideal_use_case = COALESCE($4, ideal_use_case), font_name = COALESCE($5, font_name),
        font_style = COALESCE($6, font_style), text_position = COALESCE($7, text_position),
        has_voiceover = COALESCE($8, has_voiceover), photo_reference_url = COALESCE($9, photo_reference_url),
        updated_at = NOW()
       WHERE id = $10 RETURNING *`,
      [code, name, description, ideal_use_case, font_name, font_style, text_position,
       has_voiceover !== undefined ? has_voiceover === 'true' : undefined,
       photo_reference_url, req.params.id]
    );
    res.json({ template: result.rows[0] });
  } catch (err) {
    console.error('Update template error:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// Delete template
router.delete('/:id', authenticate, authorize('admin'), async (req, res) => {
  try {
    await db.query('DELETE FROM templates WHERE id = $1', [req.params.id]);
    res.json({ message: 'Template archived' });
  } catch (err) {
    console.error('Delete template error:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;
