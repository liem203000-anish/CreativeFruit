const express = require('express');
const multer = require('multer');
const path = require('path');
const db = require('../config/database');
const { authenticate, authorize } = require('../middleware/auth');

const router = express.Router();

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, 'uploads/videos'),
  filename: (req, file, cb) => cb(null, `${Date.now()}-${file.originalname}`),
});
const upload = multer({ storage, limits: { fileSize: 500 * 1024 * 1024 } }); // 500MB limit

// Get deliverables for a campaign
router.get('/campaign/:campaignId', authenticate, async (req, res) => {
  try {
    let query = `
      SELECT d.*, t.code as template_code, t.name as template_name, t.has_voiceover, t.photo_reference_url, t.font_name, t.text_position,
        h.name as hook_name, h.hook_text as parent_hook_text,
        u.full_name as editor_name, u.username as editor_username,
        ba.account_name as burner_account_name, ba.platform as burner_platform
      FROM deliverables d
      LEFT JOIN templates t ON t.id = d.template_id
      LEFT JOIN hooks h ON h.id = d.hook_id
      LEFT JOIN users u ON u.id = d.assigned_editor_id
      LEFT JOIN burner_accounts ba ON ba.id = d.burner_account_id
      WHERE d.campaign_id = $1
      ORDER BY d.deliverable_set_id, d.variant_number
    `;
    const result = await db.query(query, [req.params.campaignId]);
    res.json({ deliverables: result.rows });
  } catch (err) {
    console.error('Get deliverables error:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// Get deliverables assigned to current editor
router.get('/my-tasks', authenticate, async (req, res) => {
  try {
    const result = await db.query(`
      SELECT d.*, t.code as template_code, t.name as template_name, t.has_voiceover, t.photo_reference_url, t.font_name, t.text_position,
        h.name as hook_name, h.hook_text as parent_hook_text,
        c.name as campaign_name, cl.name as client_name, cl.logo_url as client_logo,
        ba.account_name as burner_account_name, ba.platform as burner_platform
      FROM deliverables d
      LEFT JOIN templates t ON t.id = d.template_id
      LEFT JOIN hooks h ON h.id = d.hook_id
      LEFT JOIN campaigns c ON c.id = d.campaign_id
      LEFT JOIN clients cl ON cl.id = d.client_id
      LEFT JOIN burner_accounts ba ON ba.id = d.burner_account_id
      WHERE d.assigned_editor_id = $1
      ORDER BY
        CASE d.status
          WHEN 'revision' THEN 1
          WHEN 'in_progress' THEN 2
          WHEN 'get_started' THEN 3
          WHEN 'review' THEN 4
          WHEN 'approved' THEN 5
          WHEN 'scheduled' THEN 6
          WHEN 'posted' THEN 7
        END,
        d.updated_at DESC
    `, [req.user.id]);
    res.json({ deliverables: result.rows });
  } catch (err) {
    console.error('Get my tasks error:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// Get tasks for a specific user (admin/PM view)
router.get('/user-tasks/:userId', authenticate, authorize('admin', 'project_manager'), async (req, res) => {
  try {
    const result = await db.query(`
      SELECT d.*, t.code as template_code, t.name as template_name, t.has_voiceover, t.photo_reference_url, t.font_name, t.text_position,
        h.name as hook_name, h.hook_text as parent_hook_text,
        c.name as campaign_name, cl.name as client_name, cl.logo_url as client_logo,
        ba.account_name as burner_account_name, ba.platform as burner_platform
      FROM deliverables d
      LEFT JOIN templates t ON t.id = d.template_id
      LEFT JOIN hooks h ON h.id = d.hook_id
      LEFT JOIN campaigns c ON c.id = d.campaign_id
      LEFT JOIN clients cl ON cl.id = d.client_id
      LEFT JOIN burner_accounts ba ON ba.id = d.burner_account_id
      WHERE d.assigned_editor_id = $1
      ORDER BY
        CASE d.status
          WHEN 'revision' THEN 1
          WHEN 'in_progress' THEN 2
          WHEN 'get_started' THEN 3
          WHEN 'review' THEN 4
          WHEN 'approved' THEN 5
          WHEN 'scheduled' THEN 6
          WHEN 'posted' THEN 7
        END,
        d.updated_at DESC
    `, [req.params.userId]);
    res.json({ deliverables: result.rows });
  } catch (err) {
    console.error('Get user tasks error:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// Create a set of 4 deliverables
router.post('/create-set', authenticate, authorize('admin', 'project_manager', 'lead_editor'), async (req, res) => {
  try {
    const { campaign_id, client_id, template_id, hook_id, assigned_editor_id } = req.body;

    // Create the set
    const setResult = await db.query(
      `INSERT INTO deliverable_sets (campaign_id, template_id, hook_id, created_by)
       VALUES ($1, $2, $3, $4) RETURNING *`,
      [campaign_id, template_id, hook_id, req.user.id]
    );
    const setId = setResult.rows[0].id;

    // Create 4 variant deliverables
    const deliverables = [];
    for (let i = 0; i <= 4; i++) {
      const result = await db.query(
        `INSERT INTO deliverables (campaign_id, client_id, template_id, hook_id, variant_number, deliverable_set_id, assigned_editor_id, created_by)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8) RETURNING *`,
        [campaign_id, client_id, template_id, hook_id, i, setId, assigned_editor_id || null, req.user.id]
      );
      deliverables.push(result.rows[0]);
    }

    // Send notification if editor was assigned
    if (assigned_editor_id) {
      await db.query(
        `INSERT INTO notifications (user_id, type, title, message, reference_id, reference_type)
         VALUES ($1, 'task_assigned', 'New set assigned', 'You have been assigned a new deliverable set (5 deliverables)', $2, 'deliverable')`,
        [assigned_editor_id, deliverables[0].id]
      );
    }

    // Update template usage count
    await db.query('UPDATE templates SET times_used = times_used + 1 WHERE id = $1', [template_id]);
    if (hook_id) {
      await db.query('UPDATE hooks SET times_used = times_used + 1 WHERE id = $1', [hook_id]);
    }

    res.status(201).json({ set: setResult.rows[0], deliverables });
  } catch (err) {
    console.error('Create deliverable set error:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// Update deliverable (assign editor, change status, etc.)
router.put('/:id', authenticate, async (req, res) => {
  try {
    const { assigned_editor_id, burner_account_id, status, platform, voice_id,
            hook_variant_text, main_script, scheduled_at } = req.body;

    const result = await db.query(
      `UPDATE deliverables SET
        assigned_editor_id = COALESCE($1, assigned_editor_id),
        burner_account_id = COALESCE($2, burner_account_id),
        status = COALESCE($3, status),
        platform = COALESCE($4, platform),
        voice_id = COALESCE($5, voice_id),
        hook_variant_text = COALESCE($6, hook_variant_text),
        main_script = COALESCE($7, main_script),
        scheduled_at = COALESCE($8, scheduled_at),
        posted_at = CASE WHEN $3 = 'posted' THEN NOW() ELSE posted_at END,
        updated_at = NOW()
       WHERE id = $9 RETURNING *`,
      [assigned_editor_id, burner_account_id, status, platform, voice_id,
       hook_variant_text, main_script, scheduled_at, req.params.id]
    );

    // Send notification if editor was assigned
    if (assigned_editor_id) {
      await db.query(
        `INSERT INTO notifications (user_id, type, title, message, reference_id, reference_type)
         VALUES ($1, 'task_assigned', 'New task assigned', 'You have been assigned a new deliverable', $2, 'deliverable')`,
        [assigned_editor_id, req.params.id]
      );
    }

    // Send notification if status changed to revision
    if (status === 'revision') {
      const deliverable = result.rows[0];
      if (deliverable.assigned_editor_id) {
        await db.query(
          `INSERT INTO notifications (user_id, type, title, message, reference_id, reference_type)
           VALUES ($1, 'revision_requested', 'Revision requested', 'A deliverable needs revision', $2, 'deliverable')`,
          [deliverable.assigned_editor_id, req.params.id]
        );
      }
    }

    res.json({ deliverable: result.rows[0] });
  } catch (err) {
    console.error('Update deliverable error:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// Upload video for deliverable
router.post('/:id/upload-video', authenticate, upload.single('video'), async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ error: 'No video file provided' });

    const video_url = `/uploads/videos/${req.file.filename}`;
    const result = await db.query(
      `UPDATE deliverables SET video_url = $1, video_filename = $2, status = 'review', updated_at = NOW()
       WHERE id = $3 RETURNING *`,
      [video_url, req.file.originalname, req.params.id]
    );

    // Notify lead editors about new video for review
    const leads = await db.query("SELECT id FROM users WHERE role IN ('lead_editor', 'project_manager') AND is_active = true");
    for (const lead of leads.rows) {
      await db.query(
        `INSERT INTO notifications (user_id, type, title, message, reference_id, reference_type)
         VALUES ($1, 'video_uploaded', 'Video ready for review', 'An editor has uploaded a video for review', $2, 'deliverable')`,
        [lead.id, req.params.id]
      );
    }

    res.json({ deliverable: result.rows[0] });
  } catch (err) {
    console.error('Upload video error:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// Get all deliverables for kanban (PM view)
router.get('/kanban/:clientId', authenticate, authorize('admin', 'project_manager', 'lead_editor'), async (req, res) => {
  try {
    const result = await db.query(`
      SELECT d.*, t.code as template_code, t.name as template_name,
        u.full_name as editor_name, u.username as editor_username,
        c.name as campaign_name
      FROM deliverables d
      LEFT JOIN templates t ON t.id = d.template_id
      LEFT JOIN users u ON u.id = d.assigned_editor_id
      LEFT JOIN campaigns c ON c.id = d.campaign_id
      WHERE d.client_id = $1
      ORDER BY d.updated_at DESC
    `, [req.params.clientId]);
    res.json({ deliverables: result.rows });
  } catch (err) {
    console.error('Get kanban error:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// Delete entire deliverable set (all variants + the set record)
// NOTE: This route MUST be before /:id or Express will match "set" as an id
router.delete('/set/:setId', authenticate, authorize('admin', 'project_manager'), async (req, res) => {
  try {
    // Get all deliverable IDs in this set
    const dels = await db.query('SELECT id FROM deliverables WHERE deliverable_set_id = $1', [req.params.setId]);
    const ids = dels.rows.map(r => r.id);

    if (ids.length > 0) {
      // Clean up child tables
      await db.query('DELETE FROM review_comments WHERE deliverable_id = ANY($1)', [ids]);
      await db.query('DELETE FROM post_analytics WHERE deliverable_id = ANY($1)', [ids]);
      await db.query('DELETE FROM publish_configs WHERE deliverable_id = ANY($1)', [ids]);
      await db.query('DELETE FROM publish_log WHERE deliverable_id = ANY($1)', [ids]);
      // Delete all deliverables in the set
      await db.query('DELETE FROM deliverables WHERE deliverable_set_id = $1', [req.params.setId]);
    }

    // Delete the set itself
    await db.query('DELETE FROM deliverable_sets WHERE id = $1', [req.params.setId]);

    res.json({ message: 'Deliverable set deleted', deleted_count: ids.length });
  } catch (err) {
    console.error('Delete deliverable set error:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// Delete single deliverable
router.delete('/:id', authenticate, authorize('admin', 'project_manager'), async (req, res) => {
  try {
    await db.query('DELETE FROM review_comments WHERE deliverable_id = $1', [req.params.id]);
    await db.query('DELETE FROM post_analytics WHERE deliverable_id = $1', [req.params.id]);
    await db.query('DELETE FROM publish_configs WHERE deliverable_id = $1', [req.params.id]);
    await db.query('DELETE FROM publish_log WHERE deliverable_id = $1', [req.params.id]);
    await db.query('DELETE FROM deliverables WHERE id = $1', [req.params.id]);
    res.json({ message: 'Deliverable deleted' });
  } catch (err) {
    console.error('Delete deliverable error:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;
