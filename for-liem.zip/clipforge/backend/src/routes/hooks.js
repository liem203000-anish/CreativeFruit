const express = require('express');
const db = require('../config/database');
const { authenticate, authorize } = require('../middleware/auth');

const router = express.Router();

// Get all hooks with scores
router.get('/', authenticate, async (req, res) => {
  try {
    const result = await db.query(`
      SELECT h.*,
        (SELECT COUNT(*) FROM deliverables d WHERE d.hook_id = h.id) as usage_count,
        (SELECT AVG(pa.engagement_rate) FROM post_analytics pa
         JOIN deliverables d ON d.id = pa.deliverable_id WHERE d.hook_id = h.id) as avg_engagement,
        (SELECT AVG(pa.three_second_retention) FROM post_analytics pa
         JOIN deliverables d ON d.id = pa.deliverable_id WHERE d.hook_id = h.id) as avg_3s_retention
      FROM hooks h WHERE h.is_active = true ORDER BY h.score DESC
    `);
    res.json({ hooks: result.rows });
  } catch (err) {
    console.error('Get hooks error:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// Get single hook with detailed analytics
router.get('/:id', authenticate, async (req, res) => {
  try {
    const hook = await db.query('SELECT * FROM hooks WHERE id = $1', [req.params.id]);
    if (hook.rows.length === 0) return res.status(404).json({ error: 'Hook not found' });

    const variants = await db.query(`
      SELECT d.variant_number, d.hook_variant_text,
        AVG(pa.views) as avg_views,
        AVG(pa.engagement_rate) as avg_engagement,
        AVG(pa.three_second_retention) as avg_3s_retention,
        AVG(pa.fifty_percent_dropoff_seconds) as avg_50_dropoff,
        COUNT(pa.id) as data_points
      FROM deliverables d
      LEFT JOIN post_analytics pa ON pa.deliverable_id = d.id
      WHERE d.hook_id = $1
      GROUP BY d.variant_number, d.hook_variant_text
      ORDER BY d.variant_number
    `, [req.params.id]);

    res.json({ hook: hook.rows[0], variant_performance: variants.rows });
  } catch (err) {
    console.error('Get hook error:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// Create hook (lead editor)
router.post('/', authenticate, authorize('admin', 'lead_editor'), async (req, res) => {
  try {
    const { name, hook_text, menu_items } = req.body;
    const result = await db.query(
      `INSERT INTO hooks (name, hook_text, menu_items, created_by)
       VALUES ($1, $2, $3, $4) RETURNING *`,
      [name, hook_text, menu_items || [], req.user.id]
    );
    res.status(201).json({ hook: result.rows[0] });
  } catch (err) {
    console.error('Create hook error:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// Update hook
router.put('/:id', authenticate, authorize('admin', 'lead_editor'), async (req, res) => {
  try {
    const { name, hook_text, menu_items } = req.body;
    const result = await db.query(
      `UPDATE hooks SET name = COALESCE($1, name), hook_text = COALESCE($2, hook_text),
       menu_items = COALESCE($3, menu_items), updated_at = NOW()
       WHERE id = $4 RETURNING *`,
      [name, hook_text, menu_items, req.params.id]
    );
    res.json({ hook: result.rows[0] });
  } catch (err) {
    console.error('Update hook error:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// Delete hook
router.delete('/:id', authenticate, authorize('admin', 'lead_editor'), async (req, res) => {
  try {
    await db.query('UPDATE hooks SET is_active = false, updated_at = NOW() WHERE id = $1', [req.params.id]);
    res.json({ message: 'Hook archived' });
  } catch (err) {
    console.error('Delete hook error:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;
