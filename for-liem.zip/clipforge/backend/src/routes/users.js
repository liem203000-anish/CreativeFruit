const express = require('express');
const bcrypt = require('bcryptjs');
const db = require('../config/database');
const { authenticate, authorize } = require('../middleware/auth');

const router = express.Router();

// Get all users (admin, PM)
router.get('/', authenticate, authorize('admin', 'project_manager'), async (req, res) => {
  try {
    const result = await db.query(
      'SELECT id, username, email, full_name, role, is_active, created_at FROM users ORDER BY created_at DESC'
    );
    res.json({ users: result.rows });
  } catch (err) {
    console.error('Get users error:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// Create user (admin only)
router.post('/', authenticate, authorize('admin'), async (req, res) => {
  try {
    const { username, email, password, full_name, role } = req.body;

    if (!['admin', 'project_manager', 'lead_editor', 'editor', 'social_media_manager'].includes(role)) {
      return res.status(400).json({ error: 'Invalid role' });
    }

    const hash = await bcrypt.hash(password, 10);
    const result = await db.query(
      `INSERT INTO users (username, email, password_hash, full_name, role)
       VALUES ($1, $2, $3, $4, $5)
       RETURNING id, username, email, full_name, role, is_active, created_at`,
      [username, email, hash, full_name, role]
    );

    res.status(201).json({ user: result.rows[0] });
  } catch (err) {
    if (err.code === '23505') {
      return res.status(400).json({ error: 'Username or email already exists' });
    }
    console.error('Create user error:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// Reset password (admin, PM)
router.put('/:id/reset-password', authenticate, authorize('admin', 'project_manager'), async (req, res) => {
  try {
    const { new_password } = req.body;
    const hash = await bcrypt.hash(new_password, 10);
    await db.query('UPDATE users SET password_hash = $1, updated_at = NOW() WHERE id = $2', [hash, req.params.id]);
    res.json({ message: 'Password reset successfully' });
  } catch (err) {
    console.error('Reset password error:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// Update user (admin, PM)
router.put('/:id', authenticate, authorize('admin', 'project_manager'), async (req, res) => {
  try {
    const { email, full_name, role, is_active } = req.body;
    const result = await db.query(
      `UPDATE users SET email = COALESCE($1, email), full_name = COALESCE($2, full_name),
       role = COALESCE($3, role), is_active = COALESCE($4, is_active), updated_at = NOW()
       WHERE id = $5
       RETURNING id, username, email, full_name, role, is_active`,
      [email, full_name, role, is_active, req.params.id]
    );
    res.json({ user: result.rows[0] });
  } catch (err) {
    console.error('Update user error:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// Deactivate user (admin, PM)
router.delete('/:id', authenticate, authorize('admin', 'project_manager'), async (req, res) => {
  try {
    await db.query('UPDATE users SET is_active = false, updated_at = NOW() WHERE id = $1', [req.params.id]);
    res.json({ message: 'User deactivated' });
  } catch (err) {
    console.error('Delete user error:', err);
    res.status(500).json({ error: 'Server error' });
  }
});


router.delete('/:id/permanent', authenticate, authorize('admin', 'project_manager'), async (req, res) => {
  try {
    await db.query('UPDATE deliverables SET assigned_editor_id = NULL WHERE assigned_editor_id = $1', [req.params.id]);
    await db.query('DELETE FROM notifications WHERE user_id = $1', [req.params.id]);
    await db.query('DELETE FROM review_comments WHERE user_id = $1', [req.params.id]);
    await db.query('DELETE FROM users WHERE id = $1', [req.params.id]);
    res.json({ message: 'User permanently deleted' });
  } catch (err) { console.error(err); res.status(500).json({ error: 'Server error' }); }
});

module.exports = router;
