const fs = require('fs');
const path = require('path');

// Get available voices from ElevenLabs account
const getVoices = async () => {
  const apiKey = process.env.ELEVENLABS_API_KEY;
  if (!apiKey || apiKey === 'your_elevenlabs_api_key_here') {
    return [
      { voice_id: 'demo_1', name: 'Demo Voice 1 (Configure API key)', category: 'demo' },
      { voice_id: 'demo_2', name: 'Demo Voice 2 (Configure API key)', category: 'demo' },
    ];
  }

  try {
    const response = await fetch('https://api.elevenlabs.io/v1/voices', {
      headers: { 'xi-api-key': apiKey },
    });
    const data = await response.json();
    return data.voices.map(v => ({
      voice_id: v.voice_id,
      name: v.name,
      preview_url: v.preview_url,
      category: v.category,
      labels: v.labels || {},
    }));
  } catch (err) {
    console.error('ElevenLabs get voices error:', err);
    throw new Error('Failed to fetch voices');
  }
};

// Generate voiceover audio
const generateVoiceover = async (text, voiceId) => {
  const apiKey = process.env.ELEVENLABS_API_KEY;
  if (!apiKey || apiKey === 'your_elevenlabs_api_key_here') {
    return null; // Return null in demo mode
  }

  try {
    const response = await fetch(`https://api.elevenlabs.io/v1/text-to-speech/${voiceId}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'xi-api-key': apiKey,
      },
      body: JSON.stringify({
        text,
        model_id: 'eleven_monolingual_v1',
        voice_settings: {
          stability: 0.5,
          similarity_boost: 0.75,
        },
      }),
    });

    if (!response.ok) {
      throw new Error(`ElevenLabs API error: ${response.status}`);
    }

    const buffer = Buffer.from(await response.arrayBuffer());
    const filename = `voiceover-${Date.now()}.mp3`;
    const filepath = path.join('uploads', 'voiceovers', filename);

    // Ensure directory exists
    fs.mkdirSync(path.join('uploads', 'voiceovers'), { recursive: true });
    fs.writeFileSync(filepath, buffer);

    return `/uploads/voiceovers/${filename}`;
  } catch (err) {
    console.error('ElevenLabs TTS error:', err);
    throw new Error('Failed to generate voiceover');
  }
};

module.exports = { getVoices, generateVoiceover };
