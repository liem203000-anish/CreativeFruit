const generateHookVariants = async (parentHookText, menuItems = [], templateName = '') => {
  const apiKey = process.env.CLAUDE_API_KEY;

  if (!apiKey || apiKey === 'your_key_here') {
    console.log('Claude API key not configured, returning demo variants');
    return {
      parent_main_text: parentHookText,
      parent_sub_text: 'The one that started it all',
      parent_voiceover_hook: 'Let me tell you about something that will blow your mind.',
      variants: [
        { variant: 1, main_text: 'THIS CHANGES EVERYTHING', sub_text: 'You have to see it to believe it', voiceover_hook: 'You will not believe what happens when you try this.' },
        { variant: 2, main_text: 'NOBODY EXPECTED THIS', sub_text: 'But here we are', voiceover_hook: 'Stop scrolling, you need to see this right now.' },
        { variant: 3, main_text: 'WAIT FOR IT...', sub_text: 'You are not ready', voiceover_hook: 'This is something you have to try for yourself.' },
        { variant: 4, main_text: 'THEY SAID IT COULDN\'T BE DONE', sub_text: 'Watch what happens next', voiceover_hook: 'I could not believe this until I tried it myself.' },
      ],
      voiceover_body: 'What you are looking at is one of the most incredible things you will ever taste. Every bite is packed with flavor, and once you try it, you will keep coming back for more.',
      main_script: 'Film close-up shots of the food, show the textures and ingredients, cut to reaction shots. Use good lighting and vibrant colors.',
    };
  }

  var menuItemsText = '';
  if (menuItems.length > 0) {
    menuItemsText = '\nThe restaurant featured menu items to highlight: ' + menuItems.join(', ');
  }

  var prompt = 'You are a social media content strategist for restaurant marketing. Generate hook text for short-form video content (TikTok, Reels).\n\n';
  prompt += 'The video template has TWO text lines on screen:\n';
  prompt += '- LINE 1 ("main_text"): The BIG BOLD headline text. Short, punchy, attention-grabbing. Under 6 words.\n';
  prompt += '- LINE 2 ("sub_text"): A smaller supporting line underneath. Adds context or intrigue. Under 8 words.\n\n';
  prompt += 'Think of it like a title + subtitle on screen. Example:\n';
  prompt += '  main_text: "YOU CAN CREATE"\n';
  prompt += '  sub_text: "YOUR OWN PHONE CASE"\n\n';
  prompt += 'ORIGINAL HOOK CONCEPT: "' + parentHookText + '"\n';
  prompt += 'TEMPLATE STYLE: ' + (templateName || 'General') + '\n';
  prompt += menuItemsText + '\n\n';
  prompt += 'Generate the PARENT version and 4 VARIANT versions. Each must express the same core concept but with COMPLETELY DIFFERENT wording.\n\n';
  prompt += 'For each version generate:\n';
  prompt += '1. "main_text" - Line 1: Big bold headline (under 6 words)\n';
  prompt += '2. "sub_text" - Line 2: Supporting subtitle (under 8 words)\n';
  prompt += '3. "voiceover_hook" - What the narrator SAYS out loud (conversational, different from the on-screen text)\n\n';
  prompt += 'Also generate:\n';
  prompt += '- "voiceover_body" - Shared body narration after the hook (2-3 sentences, describes the food/experience)\n';
  prompt += '- "main_script" - Director\'s notes for the editor (what to film, camera angles, mood)\n\n';
  prompt += 'CRITICAL RULES:\n';
  prompt += '- Every version (parent + 4 variants) must have UNIQUE main_text. No two should be the same or near-identical.\n';
  prompt += '- Every version must have UNIQUE sub_text.\n';
  prompt += '- main_text and voiceover_hook must be DIFFERENT from each other.\n';
  prompt += '- voiceover_hook should sound natural when spoken aloud.\n';
  if (menuItems.length > 0) {
    prompt += '- Work the menu items into the sub_text where it fits naturally.\n';
  }
  prompt += '\nRespond ONLY with valid JSON, no markdown, no backticks:\n';
  prompt += '{"parent_main_text":"parent line 1","parent_sub_text":"parent line 2","parent_voiceover_hook":"parent spoken opener","variants":[{"variant":1,"main_text":"v1 line 1","sub_text":"v1 line 2","voiceover_hook":"v1 spoken"},{"variant":2,"main_text":"v2 line 1","sub_text":"v2 line 2","voiceover_hook":"v2 spoken"},{"variant":3,"main_text":"v3 line 1","sub_text":"v3 line 2","voiceover_hook":"v3 spoken"},{"variant":4,"main_text":"v4 line 1","sub_text":"v4 line 2","voiceover_hook":"v4 spoken"}],"voiceover_body":"shared body narration","main_script":"editor guide"}';

  try {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 2000,
        messages: [{ role: 'user', content: prompt }],
      }),
    });

    const data = await response.json();
    const text = data.content[0].text;
    const cleaned = text.replace(/```json|```/g, '').trim();
    return JSON.parse(cleaned);
  } catch (err) {
    console.error('Claude API error:', err);
    throw new Error('Failed to generate hook variants');
  }
};

module.exports = { generateHookVariants };
