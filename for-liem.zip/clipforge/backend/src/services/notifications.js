const nodemailer = require('nodemailer');
const db = require('../config/database');

let transporter = null;

const initMailer = () => {
  const user = process.env.GMAIL_USER;
  const pass = process.env.GMAIL_APP_PASSWORD;

  if (user && pass && user !== 'your_email@gmail.com') {
    transporter = nodemailer.createTransport({
      service: 'gmail',
      auth: { user, pass },
    });
    console.log('Email notifications enabled via Gmail');
  } else {
    console.log('Email notifications disabled (configure GMAIL_USER and GMAIL_APP_PASSWORD)');
  }
};

const sendNotification = async (userId, type, title, message, referenceId, referenceType) => {
  try {
    // Save in-app notification
    await db.query(
      `INSERT INTO notifications (user_id, type, title, message, reference_id, reference_type)
       VALUES ($1, $2, $3, $4, $5, $6)`,
      [userId, type, title, message, referenceId, referenceType]
    );

    // Send email if configured
    if (transporter) {
      const user = await db.query('SELECT email, full_name FROM users WHERE id = $1', [userId]);
      if (user.rows[0]?.email) {
        await transporter.sendMail({
          from: `"ClipForge" <${process.env.GMAIL_USER}>`,
          to: user.rows[0].email,
          subject: `[ClipForge] ${title}`,
          html: `
            <div style="font-family: -apple-system, sans-serif; max-width: 500px;">
              <h2 style="color: #1a1a1a;">${title}</h2>
              <p style="color: #555;">${message}</p>
              <hr style="border: none; border-top: 1px solid #eee; margin: 20px 0;">
              <p style="color: #999; font-size: 12px;">ClipForge Notification</p>
            </div>
          `,
        });
        await db.query('UPDATE notifications SET email_sent = true WHERE user_id = $1 AND reference_id = $2 AND type = $3 ORDER BY created_at DESC LIMIT 1',
          [userId, referenceId, type]);
      }
    }
  } catch (err) {
    console.error('Notification error:', err);
  }
};

module.exports = { initMailer, sendNotification };
