import { useState, useEffect, useRef } from 'react';
import { useAuth } from '../contexts/AuthContext';
import api from '../services/api';
import { ChevronLeft, List, Kanban, FileVideo, Package } from 'lucide-react';

const STATUSES = [
  { key: 'get_started', label: 'Get Started' },
  { key: 'in_progress', label: 'In Progress' },
  { key: 'review', label: 'Review' },
  { key: 'revision', label: 'Revision' },
  { key: 'approved', label: 'Approved' },
  { key: 'scheduled', label: 'Scheduled' },
  { key: 'posted', label: 'Posted' },
];

const useHorizontalScroll = () => {
  const ref = useRef(null);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const onWheel = (e) => {
      if (Math.abs(e.deltaX) > Math.abs(e.deltaY)) return;
      if (el.scrollWidth <= el.clientWidth) return;
      e.preventDefault();
      el.scrollLeft += e.deltaY;
    };
    el.addEventListener('wheel', onWheel, { passive: false });
    return () => el.removeEventListener('wheel', onWheel);
  }, []);
  return ref;
};

const TeamMemberTasksPage = ({ member, onBack }) => {
  const { hasRole } = useAuth();
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [viewMode, setViewMode] = useState('list');
  const kanbanRef = useHorizontalScroll();

  useEffect(() => { if (member?.id) loadTasks(); }, [member?.id]);

  const loadTasks = async () => {
    setLoading(true);
    try {
      const data = await api.getUserTasks(member.id);
      setTasks(data.deliverables || []);
    } catch (err) { console.error(err); }
    setLoading(false);
  };

  const handleStatusChange = async (id, status) => {
    try {
      await api.updateDeliverable(id, { status });
      loadTasks();
    } catch (err) { alert(err.message); }
  };

  const activeCount = tasks.filter(t => ['get_started', 'in_progress', 'revision'].includes(t.status)).length;
  const reviewCount = tasks.filter(t => t.status === 'review').length;
  const doneCount = tasks.filter(t => ['approved', 'scheduled', 'posted'].includes(t.status)).length;

  if (loading) return <div className="page-content"><p style={{ color: 'var(--text-tertiary)' }}>Loading...</p></div>;

  return (
    <div className="page-content">
      <button className="btn btn-secondary btn-sm" onClick={onBack} style={{ marginBottom: 16 }}>
        <ChevronLeft size={14} /> Back to Team
      </button>

      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 20 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <div className="user-avatar" style={{ width: 40, height: 40, fontSize: 16 }}>{member.full_name?.[0] || member.username[0]}</div>
          <div>
            <h2 style={{ fontSize: 20, fontWeight: 600 }}>{member.full_name || member.username}</h2>
            <p style={{ fontSize: 12, color: 'var(--text-tertiary)', textTransform: 'capitalize' }}>{member.role?.replace('_', ' ')}</p>
          </div>
        </div>
        <div style={{ display: 'flex', gap: 2, background: 'var(--bg-tertiary)', borderRadius: 'var(--radius-sm)', padding: 3 }}>
          <button className={`tab ${viewMode === 'list' ? 'active' : ''}`} onClick={() => setViewMode('list')}><List size={14} /> List</button>
          <button className={`tab ${viewMode === 'kanban' ? 'active' : ''}`} onClick={() => setViewMode('kanban')}><Kanban size={14} /> Kanban</button>
        </div>
      </div>

      <div className="stat-grid" style={{ marginBottom: 20 }}>
        <div className="stat-card"><div className="stat-label">Total Tasks</div><div className="stat-value">{tasks.length}</div></div>
        <div className="stat-card"><div className="stat-label">Active</div><div className="stat-value" style={{ color: 'var(--warning)' }}>{activeCount}</div></div>
        <div className="stat-card"><div className="stat-label">In Review</div><div className="stat-value" style={{ color: 'var(--accent-primary)' }}>{reviewCount}</div></div>
        <div className="stat-card"><div className="stat-label">Done</div><div className="stat-value" style={{ color: 'var(--success)' }}>{doneCount}</div></div>
      </div>

      {tasks.length === 0 ? (
        <div className="empty-state">
          <FileVideo size={48} />
          <h3>No tasks assigned</h3>
          <p>This team member has no deliverables assigned yet</p>
        </div>
      ) : viewMode === 'list' ? (
        <div className="card" style={{ padding: 0 }}>
          <table className="data-table">
            <thead>
              <tr>
                <th>Deliverable</th>
                <th>Client</th>
                <th>Campaign</th>
                <th>Template</th>
                <th>Hook Text</th>
                <th>Status</th>
                <th>Video</th>
              </tr>
            </thead>
            <tbody>
              {tasks.map(t => (
                <tr key={t.id}>
                  <td>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                      <Package size={14} style={{ color: 'var(--accent-primary)', flexShrink: 0 }} />
                      <span style={{ fontWeight: 500 }}>
                        {t.variant_number === 0 ? 'Parent' : `Variant ${t.variant_number}`}
                      </span>
                    </div>
                  </td>
                  <td>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                      {t.client_logo
                        ? <img src={t.client_logo} style={{ width: 20, height: 20, borderRadius: 4, objectFit: 'cover' }} />
                        : <div style={{ width: 20, height: 20, borderRadius: 4, background: 'var(--accent-glow)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 9, fontWeight: 700, color: 'var(--accent-primary)' }}>{t.client_name?.[0]}</div>}
                      <span style={{ fontSize: 12 }}>{t.client_name}</span>
                    </div>
                  </td>
                  <td><span style={{ fontSize: 12 }}>{t.campaign_name}</span></td>
                  <td>
                    {t.template_code && (
                      <span style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--accent-primary)' }}>{t.template_code}</span>
                    )}
                  </td>
                  <td>
                    <span style={{ fontSize: 11, color: 'var(--text-secondary)', maxWidth: 200, display: 'block', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                      {t.hook_variant_text || '—'}
                    </span>
                  </td>
                  <td>
                    {hasRole('admin', 'project_manager') ? (
                      <select className="form-select" value={t.status} onChange={e => handleStatusChange(t.id, e.target.value)}
                        style={{ fontSize: 11, padding: '3px 6px', width: 120 }}>
                        {STATUSES.map(s => <option key={s.key} value={s.key}>{s.label}</option>)}
                      </select>
                    ) : (
                      <span className={`status-badge status-${t.status}`}>{t.status.replace('_', ' ')}</span>
                    )}
                  </td>
                  <td>
                    {t.video_url
                      ? <span style={{ fontSize: 11, color: 'var(--success)' }}>Uploaded</span>
                      : <span style={{ fontSize: 11, color: 'var(--text-muted)' }}>—</span>}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        /* Kanban view */
        <div className="kanban-board" ref={kanbanRef}>
          {STATUSES.map(status => {
            const columnTasks = tasks.filter(t => t.status === status.key);
            return (
              <div key={status.key} className="kanban-column">
                <div className="kanban-column-header">
                  {status.label}
                  <span className="kanban-column-count">{columnTasks.length}</span>
                </div>
                <div className="kanban-cards">
                  {columnTasks.map(t => (
                    <div key={t.id} className="kanban-card">
                      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 6 }}>
                        <span style={{ fontSize: 11, fontWeight: 600, color: t.variant_number === 0 ? 'var(--warning)' : 'var(--accent-primary)' }}>
                          {t.variant_number === 0 ? 'Parent' : `V${t.variant_number}`}
                        </span>
                        {t.template_code && (
                          <span style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--accent-primary)' }}>{t.template_code}</span>
                        )}
                      </div>
                      <div style={{ fontSize: 12, fontWeight: 500, marginBottom: 4 }}>{t.client_name}</div>
                      <div style={{ fontSize: 11, color: 'var(--text-tertiary)', marginBottom: 4 }}>{t.campaign_name}</div>
                      {t.hook_variant_text && (
                        <p style={{ fontSize: 11, color: 'var(--text-secondary)', lineHeight: 1.4, marginBottom: 6,
                          overflow: 'hidden', textOverflow: 'ellipsis', display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical' }}>
                          "{t.hook_variant_text}"
                        </p>
                      )}
                      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', fontSize: 10, color: 'var(--text-muted)' }}>
                        {t.video_url ? <span style={{ color: 'var(--success)' }}>Video uploaded</span> : <span>No video</span>}
                        {t.burner_account_name && <span>{t.burner_platform}</span>}
                      </div>
                      {hasRole('admin', 'project_manager') && (
                        <select className="form-select" value={t.status} onChange={e => handleStatusChange(t.id, e.target.value)}
                          style={{ fontSize: 10, padding: '3px 6px', marginTop: 8 }}>
                          {STATUSES.map(s => <option key={s.key} value={s.key}>{s.label}</option>)}
                        </select>
                      )}
                    </div>
                  ))}
                  {columnTasks.length === 0 && (
                    <div style={{ padding: 12, textAlign: 'center', fontSize: 11, color: 'var(--text-muted)' }}>Empty</div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

export default TeamMemberTasksPage;
