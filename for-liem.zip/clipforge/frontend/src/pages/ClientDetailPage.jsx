import { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import api from '../services/api';
import { Plus, ChevronLeft, FolderOpen, ChevronDown, ChevronRight, Package, Trash2, Edit2, Upload } from 'lucide-react';

const MONTHS = ['January','February','March','April','May','June','July','August','September','October','November','December'];

const ClientDetailPage = ({ client, onBack, onOpenCampaign }) => {
  const { hasRole } = useAuth();
  const [detail, setDetail] = useState(null);
  const [expandedFolder, setExpandedFolder] = useState(null);
  const [campaigns, setCampaigns] = useState({});
  const [showCreateFolder, setShowCreateFolder] = useState(false);
  const [showCreateCampaign, setShowCreateCampaign] = useState(null);
  const [showAddAccount, setShowAddAccount] = useState(false);
  const [newFolder, setNewFolder] = useState({ month: new Date().getMonth() + 1, year: new Date().getFullYear() });
  const [newCampaign, setNewCampaign] = useState({ name: '', description: '' });
  const [newAccount, setNewAccount] = useState({ platform: 'tiktok', account_name: '', account_username: '' });
  const [editingClient, setEditingClient] = useState(false);
  const [editClientName, setEditClientName] = useState('');
  const [editClientLogo, setEditClientLogo] = useState(null);
  const [editingCampaign, setEditingCampaign] = useState(null);
  const [editCampaignName, setEditCampaignName] = useState('');
  const [editCampaignDesc, setEditCampaignDesc] = useState('');

  useEffect(() => { loadClient(); }, [client.id]);

  const loadClient = async () => {
    try {
      const data = await api.getClient(client.id);
      setDetail(data);
      // Auto-expand first folder
      if (data.folders?.length > 0) {
        const firstId = data.folders[0].id;
        setExpandedFolder(firstId);
        loadCampaigns(firstId);
      }
    } catch (err) { console.error(err); }
  };

  const loadCampaigns = async (folderId) => {
    try {
      const data = await api.getCampaigns(folderId);
      setCampaigns(prev => ({ ...prev, [folderId]: data.campaigns }));
    } catch (err) { console.error(err); }
  };

  const handleEditClient = async (e) => {
    e.preventDefault();
    try {
      const formData = new FormData();
      formData.append('name', editClientName);
      if (editClientLogo) formData.append('logo', editClientLogo);
      await api.updateClient(client.id, formData);
      setEditingClient(false); setEditClientLogo(null); loadClient();
    } catch (err) { alert(err.message); }
  };

  const handleEditCampaign = async (e) => {
    e.preventDefault();
    try {
      await api.updateCampaign(editingCampaign.id, { name: editCampaignName, description: editCampaignDesc });
      setEditingCampaign(null);
      Object.keys(campaigns).forEach(fid => loadCampaigns(fid));
    } catch (err) { alert(err.message); }
  };

  const handleDeleteFolder = async (folderId) => {
    if (!confirm('Delete this folder and all its campaigns? This cannot be undone.')) return;
    try { await api.deleteMonthlyFolder(folderId); loadClient(); } catch (err) { alert(err.message); }
  };

  const handleDeleteCampaign = async (campaignId, folderId) => {
    if (!confirm('Delete this campaign and all its deliverables? This cannot be undone.')) return;
    try { await api.deleteCampaign(campaignId); loadCampaigns(folderId); } catch (err) { alert(err.message); }
  };

  const toggleFolder = (folderId) => {
    if (expandedFolder === folderId) {
      setExpandedFolder(null);
    } else {
      setExpandedFolder(folderId);
      if (!campaigns[folderId]) loadCampaigns(folderId);
    }
  };

  const handleCreateFolder = async (e) => {
    e.preventDefault();
    try {
      const name = `${MONTHS[newFolder.month - 1]} ${newFolder.year}`;
      await api.createMonthlyFolder({ client_id: client.id, name, month: newFolder.month, year: newFolder.year });
      setShowCreateFolder(false);
      loadClient();
    } catch (err) { alert(err.message); }
  };

  const handleCreateCampaign = async (e) => {
    e.preventDefault();
    try {
      await api.createCampaign({ name: newCampaign.name, description: newCampaign.description, monthly_folder_id: showCreateCampaign, client_id: client.id });
      setShowCreateCampaign(null);
      setNewCampaign({ name: '', description: '' });
      loadCampaigns(showCreateCampaign);
    } catch (err) { alert(err.message); }
  };

  const handleAddAccount = async (e) => {
    e.preventDefault();
    try {
      await api.addBurnerAccount(client.id, newAccount);
      setShowAddAccount(false);
      setNewAccount({ platform: 'tiktok', account_name: '', account_username: '' });
      loadClient();
    } catch (err) { alert(err.message); }
  };

  if (!detail) return <div className="page-content"><p style={{ color: 'var(--text-tertiary)' }}>Loading...</p></div>;

  return (
    <div className="page-content">
      <button className="btn btn-secondary btn-sm" onClick={onBack} style={{ marginBottom: 16 }}>
        <ChevronLeft size={14} /> Back to Clients
      </button>

      <div style={{ display: 'flex', alignItems: 'center', gap: 16, marginBottom: 24 }}>
        {detail.client.logo_url
          ? <img src={detail.client.logo_url} style={{ width: 56, height: 56, borderRadius: 12, objectFit: 'cover' }} />
          : <div className="client-logo-placeholder" style={{ width: 56, height: 56, fontSize: 24, borderRadius: 12 }}>{detail.client.name[0]}</div>}
        <div>
          <h2 style={{ fontSize: 22, fontWeight: 600 }}>{detail.client.name}</h2>
          <p style={{ fontSize: 13, color: 'var(--text-tertiary)' }}>
            {detail.burner_accounts?.length || 0} accounts connected
          </p>
        </div>
        {hasRole('admin') && (
          <button className="btn btn-secondary btn-sm" onClick={() => { setEditingClient(true); setEditClientName(detail.client.name); }} style={{ marginLeft: 'auto' }}>
            <Edit2 size={12} /> Edit Client
          </button>
        )}
      </div>

      <div className="grid-2" style={{ marginBottom: 24 }}>
        {/* Monthly Folders */}
        <div>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 }}>
            <h3 style={{ fontSize: 15, fontWeight: 600 }}>Monthly Folders</h3>
            {hasRole('admin', 'project_manager') && (
              <button className="btn btn-primary btn-sm" onClick={() => setShowCreateFolder(true)}>
                <Plus size={14} /> Add Month
              </button>
            )}
          </div>

          {(detail.folders || []).length === 0 ? (
            <div className="card"><p style={{ color: 'var(--text-tertiary)', fontSize: 13 }}>No folders yet</p></div>
          ) : detail.folders.map(folder => (
            <div key={folder.id} className="card" style={{ marginBottom: 8 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10, cursor: 'pointer' }} onClick={() => toggleFolder(folder.id)}>
                {expandedFolder === folder.id ? <ChevronDown size={16} /> : <ChevronRight size={16} />}
                <FolderOpen size={16} style={{ color: 'var(--warning)' }} />
                <span style={{ fontSize: 14, fontWeight: 500, flex: 1 }}>{folder.name}</span>
                {hasRole('admin', 'project_manager') && (
                  <button className="btn btn-danger btn-sm" onClick={(e) => { e.stopPropagation(); handleDeleteFolder(folder.id); }} title="Delete folder">
                    <Trash2 size={12} />
                  </button>
                )}
              </div>

              {expandedFolder === folder.id && (
                <div style={{ marginTop: 12, paddingLeft: 32 }}>
                  {hasRole('admin', 'project_manager') && (
                    <button className="btn btn-secondary btn-sm" onClick={() => setShowCreateCampaign(folder.id)} style={{ marginBottom: 8 }}>
                      <Plus size={12} /> New Campaign
                    </button>
                  )}
                  {(campaigns[folder.id] || []).map(c => (
                    <div key={c.id}
                      style={{
                        padding: '10px 14px', background: 'var(--bg-tertiary)', borderRadius: 'var(--radius-sm)',
                        marginBottom: 6, cursor: 'pointer', border: '1px solid transparent', transition: 'all 0.15s'
                      }}
                      onClick={() => onOpenCampaign(c)}
                      onMouseEnter={e => e.currentTarget.style.borderColor = 'var(--accent-primary)'}
                      onMouseLeave={e => e.currentTarget.style.borderColor = 'transparent'}>
                      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                          <Package size={14} style={{ color: 'var(--accent-primary)' }} />
                          <span style={{ fontSize: 13, fontWeight: 500 }}>{c.name}</span>
                        </div>
                        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                          <span style={{ fontSize: 11, color: 'var(--text-tertiary)' }}>
                            {c.completed_deliverables}/{c.total_deliverables}
                          </span>
                          {hasRole('admin', 'project_manager') && (
                            <button className="btn btn-danger btn-sm btn-icon" title="Delete campaign"
                              onClick={(e) => { e.stopPropagation(); handleDeleteCampaign(c.id, folder.id); }}>
                              <Trash2 size={12} />
                            </button>
                          )}
                          <ChevronRight size={14} style={{ color: 'var(--text-tertiary)' }} />
                        </div>
                      </div>
                      {c.description && <p style={{ fontSize: 11, color: 'var(--text-tertiary)', marginTop: 4, paddingLeft: 22 }}>{c.description}</p>}
                    </div>
                  ))}
                  {campaigns[folder.id]?.length === 0 && (
                    <p style={{ fontSize: 12, color: 'var(--text-muted)' }}>No campaigns yet</p>
                  )}
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Burner Accounts */}
        <div>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 }}>
            <h3 style={{ fontSize: 15, fontWeight: 600 }}>Burner Accounts</h3>
            {hasRole('admin', 'project_manager') && (
              <button className="btn btn-primary btn-sm" onClick={() => setShowAddAccount(true)}>
                <Plus size={14} /> Add Account
              </button>
            )}
          </div>

          {(detail.burner_accounts || []).length === 0 ? (
            <div className="card"><p style={{ color: 'var(--text-tertiary)', fontSize: 13 }}>No accounts yet</p></div>
          ) : detail.burner_accounts.map(acc => (
            <div key={acc.id} className="card" style={{ marginBottom: 8, display: 'flex', alignItems: 'center', gap: 12 }}>
              <div style={{
                width: 32, height: 32, borderRadius: 8,
                background: acc.platform === 'tiktok' ? 'rgba(96, 165, 250, 0.1)' : acc.platform === 'instagram' ? 'rgba(248, 113, 113, 0.1)' : 'rgba(96, 165, 250, 0.1)',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontSize: 11, fontWeight: 600, textTransform: 'uppercase',
                color: acc.platform === 'tiktok' ? 'var(--info)' : acc.platform === 'instagram' ? 'var(--danger)' : 'var(--info)'
              }}>{acc.platform.slice(0, 2)}</div>
              <div>
                <div style={{ fontSize: 13, fontWeight: 500 }}>{acc.account_name}</div>
                <div style={{ fontSize: 11, color: 'var(--text-tertiary)' }}>@{acc.account_username} · {acc.platform}</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Create Folder Modal */}
      {showCreateFolder && (
        <div className="modal-overlay" onClick={() => setShowCreateFolder(false)}>
          <div className="modal" onClick={e => e.stopPropagation()}>
            <h3 className="modal-title">Create Monthly Folder</h3>
            <form onSubmit={handleCreateFolder}>
              <div className="grid-2">
                <div className="form-group">
                  <label className="form-label">Month</label>
                  <select className="form-select" value={newFolder.month} onChange={e => setNewFolder({ ...newFolder, month: parseInt(e.target.value) })}>
                    {MONTHS.map((m, i) => <option key={i} value={i + 1}>{m}</option>)}
                  </select>
                </div>
                <div className="form-group">
                  <label className="form-label">Year</label>
                  <input className="form-input" type="number" value={newFolder.year} onChange={e => setNewFolder({ ...newFolder, year: parseInt(e.target.value) })} />
                </div>
              </div>
              <div className="modal-actions">
                <button type="button" className="btn btn-secondary" onClick={() => setShowCreateFolder(false)}>Cancel</button>
                <button type="submit" className="btn btn-primary">Create</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Create Campaign Modal */}
      {showCreateCampaign && (
        <div className="modal-overlay" onClick={() => setShowCreateCampaign(null)}>
          <div className="modal" onClick={e => e.stopPropagation()}>
            <h3 className="modal-title">New Campaign</h3>
            <form onSubmit={handleCreateCampaign}>
              <div className="form-group">
                <label className="form-label">Campaign Name</label>
                <input className="form-input" value={newCampaign.name} onChange={e => setNewCampaign({ ...newCampaign, name: e.target.value })} required placeholder="e.g., Spring Menu Launch" />
              </div>
              <div className="form-group">
                <label className="form-label">Description</label>
                <textarea className="form-textarea" value={newCampaign.description} onChange={e => setNewCampaign({ ...newCampaign, description: e.target.value })} placeholder="Campaign details..." />
              </div>
              <div className="modal-actions">
                <button type="button" className="btn btn-secondary" onClick={() => setShowCreateCampaign(null)}>Cancel</button>
                <button type="submit" className="btn btn-primary">Create Campaign</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Add Account Modal */}
      {showAddAccount && (
        <div className="modal-overlay" onClick={() => setShowAddAccount(false)}>
          <div className="modal" onClick={e => e.stopPropagation()}>
            <h3 className="modal-title">Add Burner Account</h3>
            <form onSubmit={handleAddAccount}>
              <div className="form-group">
                <label className="form-label">Platform</label>
                <select className="form-select" value={newAccount.platform} onChange={e => setNewAccount({ ...newAccount, platform: e.target.value })}>
                  <option value="tiktok">TikTok</option>
                  <option value="instagram">Instagram</option>
                  <option value="facebook">Facebook</option>
                </select>
              </div>
              <div className="form-group">
                <label className="form-label">Account Name</label>
                <input className="form-input" value={newAccount.account_name} onChange={e => setNewAccount({ ...newAccount, account_name: e.target.value })} required placeholder="e.g., BurgerPalace_Clips1" />
              </div>
              <div className="form-group">
                <label className="form-label">Username</label>
                <input className="form-input" value={newAccount.account_username} onChange={e => setNewAccount({ ...newAccount, account_username: e.target.value })} placeholder="@username" />
              </div>
              <div className="modal-actions">
                <button type="button" className="btn btn-secondary" onClick={() => setShowAddAccount(false)}>Cancel</button>
                <button type="submit" className="btn btn-primary">Add Account</button>
              </div>
            </form>
          </div>
        </div>
      )}
      {editingClient && (
        <div className="modal-overlay" onClick={() => setEditingClient(false)}>
          <div className="modal" onClick={e => e.stopPropagation()}>
            <h3 className="modal-title">Edit Client</h3>
            <form onSubmit={handleEditClient}>
              <div className="form-group">
                <label className="form-label">Client Name</label>
                <input className="form-input" value={editClientName} onChange={e => setEditClientName(e.target.value)} required />
              </div>
              <div className="form-group">
                <label className="form-label">Update Logo</label>
                <div style={{ border: '1px dashed var(--border-light)', borderRadius: 'var(--radius-sm)', padding: 16, textAlign: 'center', cursor: 'pointer' }}
                  onClick={() => document.getElementById('edit-logo').click()}>
                  <Upload size={18} style={{ color: 'var(--text-tertiary)' }} />
                  <p style={{ fontSize: 12, color: 'var(--text-tertiary)', marginTop: 4 }}>{editClientLogo ? editClientLogo.name : 'Click to upload new logo (optional)'}</p>
                  <input id="edit-logo" type="file" accept="image/*" hidden onChange={e => setEditClientLogo(e.target.files[0])} />
                </div>
              </div>
              <div className="modal-actions">
                <button type="button" className="btn btn-secondary" onClick={() => setEditingClient(false)}>Cancel</button>
                <button type="submit" className="btn btn-primary">Save Changes</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {editingCampaign && (
        <div className="modal-overlay" onClick={() => setEditingCampaign(null)}>
          <div className="modal" onClick={e => e.stopPropagation()}>
            <h3 className="modal-title">Edit Campaign</h3>
            <form onSubmit={handleEditCampaign}>
              <div className="form-group">
                <label className="form-label">Campaign Name</label>
                <input className="form-input" value={editCampaignName} onChange={e => setEditCampaignName(e.target.value)} required />
              </div>
              <div className="form-group">
                <label className="form-label">Description</label>
                <textarea className="form-textarea" value={editCampaignDesc} onChange={e => setEditCampaignDesc(e.target.value)} />
              </div>
              <div className="modal-actions">
                <button type="button" className="btn btn-secondary" onClick={() => setEditingCampaign(null)}>Cancel</button>
                <button type="submit" className="btn btn-primary">Save Changes</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default ClientDetailPage;
