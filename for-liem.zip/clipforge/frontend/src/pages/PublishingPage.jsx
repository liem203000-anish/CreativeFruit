import { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import api from '../services/api';
import { Send, Edit2, Copy, Instagram, Globe, Play, Image, Film, ChevronDown, ChevronUp, Check, X, Users, Plus, Trash2 } from 'lucide-react';

const PLATFORMS = [
  { key: 'tiktok', label: 'TikTok', icon: '🎵', color: '#00f2ea' },
  { key: 'instagram_reels', label: 'IG Reels', icon: '🎬', color: '#E1306C' },
  { key: 'instagram_stories', label: 'IG Stories', icon: '📱', color: '#833AB4' },
  { key: 'instagram_trial_reels', label: 'IG Trial Reels', icon: '🧪', color: '#F77737' },
  { key: 'instagram_image', label: 'IG Image Post', icon: '🖼️', color: '#C13584' },
  { key: 'facebook_reels', label: 'FB Reels', icon: '📘', color: '#1877F2' },
  { key: 'youtube_shorts', label: 'YT Shorts', icon: '▶️', color: '#FF0000' },
];

const PublishingPage = () => {
  const { hasRole } = useAuth();
  const [clients, setClients] = useState([]);
  const [selectedClient, setSelectedClient] = useState(null);
  const [deliverables, setDeliverables] = useState([]);
  const [expandedDel, setExpandedDel] = useState(null);
  const [publishConfigs, setPublishConfigs] = useState({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.getClients().then(d => {
      setClients(d.clients || []);
      if (d.clients?.length > 0) setSelectedClient(d.clients[0].id);
    }).catch(console.error);
  }, []);

  useEffect(() => {
    if (selectedClient) loadDeliverables();
  }, [selectedClient]);

  const loadDeliverables = async () => {
    setLoading(true);
    try {
      const data = await api.getKanban(selectedClient);
      const approved = (data.deliverables || []).filter(d => ['approved', 'scheduled', 'posted'].includes(d.status) && d.video_url);
      setDeliverables(approved);

      // Load existing publish configs
      const configs = {};
      for (const d of approved) {
        try {
          const pc = await api.getPublishConfig(d.id);
          if (pc.config) configs[d.id] = pc.config;
        } catch (e) {}
      }
      setPublishConfigs(configs);
    } catch (err) { console.error(err); }
    setLoading(false);
  };

  const getOrCreateConfig = (deliverableId) => {
    if (publishConfigs[deliverableId]) return publishConfigs[deliverableId];
    return {
      shared_caption: '',
      custom_captions: false,
      platforms: {},
      collab_accounts: [],
    };
  };

  const updateConfig = (deliverableId, updates) => {
    const current = getOrCreateConfig(deliverableId);
    const updated = { ...current, ...updates };
    setPublishConfigs(prev => ({ ...prev, [deliverableId]: updated }));
  };

  const updatePlatformConfig = (deliverableId, platformKey, updates) => {
    const current = getOrCreateConfig(deliverableId);
    const platforms = { ...current.platforms };
    platforms[platformKey] = { ...(platforms[platformKey] || { enabled: false, caption: '', account_id: '' }), ...updates };
    updateConfig(deliverableId, { platforms });
  };

  const togglePlatform = (deliverableId, platformKey) => {
    const current = getOrCreateConfig(deliverableId);
    const platforms = { ...current.platforms };
    const existing = platforms[platformKey] || { enabled: false, caption: '', account_id: '' };
    platforms[platformKey] = { ...existing, enabled: !existing.enabled };
    updateConfig(deliverableId, { platforms });
  };

  const handleSaveConfig = async (deliverableId) => {
    try {
      const config = getOrCreateConfig(deliverableId);
      await api.savePublishConfig(deliverableId, config);
      alert('Publishing config saved!');
    } catch (err) { alert(err.message); }
  };

  const handlePublish = async (deliverableId, platformKey) => {
    const config = getOrCreateConfig(deliverableId);
    const platConfig = config.platforms[platformKey];
    if (!platConfig?.enabled) return;

    const caption = config.custom_captions ? (platConfig.caption || config.shared_caption) : config.shared_caption;

    try {
      await api.publishToplatform(deliverableId, {
        platform: platformKey,
        caption,
        account_id: platConfig.account_id,
        collab_accounts: platformKey.startsWith('instagram') ? config.collab_accounts : [],
      });
      alert(`Published to ${platformKey}!`);
      loadDeliverables();
    } catch (err) { alert(err.message); }
  };

  const addCollabAccount = (deliverableId) => {
    const current = getOrCreateConfig(deliverableId);
    updateConfig(deliverableId, { collab_accounts: [...(current.collab_accounts || []), ''] });
  };

  const updateCollabAccount = (deliverableId, index, value) => {
    const current = getOrCreateConfig(deliverableId);
    const collabs = [...(current.collab_accounts || [])];
    collabs[index] = value;
    updateConfig(deliverableId, { collab_accounts: collabs });
  };

  const removeCollabAccount = (deliverableId, index) => {
    const current = getOrCreateConfig(deliverableId);
    const collabs = (current.collab_accounts || []).filter((_, i) => i !== index);
    updateConfig(deliverableId, { collab_accounts: collabs });
  };

  if (loading) return <div className="page-content"><p style={{ color: 'var(--text-tertiary)' }}>Loading...</p></div>;

  return (
    <div className="page-content">
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 20 }}>
        <h2 style={{ fontSize: 20, fontWeight: 600 }}>Publishing Dashboard</h2>
        <select className="form-select" style={{ width: 200 }} value={selectedClient || ''} onChange={e => setSelectedClient(e.target.value)}>
          {clients.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
        </select>
      </div>

      {deliverables.length === 0 ? (
        <div className="empty-state">
          <Send />
          <h3>No videos ready to publish</h3>
          <p>Videos with "Approved" status and an uploaded video will appear here</p>
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          {deliverables.map(d => {
            const config = getOrCreateConfig(d.id);
            const isExpanded = expandedDel === d.id;
            const enabledPlatforms = Object.entries(config.platforms || {}).filter(([_, v]) => v.enabled);

            return (
              <div key={d.id} className="card">
                {/* Header */}
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', cursor: 'pointer' }}
                  onClick={() => setExpandedDel(isExpanded ? null : d.id)}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                    {d.video_url && (
                      <video src={d.video_url} style={{ width: 60, height: 80, objectFit: 'cover', borderRadius: 8 }} />
                    )}
                    <div>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                        <span style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--accent-primary)', fontWeight: 600 }}>{d.template_code}</span>
                        <span style={{ fontSize: 14, fontWeight: 600 }}>{d.template_name}</span>
                        <span style={{ fontSize: 11, color: 'var(--text-tertiary)' }}>
                          {d.variant_number === 0 ? 'Parent' : `V${d.variant_number}`}
                        </span>
                      </div>
                      <div style={{ fontSize: 12, color: 'var(--text-tertiary)', marginTop: 2 }}>
                        {d.campaign_name} · {d.editor_name || 'Unassigned'}
                      </div>
                      {enabledPlatforms.length > 0 && (
                        <div style={{ display: 'flex', gap: 4, marginTop: 6 }}>
                          {enabledPlatforms.map(([key]) => {
                            const p = PLATFORMS.find(pl => pl.key === key);
                            return p ? (
                              <span key={key} style={{ fontSize: 10, padding: '2px 6px', background: 'var(--bg-tertiary)', borderRadius: 8, color: p.color }}>{p.icon} {p.label}</span>
                            ) : null;
                          })}
                        </div>
                      )}
                    </div>
                  </div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                    <span className={`status-badge status-${d.status}`}>{d.status.replace('_', ' ')}</span>
                    {isExpanded ? <ChevronUp size={16} style={{ color: 'var(--text-tertiary)' }} /> : <ChevronDown size={16} style={{ color: 'var(--text-tertiary)' }} />}
                  </div>
                </div>

                {/* Expanded Publishing Config */}
                {isExpanded && (
                  <div style={{ marginTop: 16, borderTop: '1px solid var(--border)', paddingTop: 16 }}>
                    {/* Platform Selection */}
                    <div style={{ marginBottom: 16 }}>
                      <div style={{ fontSize: 12, fontWeight: 600, color: 'var(--text-tertiary)', marginBottom: 8, textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                        Select Platforms
                      </div>
                      <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                        {PLATFORMS.map(p => {
                          const enabled = config.platforms?.[p.key]?.enabled;
                          return (
                            <button key={p.key} onClick={() => togglePlatform(d.id, p.key)}
                              style={{
                                padding: '8px 14px', borderRadius: 'var(--radius-sm)', cursor: 'pointer',
                                border: enabled ? `2px solid ${p.color}` : '1px solid var(--border)',
                                background: enabled ? `${p.color}15` : 'var(--bg-tertiary)',
                                color: enabled ? p.color : 'var(--text-secondary)',
                                fontSize: 12, fontWeight: 500, fontFamily: 'var(--font-body)',
                                display: 'flex', alignItems: 'center', gap: 6,
                                transition: 'all 0.15s'
                              }}>
                              <span>{p.icon}</span>
                              {p.label}
                              {enabled && <Check size={12} />}
                            </button>
                          );
                        })}
                      </div>
                    </div>

                    {/* Shared Caption */}
                    <div style={{ marginBottom: 16 }}>
                      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 8 }}>
                        <div style={{ fontSize: 12, fontWeight: 600, color: 'var(--text-tertiary)', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                          Caption
                        </div>
                        <label style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 11, color: 'var(--text-secondary)', cursor: 'pointer' }}>
                          <input type="checkbox" checked={config.custom_captions || false}
                            onChange={e => updateConfig(d.id, { custom_captions: e.target.checked })}
                            style={{ accentColor: 'var(--accent-primary)' }} />
                          Customize per platform
                        </label>
                      </div>

                      {!config.custom_captions ? (
                        <textarea className="form-textarea" value={config.shared_caption || ''} onChange={e => updateConfig(d.id, { shared_caption: e.target.value })}
                          placeholder="Write your caption here... (shared across all platforms)"
                          style={{ minHeight: 80, fontSize: 13 }} />
                      ) : (
                        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                          {PLATFORMS.filter(p => config.platforms?.[p.key]?.enabled).map(p => (
                            <div key={p.key}>
                              <div style={{ fontSize: 11, fontWeight: 600, color: p.color, marginBottom: 4, display: 'flex', alignItems: 'center', gap: 4 }}>
                                {p.icon} {p.label}
                              </div>
                              <textarea className="form-textarea" value={config.platforms?.[p.key]?.caption || config.shared_caption || ''}
                                onChange={e => updatePlatformConfig(d.id, p.key, { caption: e.target.value })}
                                placeholder={`Caption for ${p.label}...`}
                                style={{ minHeight: 60, fontSize: 12 }} />
                            </div>
                          ))}
                        </div>
                      )}
                    </div>

                    {/* Instagram Collab Invite */}
                    {Object.entries(config.platforms || {}).some(([k, v]) => k.startsWith('instagram') && v.enabled) && (
                      <div style={{ marginBottom: 16 }}>
                        <div style={{ fontSize: 12, fontWeight: 600, color: 'var(--text-tertiary)', marginBottom: 8, textTransform: 'uppercase', letterSpacing: '0.05em', display: 'flex', alignItems: 'center', gap: 6 }}>
                          <Users size={14} /> Instagram Collab Invites
                        </div>
                        <p style={{ fontSize: 11, color: 'var(--text-muted)', marginBottom: 8 }}>
                          Invite accounts to collaborate on this Instagram post
                        </p>
                        {(config.collab_accounts || []).map((acct, i) => (
                          <div key={i} style={{ display: 'flex', gap: 6, marginBottom: 6 }}>
                            <input className="form-input" value={acct} onChange={e => updateCollabAccount(d.id, i, e.target.value)}
                              placeholder="@username" style={{ fontSize: 12, flex: 1 }} />
                            <button className="btn btn-danger btn-sm" onClick={() => removeCollabAccount(d.id, i)}>
                              <Trash2 size={12} />
                            </button>
                          </div>
                        ))}
                        <button className="btn btn-secondary btn-sm" onClick={() => addCollabAccount(d.id)}>
                          <Plus size={12} /> Add Collab Account
                        </button>
                      </div>
                    )}

                    {/* Per-Platform Account Assignment & Publish Buttons */}
                    {enabledPlatforms.length > 0 && (
                      <div style={{ marginBottom: 16 }}>
                        <div style={{ fontSize: 12, fontWeight: 600, color: 'var(--text-tertiary)', marginBottom: 8, textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                          Publish
                        </div>
                        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(220px, 1fr))', gap: 10 }}>
                          {enabledPlatforms.map(([key, platConfig]) => {
                            const p = PLATFORMS.find(pl => pl.key === key);
                            if (!p) return null;
                            return (
                              <div key={key} style={{ background: 'var(--bg-tertiary)', borderRadius: 'var(--radius-sm)', padding: 12, border: `1px solid ${p.color}30` }}>
                                <div style={{ fontSize: 12, fontWeight: 600, color: p.color, marginBottom: 8, display: 'flex', alignItems: 'center', gap: 4 }}>
                                  {p.icon} {p.label}
                                </div>
                                <div style={{ fontSize: 10, color: 'var(--text-tertiary)', marginBottom: 4, fontWeight: 600, textTransform: 'uppercase' }}>Account</div>
                                <input className="form-input" value={platConfig.account_id || ''} onChange={e => updatePlatformConfig(d.id, key, { account_id: e.target.value })}
                                  placeholder="Account username" style={{ fontSize: 11, marginBottom: 8, padding: '4px 8px' }} />
                                <div style={{ display: 'flex', gap: 6 }}>
                                  <button className="btn btn-primary btn-sm" style={{ flex: 1, fontSize: 11, background: p.color }}
                                    onClick={() => handlePublish(d.id, key)}>
                                    <Send size={10} /> Publish
                                  </button>
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    )}

                    {/* Save Config */}
                    <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 8 }}>
                      <button className="btn btn-primary" onClick={() => handleSaveConfig(d.id)}>
                        <Check size={14} /> Save Publishing Config
                      </button>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

export default PublishingPage;
