import { useState, useEffect } from 'react';
import api from '../services/api';
import { BarChart3, TrendingUp, Layers, Anchor, Users } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar } from 'recharts';

const AnalyticsPage = () => {
  const [tab, setTab] = useState('templates');
  const [templates, setTemplates] = useState([]);
  const [hooks, setHooks] = useState([]);
  const [accounts, setAccounts] = useState([]);
  const [selectedTemplate, setSelectedTemplate] = useState(null);
  const [variants, setVariants] = useState([]);

  useEffect(() => {
    api.getTemplateAnalytics().then(d => setTemplates(d.templates || [])).catch(console.error);
    api.getHookAnalytics().then(d => setHooks(d.hooks || [])).catch(console.error);
    api.getAccountAnalytics().then(d => setAccounts(d.accounts || [])).catch(console.error);
  }, []);

  const loadVariants = async (templateId) => {
    setSelectedTemplate(templateId);
    try {
      const data = await api.getVariantAnalytics(templateId);
      setVariants(data.variants || []);
    } catch (err) { console.error(err); }
  };

  const getScoreClass = (score) => {
    const s = parseFloat(score) || 0;
    if (s >= 70) return 'score-high';
    if (s >= 40) return 'score-mid';
    return 'score-low';
  };

  const tooltipStyle = { background: 'var(--bg-elevated)', border: '1px solid var(--border)', borderRadius: 8, fontSize: 12 };

  return (
    <div className="page-content">
      <h2 style={{ fontSize: 20, fontWeight: 600, marginBottom: 20 }}>Analytics</h2>

      <div className="tabs">
        <button className={`tab ${tab === 'templates' ? 'active' : ''}`} onClick={() => setTab('templates')}>
          <Layers size={14} style={{ marginRight: 4, verticalAlign: -2 }} /> Templates
        </button>
        <button className={`tab ${tab === 'hooks' ? 'active' : ''}`} onClick={() => setTab('hooks')}>
          <Anchor size={14} style={{ marginRight: 4, verticalAlign: -2 }} /> Hooks
        </button>
        <button className={`tab ${tab === 'accounts' ? 'active' : ''}`} onClick={() => setTab('accounts')}>
          <Users size={14} style={{ marginRight: 4, verticalAlign: -2 }} /> Accounts
        </button>
      </div>

      {/* TEMPLATE ANALYTICS */}
      {tab === 'templates' && (
        <div>
          {templates.length === 0 ? (
            <div className="empty-state"><BarChart3 /><h3>No data yet</h3><p>Template scores will appear once videos are posted and analytics are pulled</p></div>
          ) : (
            <>
              <div className="card" style={{ marginBottom: 16 }}>
                <div className="card-header"><h3 className="card-title">Template Scorecard</h3></div>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={templates.map(t => ({ name: t.code, score: Math.round(parseFloat(t.score) || 0), times: t.times_used }))}>
                    <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                    <XAxis dataKey="name" tick={{ fontSize: 11, fill: 'var(--text-secondary)' }} />
                    <YAxis domain={[0, 100]} tick={{ fontSize: 11, fill: 'var(--text-secondary)' }} />
                    <Tooltip contentStyle={tooltipStyle} />
                    <Bar dataKey="score" fill="var(--accent-primary)" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>

              <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                {templates.map(t => (
                  <div key={t.id} className="card" style={{ cursor: 'pointer' }} onClick={() => loadVariants(t.id)}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
                      <div className={`score-badge ${getScoreClass(t.score)}`}>{Math.round(parseFloat(t.score) || 0)}</div>
                      <div style={{ flex: 1 }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                          <span style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--accent-primary)' }}>{t.code}</span>
                          <span style={{ fontSize: 14, fontWeight: 600 }}>{t.name}</span>
                        </div>
                        <div style={{ display: 'flex', gap: 16, marginTop: 4, fontSize: 11, color: 'var(--text-tertiary)' }}>
                          <span>3s retention: {(parseFloat(t.avg_3s_retention) * 100).toFixed(1)}%</span>
                          <span>Avg watch: {parseFloat(t.avg_watch_time).toFixed(1)}s</span>
                          <span>Engagement: {(parseFloat(t.avg_engagement) * 100).toFixed(2)}%</span>
                          <span>Avg views: {Math.round(parseFloat(t.avg_views))}</span>
                          <span>{t.data_points} data points</span>
                        </div>
                      </div>
                    </div>

                    {selectedTemplate === t.id && variants.length > 0 && (
                      <div style={{ marginTop: 16, paddingTop: 16, borderTop: '1px solid var(--border)' }}>
                        <h4 style={{ fontSize: 13, fontWeight: 600, marginBottom: 12 }}>Variant Comparison</h4>
                        <div className="grid-2">
                          <div>
                            <p style={{ fontSize: 11, color: 'var(--text-tertiary)', marginBottom: 8 }}>3-Second Retention by Variant</p>
                            <ResponsiveContainer width="100%" height={180}>
                              <BarChart data={variants.map(v => ({ name: `V${v.variant_number}`, retention: (parseFloat(v.avg_3s_retention) * 100) }))}>
                                <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                                <XAxis dataKey="name" tick={{ fontSize: 11, fill: 'var(--text-secondary)' }} />
                                <YAxis domain={[0, 100]} tick={{ fontSize: 11, fill: 'var(--text-secondary)' }} />
                                <Tooltip contentStyle={tooltipStyle} />
                                <Bar dataKey="retention" fill="var(--success)" radius={[4, 4, 0, 0]} />
                              </BarChart>
                            </ResponsiveContainer>
                          </div>
                          <div>
                            <p style={{ fontSize: 11, color: 'var(--text-tertiary)', marginBottom: 8 }}>50% Drop-off Point (seconds)</p>
                            <ResponsiveContainer width="100%" height={180}>
                              <BarChart data={variants.map(v => ({ name: `V${v.variant_number}`, dropoff: parseFloat(v.avg_50_dropoff) }))}>
                                <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                                <XAxis dataKey="name" tick={{ fontSize: 11, fill: 'var(--text-secondary)' }} />
                                <YAxis tick={{ fontSize: 11, fill: 'var(--text-secondary)' }} />
                                <Tooltip contentStyle={tooltipStyle} />
                                <Bar dataKey="dropoff" fill="var(--info)" radius={[4, 4, 0, 0]} />
                              </BarChart>
                            </ResponsiveContainer>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </>
          )}
        </div>
      )}

      {/* HOOK ANALYTICS */}
      {tab === 'hooks' && (
        <div>
          {hooks.length === 0 ? (
            <div className="empty-state"><Anchor /><h3>No hook data yet</h3><p>Hook scores will appear once videos using them are posted</p></div>
          ) : (
            <>
              <div className="card" style={{ marginBottom: 16 }}>
                <div className="card-header"><h3 className="card-title">Hook Library Scores</h3></div>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={hooks.map(h => ({ name: h.name.length > 20 ? h.name.slice(0, 20) + '...' : h.name, score: Math.round(parseFloat(h.score) || 0) }))}>
                    <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                    <XAxis dataKey="name" tick={{ fontSize: 10, fill: 'var(--text-secondary)' }} angle={-20} textAnchor="end" height={60} />
                    <YAxis domain={[0, 100]} tick={{ fontSize: 11, fill: 'var(--text-secondary)' }} />
                    <Tooltip contentStyle={tooltipStyle} />
                    <Bar dataKey="score" fill="var(--warning)" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>

              {hooks.map(h => (
                <div key={h.id} className="card" style={{ marginBottom: 10 }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
                    <div className={`score-badge ${getScoreClass(h.score)}`}>{Math.round(parseFloat(h.score) || 0)}</div>
                    <div style={{ flex: 1 }}>
                      <h4 style={{ fontSize: 14, fontWeight: 600 }}>{h.name}</h4>
                      <p style={{ fontSize: 12, color: 'var(--text-secondary)', marginTop: 2 }}>{h.hook_text}</p>
                      <div style={{ display: 'flex', gap: 16, marginTop: 6, fontSize: 11, color: 'var(--text-tertiary)' }}>
                        <span>3s retention: {(parseFloat(h.avg_3s_retention) * 100).toFixed(1)}%</span>
                        <span>50% dropoff: {parseFloat(h.avg_50_dropoff).toFixed(1)}s</span>
                        <span>Used {h.times_used} times</span>
                        <span>{h.data_points} data points</span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </>
          )}
        </div>
      )}

      {/* ACCOUNT ANALYTICS */}
      {tab === 'accounts' && (
        <div>
          {accounts.length === 0 ? (
            <div className="empty-state"><Users /><h3>No account data yet</h3><p>Account analytics will appear once videos are posted through burner accounts</p></div>
          ) : (
            <div className="card">
              <div className="card-header"><h3 className="card-title">Account Performance</h3></div>
              <div className="table-container">
                <table className="data-table">
                  <thead>
                    <tr>
                      <th>Account</th>
                      <th>Platform</th>
                      <th>Client</th>
                      <th>Posts</th>
                      <th>Total Views</th>
                      <th>Avg Views</th>
                      <th>Avg Engagement</th>
                      <th>3s Retention</th>
                    </tr>
                  </thead>
                  <tbody>
                    {accounts.map(a => (
                      <tr key={a.id}>
                        <td>
                          <div style={{ fontWeight: 500 }}>{a.account_name}</div>
                          <div style={{ fontSize: 11, color: 'var(--text-tertiary)' }}>@{a.account_username}</div>
                        </td>
                        <td>
                          <span className={`status-badge ${a.platform === 'tiktok' ? 'status-scheduled' : a.platform === 'instagram' ? 'status-revision' : 'status-get_started'}`}>
                            {a.platform}
                          </span>
                        </td>
                        <td>{a.client_name}</td>
                        <td>{a.total_posts}</td>
                        <td>{parseInt(a.total_views).toLocaleString()}</td>
                        <td>{Math.round(parseFloat(a.avg_views)).toLocaleString()}</td>
                        <td>{(parseFloat(a.avg_engagement) * 100).toFixed(2)}%</td>
                        <td>{(parseFloat(a.avg_3s_retention) * 100).toFixed(1)}%</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default AnalyticsPage;
