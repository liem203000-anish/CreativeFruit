import { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import api from '../services/api';
import { Plus, ChevronLeft, Package, Sparkles, RefreshCw, Mic, Upload, Download, Trash2, Volume2, Type, ChevronDown, ChevronUp, Star } from 'lucide-react';

const STATUSES = [
  { key: 'get_started', label: 'Get Started' },
  { key: 'in_progress', label: 'In Progress' },
  { key: 'review', label: 'Review' },
  { key: 'revision', label: 'Revision' },
  { key: 'approved', label: 'Approved' },
  { key: 'scheduled', label: 'Scheduled' },
  { key: 'posted', label: 'Posted' },
];

const CampaignDetailPage = ({ campaign, client, onBack }) => {
  const { user, hasRole } = useAuth();
  const [deliverables, setDeliverables] = useState([]);
  const [templates, setTemplates] = useState([]);
  const [hooks, setHooks] = useState([]);
  const [editors, setEditors] = useState([]);
  const [burnerAccounts, setBurnerAccounts] = useState([]);
  const [voices, setVoices] = useState([]);
  const [showAddSet, setShowAddSet] = useState(false);
  const [newSet, setNewSet] = useState({ template_id: '', hook_id: '', assigned_editor_id: '' });
  const [generating, setGenerating] = useState(null);
  const [generatingVO, setGeneratingVO] = useState(null);
  const [regeneratingVO, setRegeneratingVO] = useState(null);
  const [expandedSet, setExpandedSet] = useState(null);
  const [loading, setLoading] = useState(true);
  const [selectedVoices, setSelectedVoices] = useState({});

  useEffect(() => { loadAll(); }, [campaign.id]);

  const loadAll = async () => {
    try {
      const [delData, tplData, hookData, userData, clientData] = await Promise.all([
        api.getDeliverables(campaign.id),
        api.getTemplates(),
        api.getHooks(),
        api.getUsers().catch(() => ({ users: [] })),
        api.getClient(client.id),
      ]);
      setDeliverables(delData.deliverables || []);
      setTemplates(tplData.templates || []);
      setHooks(hookData.hooks || []);
      setEditors((userData.users || []).filter(u => u.role === 'editor' && u.is_active));
      setBurnerAccounts(clientData.burner_accounts || []);
      try {
        const voiceData = await api.getVoices();
        setVoices(voiceData.voices || []);
      } catch (e) {}
    } catch (err) { console.error('Load error:', err); }
    finally { setLoading(false); }
  };

  const handleCreateSet = async (e) => {
    e.preventDefault();
    try {
      await api.createDeliverableSet({ campaign_id: campaign.id, client_id: client.id, template_id: newSet.template_id, hook_id: newSet.hook_id || null, assigned_editor_id: newSet.assigned_editor_id || null });
      setShowAddSet(false);
      setNewSet({ template_id: '', hook_id: '', assigned_editor_id: '' });
      loadAll();
    } catch (err) { alert(err.message); }
  };

  const handleDeleteSet = async (setId, variants) => {
    if (!confirm(`Delete this entire set of ${variants.length} deliverables? This cannot be undone.`)) return;
    try {
      await api.deleteDeliverableSet(setId);
      loadAll();
    } catch (err) { alert(err.message); }
  };

  const handleGenerateHooks = async (setId, hookId, templateId) => {
    setGenerating(setId);
    try {
      await api.generateHooks({ deliverable_set_id: setId, hook_id: hookId, template_id: templateId });
      loadAll();
    } catch (err) { alert(err.message); }
    setGenerating(null);
  };

  const handleRegenerateVariant = async (deliverableId) => {
    try { await api.regenerateVariant(deliverableId); loadAll(); }
    catch (err) { alert(err.message); }
  };

  const handleUpdateDeliverable = async (id, updates) => {
    try { await api.updateDeliverable(id, updates); loadAll(); }
    catch (err) { alert(err.message); }
  };

  const handleUploadVideo = async (deliverableId, file) => {
    try {
      const formData = new FormData();
      formData.append('video', file);
      await api.uploadVideo(deliverableId, formData);
      loadAll();
    } catch (err) { alert(err.message); }
  };

  const handleGenerateAllVoiceovers = async (setId, variants, voiceId) => {
    if (!voiceId) { alert('Please select a voice first'); return; }
    setGeneratingVO(setId);
    try {
      for (const v of variants) {
        if (v.has_voiceover && (v.voiceover_script || v.hook_variant_text) && !v.voiceover_url) {
          await api.generateVoiceover({ deliverable_id: v.id, voice_id: voiceId });
        }
      }
      loadAll();
    } catch (err) { alert(err.message); }
    setGeneratingVO(null);
  };

  const handleGenerateSingleVoiceover = async (deliverableId, voiceId, mode) => {
    if (!voiceId) { alert('Please select a voice first'); return; }
    try { await api.generateVoiceover({ deliverable_id: deliverableId, voice_id: voiceId, mode: mode || 'auto' }); loadAll(); }
    catch (err) { alert(err.message); }
  };

  const handleRegenerateVoiceover = async (deliverableId, voiceId) => {
    setRegeneratingVO(deliverableId);
    try {
      await api.clearVoiceover(deliverableId);
      await api.generateVoiceover({ deliverable_id: deliverableId, voice_id: voiceId });
      loadAll();
    } catch (err) { alert(err.message); }
    setRegeneratingVO(null);
  };

  const sets = {};
  deliverables.forEach(d => { const key = d.deliverable_set_id || d.id; if (!sets[key]) sets[key] = []; sets[key].push(d); });
  Object.values(sets).forEach(arr => arr.sort((a, b) => a.variant_number - b.variant_number));

  if (loading) return <div className="page-content"><p style={{ color: 'var(--text-tertiary)' }}>Loading...</p></div>;

  const renderVariantCard = (v, hasVoiceover) => {
    const isParent = v.variant_number === 0;
    return (
      <div key={v.id} style={{
        background: 'var(--bg-tertiary)', borderRadius: 'var(--radius-md)',
        padding: 16, border: isParent ? '2px solid var(--warning)' : '1px solid var(--border)'
      }}>
        {/* Header */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 }}>
          <span style={{
            fontSize: 12, fontWeight: 700, padding: '2px 10px',
            background: isParent ? 'var(--warning-bg)' : 'var(--accent-glow)',
            color: isParent ? 'var(--warning)' : 'var(--accent-primary)',
            borderRadius: 12, display: 'flex', alignItems: 'center', gap: 4
          }}>
            {isParent && <Star size={10} />}
            {isParent ? 'Parent Hook' : `Variant ${v.variant_number}`}
          </span>
          <span className={`status-badge status-${v.status}`}>{v.status.replace('_', ' ')}</span>
        </div>

        {/* TEXT HOOK (on screen) */}
        <div style={{
          background: 'var(--bg-secondary)', borderRadius: 'var(--radius-sm)',
          padding: 12, marginBottom: 10, borderLeft: isParent ? '3px solid var(--warning)' : '3px solid var(--info)'
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 4, marginBottom: 6 }}>
            <Type size={12} style={{ color: isParent ? 'var(--warning)' : 'var(--info)' }} />
            <span style={{ fontSize: 10, color: isParent ? 'var(--warning)' : 'var(--info)', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.05em' }}>
              {isParent ? 'Original Hook (On Screen)' : 'Text Hook (On Screen)'}
            </span>
          </div>
          {v.hook_variant_text ? (
            <div>
              <div style={{ marginBottom: 6 }}>
                <span style={{ fontSize: 9, color: '#fbbf24', fontWeight: 600, textTransform: 'uppercase' }}>Main Text:</span>
                <input className="form-input" value={v.hook_variant_text} style={{ fontSize: 14, fontWeight: 600, marginTop: 2, background: 'var(--bg-tertiary)' }}
                  onChange={e => handleUpdateDeliverable(v.id, { hook_variant_text: e.target.value })} />
              </div>
              <div>
                <span style={{ fontSize: 9, color: 'var(--text-tertiary)', fontWeight: 600, textTransform: 'uppercase' }}>Sub Text:</span>
                <input className="form-input" value={v.sub_text || ''} style={{ fontSize: 12, marginTop: 2, background: 'var(--bg-tertiary)' }}
                  onChange={e => handleUpdateDeliverable(v.id, { sub_text: e.target.value })} placeholder="Supporting line..." />
              </div>
            </div>
          ) : (
            <p style={{ fontSize: 12, color: 'var(--text-muted)', fontStyle: 'italic' }}>
              {isParent ? 'Will be set when hooks are generated' : 'Not generated yet'}
            </p>
          )}
          {v.hook_variant_text && !isParent && hasRole('admin', 'project_manager', 'lead_editor') && (
            <button className="btn btn-secondary btn-sm" style={{ marginTop: 8, fontSize: 10 }}
              onClick={() => handleRegenerateVariant(v.id)}>
              <RefreshCw size={10} /> Regenerate Text
            </button>
          )}
        </div>

        {/* VOICEOVER SCRIPT (what narrator says) */}
        {hasVoiceover && (
          <div style={{
            background: 'var(--bg-secondary)', borderRadius: 'var(--radius-sm)',
            padding: 12, marginBottom: 10, borderLeft: '3px solid var(--accent-primary)'
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 4, marginBottom: 6 }}>
              <Volume2 size={12} style={{ color: 'var(--accent-primary)' }} />
              <span style={{ fontSize: 10, color: 'var(--accent-primary)', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                Voiceover Script (What Narrator Says)
              </span>
            </div>
            {v.voiceover_hook ? (
              <div>
                <div style={{ marginBottom: 6 }}>
                  <span style={{ fontSize: 9, color: 'var(--warning)', fontWeight: 600, textTransform: 'uppercase' }}>Hook (changes per variant):</span>
                  <p style={{ fontSize: 13, color: 'var(--text-primary)', lineHeight: 1.5, fontWeight: 500, marginTop: 2 }}>"{v.voiceover_hook}"</p>
                </div>
                {v.voiceover_body && (
                  <div>
                    <span style={{ fontSize: 9, color: 'var(--text-tertiary)', fontWeight: 600, textTransform: 'uppercase' }}>Body (same for all):</span>
                    <p style={{ fontSize: 12, color: 'var(--text-secondary)', lineHeight: 1.5, marginTop: 2 }}>"{v.voiceover_body}"</p>
                  </div>
                )}
              </div>
            ) : v.hook_variant_text ? (
              <p style={{ fontSize: 12, color: 'var(--text-muted)', fontStyle: 'italic' }}>Voiceover script not generated yet</p>
            ) : (
              <p style={{ fontSize: 12, color: 'var(--text-muted)', fontStyle: 'italic' }}>Generate hooks first</p>
            )}

            {/* Audio Player / Generator */}
            <div style={{ marginTop: 8 }}>
              {v.voiceover_url ? (
                <div>
                  <div style={{ fontSize: 9, color: 'var(--warning)', fontWeight: 600, textTransform: 'uppercase', marginBottom: 4 }}>
                    {isParent ? 'Hook Audio' : 'Hook Audio'}
                  </div>
                  <audio controls src={v.voiceover_url} style={{ width: '100%', height: 36 }} />
                  <div style={{ display: 'flex', gap: 6, marginTop: 6 }}>
                    <a href={v.voiceover_url} download className="btn btn-secondary btn-sm" style={{ fontSize: 10 }}>
                      <Download size={10} /> Download Hook Audio
                    </a>
                    {hasRole('admin', 'project_manager', 'lead_editor') && v.voice_id && (
                      <button className="btn btn-secondary btn-sm" style={{ fontSize: 10 }}
                        onClick={() => handleRegenerateVoiceover(v.id, v.voice_id)}
                        disabled={regeneratingVO === v.id}>
                        {regeneratingVO === v.id ? <RefreshCw size={10} className="spinning" /> : <RefreshCw size={10} />}
                        Regenerate
                      </button>
                    )}
                  </div>
                  {isParent && v.voiceover_body_url && (
                    <div style={{ marginTop: 10 }}>
                      <div style={{ fontSize: 9, color: 'var(--text-tertiary)', fontWeight: 600, textTransform: 'uppercase', marginBottom: 4 }}>Body Audio</div>
                      <audio controls src={v.voiceover_body_url} style={{ width: '100%', height: 36 }} />
                      <div style={{ display: 'flex', gap: 6, marginTop: 6 }}>
                        <a href={v.voiceover_body_url} download className="btn btn-secondary btn-sm" style={{ fontSize: 10 }}>
                          <Download size={10} /> Download Body Audio
                        </a>
                      </div>
                    </div>
                  )}
                  {isParent && !v.voiceover_body_url && v.voiceover_body && v.voice_id && hasRole('admin', 'project_manager', 'lead_editor') && (
                    <div style={{ marginTop: 10, padding: 8, background: 'var(--bg-tertiary)', borderRadius: 'var(--radius-sm)' }}>
                      <div style={{ fontSize: 9, color: 'var(--text-tertiary)', fontWeight: 600, textTransform: 'uppercase', marginBottom: 4 }}>Body Audio</div>
                      <button className="btn btn-primary btn-sm" style={{ fontSize: 10 }}
                        onClick={() => handleGenerateSingleVoiceover(v.id, v.voice_id, 'body')}>
                        <Mic size={10} /> Generate Body Audio
                      </button>
                    </div>
                  )}
                </div>
              ) : (v.voiceover_script || v.hook_variant_text) ? (
                <div style={{ display: 'flex', gap: 6 }}>
                  <select className="form-select" style={{ fontSize: 11, padding: '4px 8px', flex: 1 }}
                    value={v.voice_id || ''} onChange={e => handleUpdateDeliverable(v.id, { voice_id: e.target.value })}>
                    <option value="">Select voice...</option>
                    {voices.map(voice => (
                      <option key={voice.voice_id} value={voice.voice_id}>{voice.name}</option>
                    ))}
                  </select>
                  {v.voice_id && (
                    <button className="btn btn-primary btn-sm" style={{ fontSize: 10 }}
                      onClick={() => handleGenerateSingleVoiceover(v.id, v.voice_id)}>
                      <Mic size={10} /> Generate Audio
                    </button>
                  )}
                </div>
              ) : null}
            </div>
          </div>
        )}

        {/* Assign Editor */}
        {hasRole('admin', 'project_manager') && (
          <div style={{ marginBottom: 8 }}>
            <div style={{ fontSize: 10, color: 'var(--text-tertiary)', marginBottom: 3, fontWeight: 600, textTransform: 'uppercase' }}>Assigned Editor</div>
            <select className="form-select" style={{ fontSize: 11, padding: '4px 8px' }}
              value={v.assigned_editor_id || ''} onChange={e => handleUpdateDeliverable(v.id, { assigned_editor_id: e.target.value })}>
              <option value="">Unassigned</option>
              {editors.map(ed => <option key={ed.id} value={ed.id}>{ed.full_name || ed.username}</option>)}
            </select>
          </div>
        )}

        {/* Burner Account */}
        {hasRole('admin', 'project_manager', 'lead_editor') && (
          <div style={{ marginBottom: 8 }}>
            <div style={{ fontSize: 10, color: 'var(--text-tertiary)', marginBottom: 3, fontWeight: 600, textTransform: 'uppercase' }}>Post To</div>
            <select className="form-select" style={{ fontSize: 11, padding: '4px 8px' }}
              value={v.burner_account_id || ''} onChange={e => handleUpdateDeliverable(v.id, { burner_account_id: e.target.value })}>
              <option value="">Select account...</option>
              {burnerAccounts.map(ba => (
                <option key={ba.id} value={ba.id}>{ba.account_name} (@{ba.account_username}) - {ba.platform}</option>
              ))}
            </select>
          </div>
        )}

        {/* Status */}
        <div style={{ marginBottom: 8 }}>
          <div style={{ fontSize: 10, color: 'var(--text-tertiary)', marginBottom: 3, fontWeight: 600, textTransform: 'uppercase' }}>Status</div>
          <select className="form-select" style={{ fontSize: 11, padding: '4px 8px' }}
            value={v.status} onChange={e => handleUpdateDeliverable(v.id, { status: e.target.value })}>
            {STATUSES.map(s => <option key={s.key} value={s.key}>{s.label}</option>)}
          </select>
        </div>

        {/* Video */}
        <div>
          <div style={{ fontSize: 10, color: 'var(--text-tertiary)', marginBottom: 3, fontWeight: 600, textTransform: 'uppercase' }}>Video</div>
          {v.video_url ? (
            <div>
              <video src={v.video_url} controls style={{ width: '100%', borderRadius: 'var(--radius-sm)', maxHeight: 200 }} />
              <div style={{ fontSize: 10, color: 'var(--text-tertiary)', marginTop: 4 }}>{v.video_filename}</div>
            </div>
          ) : (
            <div style={{ border: '1px dashed var(--border-light)', borderRadius: 'var(--radius-sm)', padding: 12, textAlign: 'center', cursor: 'pointer' }}
              onClick={() => document.getElementById(`video-${v.id}`).click()}>
              <Upload size={16} style={{ color: 'var(--text-tertiary)' }} />
              <p style={{ fontSize: 11, color: 'var(--text-tertiary)', marginTop: 4 }}>Upload video</p>
              <input id={`video-${v.id}`} type="file" accept="video/*" hidden
                onChange={e => { if (e.target.files[0]) handleUploadVideo(v.id, e.target.files[0]); }} />
            </div>
          )}
        </div>
      </div>
    );
  };

  return (
    <div className="page-content">
      <button className="btn btn-secondary btn-sm" onClick={onBack} style={{ marginBottom: 16 }}>
        <ChevronLeft size={14} /> Back to {client.name}
      </button>

      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 20 }}>
        <div>
          <h2 style={{ fontSize: 20, fontWeight: 600 }}>{campaign.name}</h2>
          {campaign.description && <p style={{ fontSize: 13, color: 'var(--text-tertiary)', marginTop: 4 }}>{campaign.description}</p>}
        </div>
        {hasRole('admin', 'project_manager', 'lead_editor') && (
          <button className="btn btn-primary" onClick={() => setShowAddSet(true)}>
            <Plus size={16} /> Add 5 Deliverables
          </button>
        )}
      </div>

      <div className="stat-grid" style={{ marginBottom: 24 }}>
        <div className="stat-card"><div className="stat-label">Total</div><div className="stat-value">{deliverables.length}</div></div>
        <div className="stat-card"><div className="stat-label">In Progress</div><div className="stat-value" style={{ color: 'var(--warning)' }}>{deliverables.filter(d => ['get_started', 'in_progress'].includes(d.status)).length}</div></div>
        <div className="stat-card"><div className="stat-label">In Review</div><div className="stat-value" style={{ color: 'var(--accent-primary)' }}>{deliverables.filter(d => ['review', 'revision'].includes(d.status)).length}</div></div>
        <div className="stat-card"><div className="stat-label">Posted</div><div className="stat-value" style={{ color: 'var(--success)' }}>{deliverables.filter(d => d.status === 'posted').length}</div></div>
      </div>

      {Object.keys(sets).length === 0 ? (
        <div className="empty-state"><Package /><h3>No deliverables yet</h3><p>Click "+ Add 5 Deliverables" to create your first set</p></div>
      ) : (
        Object.entries(sets).map(([setId, variants]) => {
          const first = variants[0];
          const isExpanded = expandedSet === setId;
          const childVariants = variants.filter(v => v.variant_number > 0);
          const allHaveHooks = childVariants.every(v => v.hook_variant_text);
          const hasVoiceover = first.has_voiceover;
          const needsVoiceovers = hasVoiceover && variants.some(v => (v.voiceover_script || v.hook_variant_text) && !v.voiceover_url);
          const setVoice = selectedVoices[setId] || '';
          const parentVariant = variants.find(v => v.variant_number === 0);

          return (
            <div key={setId} className="card" style={{ marginBottom: 16 }}>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 12, cursor: 'pointer', flex: 1 }}
                  onClick={() => setExpandedSet(isExpanded ? null : setId)}>
                  <div style={{ width: 40, height: 40, borderRadius: 10, background: 'var(--accent-glow)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                    <Package size={18} style={{ color: 'var(--accent-primary)' }} />
                  </div>
                  <div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                      <span style={{ fontFamily: 'var(--font-mono)', fontSize: 12, color: 'var(--accent-primary)', fontWeight: 600 }}>{first.template_code || 'No template'}</span>
                      <span style={{ fontSize: 14, fontWeight: 600 }}>{first.template_name || 'Untitled'}</span>
                    </div>
                    <div style={{ fontSize: 12, color: 'var(--text-tertiary)', marginTop: 2 }}>
                      {first.hook_name ? `Hook: ${first.hook_name}` : 'No hook assigned'} · 1 parent + {childVariants.length} variants
                      {hasVoiceover && <span style={{ color: 'var(--accent-primary)', marginLeft: 6 }}>🎙 Voiceover</span>}
                    </div>
                  </div>
                  <div style={{ marginLeft: 'auto', marginRight: 8 }}>
                    {isExpanded ? <ChevronUp size={16} style={{ color: 'var(--text-tertiary)' }} /> : <ChevronDown size={16} style={{ color: 'var(--text-tertiary)' }} />}
                  </div>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                  {hasRole('admin', 'project_manager') && editors.length > 0 && (
                    <select className="form-select" style={{ fontSize: 11, padding: '4px 8px', width: 150 }}
                      value={variants[0]?.assigned_editor_id || ''}
                      onChange={async (e) => {
                        const editorId = e.target.value;
                        for (const v of variants) {
                          await handleUpdateDeliverable(v.id, { assigned_editor_id: editorId || null });
                        }
                      }}>
                      <option value="">Assign Editor...</option>
                      {editors.map(ed => <option key={ed.id} value={ed.id}>{ed.full_name || ed.username}</option>)}
                    </select>
                  )}
                  {!allHaveHooks && first.hook_id && hasRole('admin', 'project_manager', 'lead_editor') && (
                    <button className="btn btn-primary btn-sm" onClick={() => handleGenerateHooks(setId, first.hook_id, first.template_id)} disabled={generating === setId}>
                      {generating === setId ? <RefreshCw size={14} className="spinning" /> : <Sparkles size={14} />}
                      {generating === setId ? 'Generating...' : 'Generate Hooks'}
                    </button>
                  )}
                  {hasRole('admin', 'project_manager') && (
                    <button className="btn btn-danger btn-sm" onClick={() => handleDeleteSet(setId, variants)} title="Delete set">
                      <Trash2 size={14} />
                    </button>
                  )}
                </div>
              </div>

              {isExpanded && (
                <div style={{ marginTop: 16 }}>
                  {/* Template Reference */}
                  {first.photo_reference_url && (
                    <div style={{ marginBottom: 16 }}>
                      <div style={{ fontSize: 11, fontWeight: 600, color: 'var(--text-tertiary)', marginBottom: 6, textTransform: 'uppercase', letterSpacing: '0.05em' }}>Template Reference</div>
                      <div style={{ display: 'flex', gap: 16, alignItems: 'flex-start' }}>
                        <img src={first.photo_reference_url} style={{ width: 160, aspectRatio: '9/16', objectFit: 'cover', borderRadius: 'var(--radius-sm)', border: '1px solid var(--border)' }} />
                        <div style={{ fontSize: 12, color: 'var(--text-secondary)' }}>
                          <p><strong>Template:</strong> {first.template_name} ({first.template_code})</p>
                          {first.font_name && <p style={{ marginTop: 4 }}><strong>Font:</strong> {first.font_name}</p>}
                          {first.text_position && <p style={{ marginTop: 4 }}><strong>Text Position:</strong> {first.text_position}</p>}
                          {first.has_voiceover && <p style={{ marginTop: 4, color: 'var(--accent-primary)' }}>🎙 Voiceover Enabled</p>}
                        </div>
                      </div>
                    </div>
                  )}

                  {first.main_script && (
                    <div style={{ background: 'var(--bg-tertiary)', borderRadius: 'var(--radius-sm)', padding: 12, marginBottom: 16 }}>
                      <div style={{ fontSize: 11, fontWeight: 600, color: 'var(--text-tertiary)', marginBottom: 4, textTransform: 'uppercase', letterSpacing: '0.05em' }}>Main Script (Body / Editor Guide)</div>
                      <p style={{ fontSize: 13, color: 'var(--text-secondary)', lineHeight: 1.6 }}>{first.main_script}</p>
                    </div>
                  )}

                  {hasVoiceover && needsVoiceovers && allHaveHooks && hasRole('admin', 'project_manager', 'lead_editor') && (
                    <div style={{ background: 'rgba(124, 92, 252, 0.08)', border: '1px solid rgba(124, 92, 252, 0.2)', borderRadius: 'var(--radius-md)', padding: 14, marginBottom: 16, display: 'flex', alignItems: 'center', gap: 12 }}>
                      <Mic size={18} style={{ color: 'var(--accent-primary)', flexShrink: 0 }} />
                      <div style={{ flex: 1 }}>
                        <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--accent-primary)', marginBottom: 6 }}>Generate Voiceovers for All Variants</div>
                        <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                          <select className="form-select" style={{ fontSize: 12, padding: '6px 10px', flex: 1, maxWidth: 300 }}
                            value={setVoice} onChange={e => setSelectedVoices(prev => ({ ...prev, [setId]: e.target.value }))}>
                            <option value="">Select a voice for all variants...</option>
                            {voices.map(voice => (<option key={voice.voice_id} value={voice.voice_id}>{voice.name}</option>))}
                          </select>
                          <button className="btn btn-primary btn-sm" onClick={() => handleGenerateAllVoiceovers(setId, variants, setVoice)} disabled={!setVoice || generatingVO === setId}>
                            {generatingVO === setId ? (<><RefreshCw size={12} className="spinning" /> Generating...</>) : (<><Volume2 size={12} /> Generate All</>)}
                          </button>
                        </div>
                      </div>
                    </div>
                  )}

                  {parentVariant && (
                    <div style={{ marginBottom: 16 }}>
                      <div style={{ fontSize: 11, fontWeight: 600, color: 'var(--warning)', marginBottom: 8, textTransform: 'uppercase', letterSpacing: '0.05em', display: 'flex', alignItems: 'center', gap: 4 }}>
                        <Star size={12} /> Parent Hook
                      </div>
                      {renderVariantCard(parentVariant, hasVoiceover)}
                    </div>
                  )}

                  <div style={{ fontSize: 11, fontWeight: 600, color: 'var(--text-tertiary)', marginBottom: 8, textTransform: 'uppercase', letterSpacing: '0.05em' }}>Variants</div>
                  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))', gap: 12 }}>
                    {childVariants.map(v => renderVariantCard(v, hasVoiceover))}
                  </div>
                </div>
              )}
            </div>
          );
        })
      )}

      {showAddSet && (
        <div className="modal-overlay" onClick={() => setShowAddSet(false)}>
          <div className="modal" onClick={e => e.stopPropagation()}>
            <h3 className="modal-title">Add Deliverable Set (1 Parent + 4 Variants)</h3>
            <form onSubmit={handleCreateSet}>
              <div className="form-group">
                <label className="form-label">Template</label>
                <select className="form-select" value={newSet.template_id} onChange={e => setNewSet({ ...newSet, template_id: e.target.value })} required>
                  <option value="">Select a template...</option>
                  {templates.map(t => (<option key={t.id} value={t.id}>{t.code} — {t.name}</option>))}
                </select>
              </div>
              <div className="form-group">
                <label className="form-label">Parent Hook</label>
                <select className="form-select" value={newSet.hook_id} onChange={e => setNewSet({ ...newSet, hook_id: e.target.value })}>
                  <option value="">Select a hook (optional)...</option>
                  {hooks.map(h => (<option key={h.id} value={h.id}>{h.name} — {h.hook_text.substring(0, 60)}...</option>))}
                </select>
              </div>
              {editors.length > 0 && (
                <div className="form-group">
                  <label className="form-label">Assign Editor (all 5 deliverables)</label>
                  <select className="form-select" value={newSet.assigned_editor_id} onChange={e => setNewSet({ ...newSet, assigned_editor_id: e.target.value })}>
                    <option value="">Assign later...</option>
                    {editors.map(ed => (<option key={ed.id} value={ed.id}>{ed.full_name || ed.username}</option>))}
                  </select>
                </div>
              )}
              {newSet.template_id && (
                <div style={{ background: 'var(--bg-tertiary)', borderRadius: 'var(--radius-sm)', padding: 12, marginBottom: 16 }}>
                  <p style={{ fontSize: 12, color: 'var(--text-secondary)' }}>
                    This will create <strong>5 deliverables</strong>: 1 parent hook + 4 AI-generated variants using template{' '}
                    <span style={{ color: 'var(--accent-primary)', fontFamily: 'var(--font-mono)' }}>{templates.find(t => t.id === newSet.template_id)?.code}</span>.
                    {newSet.hook_id && ' Click "Generate Hooks" after creation to generate variant text and voiceover scripts.'}
                  </p>
                </div>
              )}
              <div className="modal-actions">
                <button type="button" className="btn btn-secondary" onClick={() => setShowAddSet(false)}>Cancel</button>
                <button type="submit" className="btn btn-primary"><Plus size={14} /> Create 5 Deliverables</button>
              </div>
            </form>
          </div>
        </div>
      )}

      <style>{`
        @keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
        .spinning { animation: spin 1s linear infinite; }
      `}</style>
    </div>
  );
};

export default CampaignDetailPage;
