import { useState, useEffect, useRef } from 'react';
import api from '../services/api';
import { Kanban as KanbanIcon, X, MessageSquare, Clock, Check, Send } from 'lucide-react';

const STATUSES = [
  { key: 'get_started', label: 'Get Started' },
  { key: 'in_progress', label: 'In Progress' },
  { key: 'review', label: 'Review' },
  { key: 'revision', label: 'Revision' },
  { key: 'approved', label: 'Approved' },
  { key: 'scheduled', label: 'Scheduled' },
  { key: 'posted', label: 'Posted' },
];

const useHorizontalScroll = () => {
  const ref = useRef(null);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const onWheel = (e) => {
      if (Math.abs(e.deltaX) > Math.abs(e.deltaY)) return; // trackpad horizontal swipe, let it pass
      if (el.scrollWidth <= el.clientWidth) return; // no overflow, don't hijack
      e.preventDefault();
      el.scrollLeft += e.deltaY;
    };
    el.addEventListener('wheel', onWheel, { passive: false });
    return () => el.removeEventListener('wheel', onWheel);
  }, []);
  return ref;
};

const formatTime = (seconds) => {
  const m = Math.floor(seconds / 60);
  const s = Math.floor(seconds % 60);
  return `${m}:${s.toString().padStart(2, '0')}`;
};

const KanbanPage = () => {
  const [clients, setClients] = useState([]);
  const [selectedClient, setSelectedClient] = useState(null);
  const [deliverables, setDeliverables] = useState([]);
  const [filterEditor, setFilterEditor] = useState('all');
  const [editors, setEditors] = useState([]);
  const [reviewModal, setReviewModal] = useState(null);
  const [comments, setComments] = useState([]);
  const [newComment, setNewComment] = useState('');
  const [currentTime, setCurrentTime] = useState(0);
  const videoRef = useRef(null);
  const kanbanRef = useHorizontalScroll();

  useEffect(() => {
    api.getClients().then(d => {
      setClients(d.clients || []);
      if (d.clients?.length > 0) setSelectedClient(d.clients[0].id);
    }).catch(console.error);
  }, []);

  useEffect(() => {
    if (selectedClient) loadKanban();
  }, [selectedClient]);

  const loadKanban = () => {
    api.getKanban(selectedClient).then(d => {
      setDeliverables(d.deliverables || []);
      const editorSet = new Map();
      (d.deliverables || []).forEach(del => {
        if (del.editor_name) editorSet.set(del.assigned_editor_id, del.editor_name);
      });
      setEditors(Array.from(editorSet, ([id, name]) => ({ id, name })));
    }).catch(console.error);
  };

  const handleStatusChange = async (deliverableId, newStatus) => {
    try {
      await api.updateDeliverable(deliverableId, { status: newStatus });
      setDeliverables(prev => prev.map(d => d.id === deliverableId ? { ...d, status: newStatus } : d));
    } catch (err) { console.error(err); }
  };

  const openReview = async (deliverable) => {
    setReviewModal(deliverable);
    try {
      const data = await api.getComments(deliverable.id);
      setComments(data.comments || []);
    } catch (err) { console.error(err); }
  };

  const closeReview = () => {
    setReviewModal(null);
    setComments([]);
    setNewComment('');
    setCurrentTime(0);
  };

  const handleAddComment = async () => {
    if (!newComment.trim()) return;
    try {
      await api.addComment({
        deliverable_id: reviewModal.id,
        timestamp_seconds: currentTime,
        comment_text: newComment.trim(),
      });
      const data = await api.getComments(reviewModal.id);
      setComments(data.comments || []);
      setNewComment('');
    } catch (err) { alert(err.message); }
  };

  const handleResolveComment = async (commentId) => {
    try {
      await api.resolveComment(commentId);
      const data = await api.getComments(reviewModal.id);
      setComments(data.comments || []);
    } catch (err) { console.error(err); }
  };

  const seekToTimestamp = (seconds) => {
    if (videoRef.current) {
      videoRef.current.currentTime = seconds;
      videoRef.current.play();
    }
  };

  const handleTimeUpdate = () => {
    if (videoRef.current) setCurrentTime(videoRef.current.currentTime);
  };

  const captureTimestamp = () => {
    if (videoRef.current) {
      videoRef.current.pause();
      setCurrentTime(videoRef.current.currentTime);
    }
  };

  const filtered = filterEditor === 'all' ? deliverables : deliverables.filter(d => d.assigned_editor_id === filterEditor);

  return (
    <div className="page-content">
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 20 }}>
        <h2 style={{ fontSize: 20, fontWeight: 600 }}>Kanban Board</h2>
        <div style={{ display: 'flex', gap: 8 }}>
          <select className="form-select" style={{ width: 180 }} value={selectedClient || ''} onChange={e => setSelectedClient(e.target.value)}>
            {clients.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
          <select className="form-select" style={{ width: 160 }} value={filterEditor} onChange={e => setFilterEditor(e.target.value)}>
            <option value="all">All Editors</option>
            {editors.map(e => <option key={e.id} value={e.id}>{e.name}</option>)}
          </select>
        </div>
      </div>

      {deliverables.length === 0 ? (
        <div className="empty-state"><KanbanIcon /><h3>No deliverables yet</h3><p>Create deliverables in a client's campaign to see them here</p></div>
      ) : (
        <div className="kanban-board" ref={kanbanRef}>
          {STATUSES.map(status => {
            const cards = filtered.filter(d => d.status === status.key);
            return (
              <div key={status.key} className="kanban-column">
                <div className="kanban-column-header">
                  <span>{status.label}</span>
                  <span className="kanban-column-count">{cards.length}</span>
                </div>
                <div className="kanban-cards">
                  {cards.map(card => (
                    <div key={card.id} className="kanban-card" onClick={() => openReview(card)}>
                      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 6 }}>
                        <span style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--accent-primary)' }}>{card.template_code}</span>
                        <span style={{ fontSize: 10, color: 'var(--text-tertiary)' }}>
                          {card.variant_number === 0 ? 'Parent' : `V${card.variant_number}`}
                        </span>
                      </div>
                      <div style={{ fontSize: 13, fontWeight: 500, marginBottom: 4 }}>{card.template_name}</div>
                      <div style={{ fontSize: 11, color: 'var(--text-tertiary)', marginBottom: 8 }}>{card.campaign_name}</div>
                      {card.editor_name && (
                        <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 8 }}>
                          <div className="user-avatar" style={{ width: 20, height: 20, fontSize: 9 }}>{card.editor_name[0]}</div>
                          <span style={{ fontSize: 11, color: 'var(--text-secondary)' }}>{card.editor_name}</span>
                        </div>
                      )}
                      {card.video_url && (
                        <div style={{ fontSize: 10, color: 'var(--success)', display: 'flex', alignItems: 'center', gap: 4 }}>
                          <MessageSquare size={10} /> Video uploaded
                        </div>
                      )}
                      <select className="form-select" style={{ fontSize: 11, padding: '4px 8px', marginTop: 6 }} value={card.status}
                        onClick={e => e.stopPropagation()}
                        onChange={e => handleStatusChange(card.id, e.target.value)}>
                        {STATUSES.map(s => <option key={s.key} value={s.key}>{s.label}</option>)}
                      </select>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Review Modal */}
      {reviewModal && (
        <div className="modal-overlay" onClick={closeReview}>
          <div className="modal" onClick={e => e.stopPropagation()} style={{ maxWidth: 800, maxHeight: '90vh', overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
            {/* Header */}
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16, flexShrink: 0 }}>
              <div>
                <h3 style={{ fontSize: 16, fontWeight: 600 }}>
                  {reviewModal.template_name} — {reviewModal.variant_number === 0 ? 'Parent' : `Variant ${reviewModal.variant_number}`}
                </h3>
                <div style={{ fontSize: 12, color: 'var(--text-tertiary)', marginTop: 2 }}>
                  {reviewModal.campaign_name} · {reviewModal.editor_name || 'Unassigned'}
                </div>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                <span className={`status-badge status-${reviewModal.status}`}>{reviewModal.status.replace('_', ' ')}</span>
                <button className="btn btn-icon" onClick={closeReview}><X size={18} /></button>
              </div>
            </div>

            <div style={{ display: 'flex', gap: 16, flex: 1, overflow: 'hidden' }}>
              {/* Video Player */}
              <div style={{ flex: 1, minWidth: 0 }}>
                {reviewModal.video_url ? (
                  <div>
                    <video
                      ref={videoRef}
                      src={reviewModal.video_url}
                      controls
                      onTimeUpdate={handleTimeUpdate}
                      style={{ width: '100%', borderRadius: 'var(--radius-sm)', maxHeight: 360, background: '#000' }}
                    />
                    {/* Timeline markers */}
                    <div style={{ position: 'relative', height: 20, background: 'var(--bg-tertiary)', borderRadius: 4, marginTop: 8, overflow: 'hidden' }}>
                      {comments.filter(c => !c.is_resolved).map(c => {
                        const duration = videoRef.current?.duration || 1;
                        const pct = (c.timestamp_seconds / duration) * 100;
                        return (
                          <div key={c.id} title={`${formatTime(c.timestamp_seconds)}: ${c.comment_text}`}
                            onClick={() => seekToTimestamp(c.timestamp_seconds)}
                            style={{
                              position: 'absolute', left: `${pct}%`, top: 2, width: 12, height: 16,
                              background: 'var(--warning)', borderRadius: 2, cursor: 'pointer',
                              transform: 'translateX(-50%)', fontSize: 8, display: 'flex',
                              alignItems: 'center', justifyContent: 'center', color: '#000', fontWeight: 700
                            }}>!</div>
                        );
                      })}
                    </div>

                    {/* Add Comment */}
                    <div style={{ marginTop: 12, display: 'flex', gap: 8, alignItems: 'flex-start' }}>
                      <button className="btn btn-secondary btn-sm" onClick={captureTimestamp} style={{ flexShrink: 0, fontSize: 11 }}>
                        <Clock size={12} /> {formatTime(currentTime)}
                      </button>
                      <div style={{ flex: 1, display: 'flex', gap: 6 }}>
                        <input className="form-input" value={newComment} onChange={e => setNewComment(e.target.value)}
                          placeholder="Add a note at this timestamp..."
                          style={{ fontSize: 12 }}
                          onKeyDown={e => { if (e.key === 'Enter') handleAddComment(); }} />
                        <button className="btn btn-primary btn-sm" onClick={handleAddComment} disabled={!newComment.trim()}>
                          <Send size={12} />
                        </button>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div style={{ height: 240, background: 'var(--bg-tertiary)', borderRadius: 'var(--radius-sm)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                    <p style={{ color: 'var(--text-muted)', fontSize: 13 }}>No video uploaded yet</p>
                  </div>
                )}

                {/* Hook & Script Info */}
                {reviewModal.hook_variant_text && (
                  <div style={{ marginTop: 12, padding: 10, background: 'var(--bg-tertiary)', borderRadius: 'var(--radius-sm)', borderLeft: '3px solid var(--info)' }}>
                    <div style={{ fontSize: 10, color: 'var(--info)', fontWeight: 600, textTransform: 'uppercase', marginBottom: 4 }}>Text Hook</div>
                    <p style={{ fontSize: 12, color: 'var(--text-secondary)' }}>{reviewModal.hook_variant_text}</p>
                  </div>
                )}
              </div>

              {/* Comments Panel */}
              <div style={{ width: 260, flexShrink: 0, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
                <div style={{ fontSize: 13, fontWeight: 600, marginBottom: 8, display: 'flex', alignItems: 'center', gap: 6 }}>
                  <MessageSquare size={14} /> Comments ({comments.length})
                </div>
                <div style={{ flex: 1, overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: 8 }}>
                  {comments.length === 0 ? (
                    <p style={{ fontSize: 12, color: 'var(--text-muted)', textAlign: 'center', padding: 20 }}>
                      No comments yet. Click the timestamp button and add a note.
                    </p>
                  ) : comments.map(c => (
                    <div key={c.id} style={{
                      padding: 10, background: c.is_resolved ? 'var(--bg-tertiary)' : 'var(--bg-secondary)',
                      borderRadius: 'var(--radius-sm)', border: '1px solid var(--border)',
                      opacity: c.is_resolved ? 0.5 : 1
                    }}>
                      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 4 }}>
                        <button onClick={() => seekToTimestamp(c.timestamp_seconds)}
                          style={{
                            background: 'var(--warning-bg)', color: 'var(--warning)', border: 'none',
                            borderRadius: 4, padding: '1px 6px', fontSize: 11, fontWeight: 600, cursor: 'pointer',
                            fontFamily: 'var(--font-mono)'
                          }}>
                          {formatTime(c.timestamp_seconds)}
                        </button>
                        {!c.is_resolved && (
                          <button className="btn btn-icon btn-sm" onClick={() => handleResolveComment(c.id)}
                            title="Mark resolved" style={{ color: 'var(--success)' }}>
                            <Check size={12} />
                          </button>
                        )}
                      </div>
                      <p style={{ fontSize: 12, color: 'var(--text-primary)', lineHeight: 1.4, textDecoration: c.is_resolved ? 'line-through' : 'none' }}>
                        {c.comment_text}
                      </p>
                      <div style={{ fontSize: 10, color: 'var(--text-muted)', marginTop: 4 }}>
                        {c.author_name} · {new Date(c.created_at).toLocaleString()}
                      </div>
                    </div>
                  ))}
                </div>

                {/* Quick Status Change */}
                <div style={{ marginTop: 12, paddingTop: 12, borderTop: '1px solid var(--border)', flexShrink: 0 }}>
                  <div style={{ fontSize: 10, color: 'var(--text-tertiary)', marginBottom: 4, fontWeight: 600, textTransform: 'uppercase' }}>Change Status</div>
                  <select className="form-select" style={{ fontSize: 11, padding: '4px 8px' }}
                    value={reviewModal.status}
                    onChange={async (e) => {
                      const newStatus = e.target.value;
                      await handleStatusChange(reviewModal.id, newStatus);
                      setReviewModal({ ...reviewModal, status: newStatus });
                    }}>
                    {STATUSES.map(s => <option key={s.key} value={s.key}>{s.label}</option>)}
                  </select>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default KanbanPage;
