import { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import api from '../services/api';
import { Key, Save } from 'lucide-react';

const SettingsPage = () => {
  const { user } = useAuth();
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [message, setMessage] = useState('');

  const handleChangePassword = async (e) => {
    e.preventDefault();
    if (newPassword !== confirmPassword) {
      setMessage('Passwords do not match');
      return;
    }
    try {
      await api.changePassword(currentPassword, newPassword);
      setMessage('Password changed successfully');
      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');
    } catch (err) {
      setMessage(err.message);
    }
  };

  return (
    <div className="page-content">
      <h2 style={{ fontSize: 20, fontWeight: 600, marginBottom: 20 }}>Settings</h2>

      <div className="card" style={{ maxWidth: 480 }}>
        <div className="card-header">
          <h3 className="card-title" style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <Key size={16} /> Change Password
          </h3>
        </div>

        {message && (
          <div style={{
            padding: '8px 12px', borderRadius: 'var(--radius-sm)', fontSize: 12, marginBottom: 16,
            background: message.includes('success') ? 'var(--success-bg)' : 'var(--danger-bg)',
            color: message.includes('success') ? 'var(--success)' : 'var(--danger)'
          }}>{message}</div>
        )}

        <form onSubmit={handleChangePassword}>
          <div className="form-group">
            <label className="form-label">Current Password</label>
            <input className="form-input" type="password" value={currentPassword} onChange={e => setCurrentPassword(e.target.value)} required />
          </div>
          <div className="form-group">
            <label className="form-label">New Password</label>
            <input className="form-input" type="password" value={newPassword} onChange={e => setNewPassword(e.target.value)} required />
          </div>
          <div className="form-group">
            <label className="form-label">Confirm New Password</label>
            <input className="form-input" type="password" value={confirmPassword} onChange={e => setConfirmPassword(e.target.value)} required />
          </div>
          <button type="submit" className="btn btn-primary"><Save size={14} /> Update Password</button>
        </form>
      </div>

      <div className="card" style={{ maxWidth: 480, marginTop: 16 }}>
        <div className="card-header">
          <h3 className="card-title">API Configuration</h3>
        </div>
        <p style={{ fontSize: 13, color: 'var(--text-secondary)', lineHeight: 1.6 }}>
          API keys are configured in the <code style={{ fontFamily: 'var(--font-mono)', fontSize: 12, background: 'var(--bg-tertiary)', padding: '2px 6px', borderRadius: 4 }}>.env</code> file on the server. You need:
        </p>
        <ul style={{ marginTop: 8, paddingLeft: 20, fontSize: 13, color: 'var(--text-secondary)', lineHeight: 2 }}>
          <li>Claude API key (for hook generation)</li>
          <li>ElevenLabs API key (for voiceovers)</li>
          <li>Gmail App Password (for email notifications)</li>
        </ul>
      </div>
    </div>
  );
};

export default SettingsPage;
