import { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import api from '../services/api';
import { Plus, Building2, ChevronRight, Upload, Trash2 } from 'lucide-react';

const ClientsPage = ({ onNavigate, setSelectedClient }) => {
  const { hasRole } = useAuth();
  const [clients, setClients] = useState([]);
  const [showCreate, setShowCreate] = useState(false);
  const [newClient, setNewClient] = useState({ name: '' });
  const [logoFile, setLogoFile] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => { loadClients(); }, []);

  const loadClients = async () => {
    try {
      const data = await api.getClients();
      setClients(data.clients || []);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleCreate = async (e) => {
    e.preventDefault();
    try {
      const formData = new FormData();
      formData.append('name', newClient.name);
      if (logoFile) formData.append('logo', logoFile);
      await api.createClient(formData);
      setShowCreate(false);
      setNewClient({ name: '' });
      setLogoFile(null);
      loadClients();
    } catch (err) {
      alert(err.message);
    }
  };

  const handleDeleteClient = async (e, clientId) => {
    e.stopPropagation();
    if (!confirm('Delete this client and ALL its data (folders, campaigns, deliverables)? This cannot be undone.')) return;
    try {
      await api.deleteClient(clientId);
      loadClients();
    } catch (err) { alert(err.message); }
  };

  const openClient = (client) => {
    setSelectedClient(client);
    onNavigate('client-detail');
  };

  if (loading) return <div className="page-content"><p style={{ color: 'var(--text-tertiary)' }}>Loading...</p></div>;

  return (
    <div className="page-content">
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 20 }}>
        <h2 style={{ fontSize: 20, fontWeight: 600 }}>Client Portals</h2>
        {hasRole('admin') && (
          <button className="btn btn-primary" onClick={() => setShowCreate(true)}>
            <Plus size={16} /> New Client
          </button>
        )}
      </div>

      {clients.length === 0 ? (
        <div className="empty-state">
          <Building2 />
          <h3>No clients yet</h3>
          <p>Create your first client portal to get started</p>
        </div>
      ) : (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: 16 }}>
          {clients.map(client => {
            const total = parseInt(client.total_deliverables) || 0;
            const completed = parseInt(client.completed_deliverables) || 0;
            const pct = total > 0 ? (completed / total) * 100 : 0;

            return (
              <div key={client.id} className="card" style={{ cursor: 'pointer', transition: 'border-color 0.15s' }}
                onClick={() => openClient(client)}
                onMouseEnter={e => e.currentTarget.style.borderColor = 'var(--accent-primary)'}
                onMouseLeave={e => e.currentTarget.style.borderColor = 'var(--border)'}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 12 }}>
                  {client.logo_url
                    ? <img src={client.logo_url} className="client-logo" />
                    : <div className="client-logo-placeholder">{client.name[0]}</div>}
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: 15, fontWeight: 600 }}>{client.name}</div>
                    <div style={{ fontSize: 12, color: 'var(--text-tertiary)' }}>{completed}/{total} deliverables</div>
                  </div>
                  {hasRole('admin') && (
                    <button className="btn btn-danger btn-sm" onClick={(e) => handleDeleteClient(e, client.id)} title="Delete client" style={{ marginLeft: 4 }}>
                      <Trash2 size={12} />
                    </button>
                  )}
                  <ChevronRight size={18} style={{ color: 'var(--text-tertiary)' }} />
                </div>
                <div className="progress-bar">
                  <div className="progress-fill" style={{ width: `${pct}%` }} />
                </div>
              </div>
            );
          })}
        </div>
      )}

      {showCreate && (
        <div className="modal-overlay" onClick={() => setShowCreate(false)}>
          <div className="modal" onClick={e => e.stopPropagation()}>
            <h3 className="modal-title">Create Client Portal</h3>
            <form onSubmit={handleCreate}>
              <div className="form-group">
                <label className="form-label">Client Name</label>
                <input className="form-input" value={newClient.name} onChange={e => setNewClient({ name: e.target.value })} required placeholder="e.g., Burger Palace" />
              </div>
              <div className="form-group">
                <label className="form-label">Logo</label>
                <div style={{ border: '1px dashed var(--border-light)', borderRadius: 'var(--radius-sm)', padding: 20, textAlign: 'center', cursor: 'pointer' }}
                  onClick={() => document.getElementById('logo-upload').click()}>
                  <Upload size={20} style={{ color: 'var(--text-tertiary)', marginBottom: 6 }} />
                  <p style={{ fontSize: 12, color: 'var(--text-tertiary)' }}>
                    {logoFile ? logoFile.name : 'Click to upload logo'}
                  </p>
                  <input id="logo-upload" type="file" accept="image/*" hidden onChange={e => setLogoFile(e.target.files[0])} />
                </div>
              </div>
              <div className="modal-actions">
                <button type="button" className="btn btn-secondary" onClick={() => setShowCreate(false)}>Cancel</button>
                <button type="submit" className="btn btn-primary">Create Portal</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default ClientsPage;
