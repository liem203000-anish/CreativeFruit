import { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import api from '../services/api';
import { Plus, Anchor, Tag, Trash2, Edit2 } from 'lucide-react';

const EMPTY_FORM = { name: '', hook_text: '', menu_items: [] };

const HooksPage = () => {
  const { hasRole } = useAuth();
  const [hooks, setHooks] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [editingHook, setEditingHook] = useState(null);
  const [form, setForm] = useState({ ...EMPTY_FORM });
  const [menuInput, setMenuInput] = useState('');

  useEffect(() => { loadHooks(); }, []);

  const loadHooks = async () => {
    try {
      const data = await api.getHooks();
      setHooks(data.hooks || []);
    } catch (err) { console.error(err); }
  };

  const addMenuItem = () => {
    if (menuInput.trim()) {
      setForm({ ...form, menu_items: [...form.menu_items, menuInput.trim()] });
      setMenuInput('');
    }
  };

  const removeMenuItem = (idx) => {
    setForm({ ...form, menu_items: form.menu_items.filter((_, i) => i !== idx) });
  };

  const openCreate = () => {
    setEditingHook(null);
    setForm({ ...EMPTY_FORM });
    setMenuInput('');
    setShowModal(true);
  };

  const openEdit = (h) => {
    setEditingHook(h);
    setForm({ name: h.name, hook_text: h.hook_text, menu_items: h.menu_items || [] });
    setMenuInput('');
    setShowModal(true);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (editingHook) {
        await api.updateHook(editingHook.id, form);
      } else {
        await api.createHook(form);
      }
      setShowModal(false);
      setEditingHook(null);
      setForm({ ...EMPTY_FORM });
      loadHooks();
    } catch (err) { alert(err.message); }
  };

  const handleDeleteHook = async (id) => {
    if (!confirm('Delete this hook?')) return;
    try { await api.deleteHook(id); loadHooks(); } catch(err) { alert(err.message); }
  };

  const getScoreClass = (score) => {
    const s = parseFloat(score) || 0;
    if (s >= 70) return 'score-high';
    if (s >= 40) return 'score-mid';
    return 'score-low';
  };

  return (
    <div className="page-content">
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 20 }}>
        <h2 style={{ fontSize: 20, fontWeight: 600 }}>Hook Library</h2>
        {hasRole('admin', 'project_manager', 'lead_editor') && (
          <button className="btn btn-primary" onClick={openCreate}>
            <Plus size={16} /> New Hook
          </button>
        )}
      </div>

      {hooks.length === 0 ? (
        <div className="empty-state"><Anchor /><h3>No hooks yet</h3><p>Add your first parent hook to the library</p></div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          {hooks.map(h => (
            <div key={h.id} className="card" style={{ display: 'flex', alignItems: 'flex-start', gap: 16 }}>
              <div className={`score-badge ${getScoreClass(h.score)}`} style={{ flexShrink: 0 }}>
                {Math.round(parseFloat(h.score) || 0)}
              </div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <h4 style={{ fontSize: 14, fontWeight: 600 }}>{h.name}</h4>
                <p style={{ fontSize: 13, color: 'var(--text-secondary)', marginTop: 4, lineHeight: 1.5 }}>{h.hook_text}</p>
                {h.menu_items?.length > 0 && (
                  <div style={{ display: 'flex', gap: 6, marginTop: 8, flexWrap: 'wrap' }}>
                    {h.menu_items.map((item, i) => (
                      <span key={i} style={{
                        fontSize: 11, padding: '3px 10px',
                        background: 'var(--warning-bg)', color: 'var(--warning)',
                        borderRadius: 12, display: 'flex', alignItems: 'center', gap: 4
                      }}>
                        <Tag size={10} /> {item}
                      </span>
                    ))}
                  </div>
                )}
                <div style={{ display: 'flex', gap: 8, marginTop: 10, fontSize: 11, color: 'var(--text-tertiary)', alignItems: 'center' }}>
                  <span>Used {h.usage_count || h.times_used || 0} times</span>
                  {h.avg_3s_retention > 0 && <span>3s retention: {(parseFloat(h.avg_3s_retention) * 100).toFixed(1)}%</span>}
                  {h.avg_engagement > 0 && <span>Engagement: {(parseFloat(h.avg_engagement) * 100).toFixed(2)}%</span>}
                  {hasRole('admin', 'project_manager', 'lead_editor') && (
                    <div style={{ marginLeft: 'auto', display: 'flex', gap: 4 }}>
                      <button className="btn btn-secondary btn-sm" onClick={() => openEdit(h)} style={{ fontSize: 10 }}>
                        <Edit2 size={10} /> Edit
                      </button>
                      <button className="btn btn-danger btn-sm" onClick={() => handleDeleteHook(h.id)} style={{ fontSize: 10 }}>
                        <Trash2 size={10} />
                      </button>
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {showModal && (
        <div className="modal-overlay" onClick={() => setShowModal(false)}>
          <div className="modal" onClick={e => e.stopPropagation()}>
            <h3 className="modal-title">{editingHook ? 'Edit Hook' : 'Add Parent Hook'}</h3>
            <form onSubmit={handleSubmit}>
              <div className="form-group">
                <label className="form-label">Hook Name</label>
                <input className="form-input" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} required placeholder="e.g., FOMO Food Hook" />
              </div>
              <div className="form-group">
                <label className="form-label">Hook Text</label>
                <textarea className="form-textarea" value={form.hook_text} onChange={e => setForm({ ...form, hook_text: e.target.value })} required
                  placeholder="e.g., You haven't lived until you've tried the [menu item] at [restaurant]" />
              </div>
              <div className="form-group">
                <label className="form-label">Menu Items to Highlight</label>
                <div style={{ display: 'flex', gap: 8 }}>
                  <input className="form-input" value={menuInput} onChange={e => setMenuInput(e.target.value)}
                    placeholder="e.g., Smash Burger" onKeyDown={e => { if (e.key === 'Enter') { e.preventDefault(); addMenuItem(); }}} />
                  <button type="button" className="btn btn-secondary" onClick={addMenuItem}>Add</button>
                </div>
                {form.menu_items.length > 0 && (
                  <div style={{ display: 'flex', gap: 6, marginTop: 8, flexWrap: 'wrap' }}>
                    {form.menu_items.map((item, i) => (
                      <span key={i} style={{
                        fontSize: 12, padding: '4px 10px', background: 'var(--warning-bg)',
                        color: 'var(--warning)', borderRadius: 12, cursor: 'pointer',
                        display: 'flex', alignItems: 'center', gap: 4
                      }} onClick={() => removeMenuItem(i)}>
                        {item} ×
                      </span>
                    ))}
                  </div>
                )}
              </div>
              <div className="modal-actions">
                <button type="button" className="btn btn-secondary" onClick={() => setShowModal(false)}>Cancel</button>
                <button type="submit" className="btn btn-primary">{editingHook ? 'Save Changes' : 'Add Hook'}</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default HooksPage;
