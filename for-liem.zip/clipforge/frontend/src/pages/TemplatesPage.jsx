import { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import api from '../services/api';
import { Plus, Layers, Upload, Mic, Download, Trash2, Edit2 } from 'lucide-react';

const EMPTY_FORM = { code: '', name: '', description: '', ideal_use_case: '', font_name: '', font_style: '', text_position: '', has_voiceover: 'false' };

const TemplatesPage = () => {
  const { hasRole } = useAuth();
  const [templates, setTemplates] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [editingTemplate, setEditingTemplate] = useState(null);
  const [form, setForm] = useState({ ...EMPTY_FORM });
  const [photoFile, setPhotoFile] = useState(null);
  const [fontFile, setFontFile] = useState(null);

  useEffect(() => { loadTemplates(); }, []);

  const loadTemplates = async () => {
    try {
      const data = await api.getTemplates();
      setTemplates(data.templates || []);
    } catch (err) { console.error(err); }
  };

  const openCreate = () => {
    setEditingTemplate(null);
    setForm({ ...EMPTY_FORM });
    setPhotoFile(null);
    setFontFile(null);
    setShowModal(true);
  };

  const openEdit = (e, t) => {
    e.stopPropagation();
    setEditingTemplate(t);
    setForm({
      code: t.code || '',
      name: t.name || '',
      description: t.description || '',
      ideal_use_case: t.ideal_use_case || '',
      font_name: t.font_name || '',
      font_style: t.font_style || '',
      text_position: t.text_position || '',
      has_voiceover: t.has_voiceover ? 'true' : 'false',
    });
    setPhotoFile(null);
    setFontFile(null);
    setShowModal(true);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const formData = new FormData();
      Object.entries(form).forEach(([k, v]) => formData.append(k, v));
      if (photoFile) formData.append('photo_reference', photoFile);
      if (fontFile) formData.append('font_file', fontFile);

      if (editingTemplate) {
        await api.updateTemplate(editingTemplate.id, formData);
      } else {
        await api.createTemplate(formData);
      }
      setShowModal(false);
      setEditingTemplate(null);
      setForm({ ...EMPTY_FORM });
      setPhotoFile(null);
      setFontFile(null);
      loadTemplates();
    } catch (err) { alert(err.message); }
  };

  const handleDeleteTemplate = async (e, id) => {
    e.stopPropagation();
    if (!confirm('Delete this template? This cannot be undone.')) return;
    try { await api.deleteTemplate(id); loadTemplates(); } catch (err) { alert(err.message); }
  };

  const getScoreClass = (score) => {
    const s = parseFloat(score) || 0;
    if (s >= 70) return 'score-high';
    if (s >= 40) return 'score-mid';
    return 'score-low';
  };

  return (
    <div className="page-content">
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 20 }}>
        <h2 style={{ fontSize: 20, fontWeight: 600 }}>Template Registry</h2>
        {hasRole('admin', 'project_manager', 'lead_editor') && (
          <button className="btn btn-primary" onClick={openCreate}>
            <Plus size={16} /> New Template
          </button>
        )}
      </div>

      {templates.length === 0 ? (
        <div className="empty-state"><Layers /><h3>No templates yet</h3><p>Create your first template entry</p></div>
      ) : (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(260px, 1fr))', gap: 16 }}>
          {templates.map(t => (
            <div key={t.id} className="card">
              {t.photo_reference_url && (
                <img src={t.photo_reference_url} style={{ width: '100%', aspectRatio: '9/16', objectFit: 'cover', borderRadius: 'var(--radius-sm)', marginBottom: 12 }} />
              )}
              <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between' }}>
                <div>
                  <span style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--accent-primary)', fontWeight: 600 }}>{t.code}</span>
                  <h4 style={{ fontSize: 14, fontWeight: 600, marginTop: 2 }}>{t.name}</h4>
                </div>
                <div className={`score-badge ${getScoreClass(t.score)}`}>{Math.round(parseFloat(t.score) || 0)}</div>
              </div>
              <div style={{ display: 'flex', gap: 6, marginTop: 10, flexWrap: 'wrap' }}>
                {t.font_name && (
                  <span style={{ fontSize: 10, padding: '2px 8px', background: 'var(--bg-tertiary)', borderRadius: 12, color: 'var(--text-secondary)' }}>
                    {t.font_name}
                  </span>
                )}
                {t.has_voiceover && (
                  <span style={{ fontSize: 10, padding: '2px 8px', background: 'rgba(124, 92, 252, 0.1)', borderRadius: 12, color: 'var(--accent-primary)', display: 'flex', alignItems: 'center', gap: 3 }}>
                    <Mic size={10} /> Voiceover
                  </span>
                )}
                {t.font_file_url && (
                  <a href={t.font_file_url} download={t.font_file_name} style={{ fontSize: 10, padding: '2px 8px', background: 'var(--bg-tertiary)', borderRadius: 12, color: 'var(--info)', textDecoration: 'none', display: 'flex', alignItems: 'center', gap: 3 }}
                    onClick={e => e.stopPropagation()}>
                    <Download size={10} /> Font File
                  </a>
                )}
              </div>
              {t.text_position && (
                <div style={{ fontSize: 10, color: 'var(--text-tertiary)', marginTop: 6 }}>Position: {t.text_position}</div>
              )}
              <div style={{ fontSize: 11, color: 'var(--text-tertiary)', marginTop: 6 }}>
                Used {t.usage_count || t.times_used || 0} times
              </div>
              {t.description && <p style={{ fontSize: 12, color: 'var(--text-secondary)', marginTop: 6, lineHeight: 1.4 }}>{t.description}</p>}
              {hasRole('admin', 'project_manager', 'lead_editor') && (
                <div style={{ display: 'flex', gap: 6, marginTop: 10 }}>
                  <button className="btn btn-secondary btn-sm" style={{ fontSize: 10, flex: 1 }} onClick={(e) => openEdit(e, t)}>
                    <Edit2 size={10} /> Edit
                  </button>
                  <button className="btn btn-danger btn-sm" style={{ fontSize: 10 }} onClick={(e) => handleDeleteTemplate(e, t.id)}>
                    <Trash2 size={10} />
                  </button>
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {showModal && (
        <div className="modal-overlay" onClick={() => setShowModal(false)}>
          <div className="modal" onClick={e => e.stopPropagation()} style={{ maxWidth: 580 }}>
            <h3 className="modal-title">{editingTemplate ? 'Edit Template' : 'Register New Template'}</h3>
            <form onSubmit={handleSubmit}>
              <div className="grid-2">
                <div className="form-group">
                  <label className="form-label">Template Code</label>
                  <input className="form-input" value={form.code} onChange={e => setForm({ ...form, code: e.target.value })} required placeholder="e.g., T-001" />
                </div>
                <div className="form-group">
                  <label className="form-label">Name</label>
                  <input className="form-input" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} required placeholder="e.g., Fast Zoom Testimonial" />
                </div>
              </div>
              <div className="form-group">
                <label className="form-label">Description</label>
                <textarea className="form-textarea" value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} placeholder="What this template looks like..." />
              </div>
              <div className="form-group">
                <label className="form-label">Ideal Use Case</label>
                <input className="form-input" value={form.ideal_use_case} onChange={e => setForm({ ...form, ideal_use_case: e.target.value })} placeholder="Best for food reveals, testimonials, etc." />
              </div>
              <div className="grid-2">
                <div className="form-group">
                  <label className="form-label">Font Name</label>
                  <input className="form-input" value={form.font_name} onChange={e => setForm({ ...form, font_name: e.target.value })} placeholder="e.g., Montserrat Bold" />
                </div>
                <div className="form-group">
                  <label className="form-label">Text Position</label>
                  <select className="form-select" value={form.text_position} onChange={e => setForm({ ...form, text_position: e.target.value })}>
                    <option value="">Not set</option>
                    <option value="top">Top</option>
                    <option value="center">Center</option>
                    <option value="bottom">Bottom</option>
                    <option value="top-left">Top Left</option>
                    <option value="top-right">Top Right</option>
                    <option value="bottom-left">Bottom Left</option>
                    <option value="bottom-right">Bottom Right</option>
                  </select>
                </div>
              </div>
              <div className="form-group">
                <label className="form-label">Font File (for editors to download)</label>
                <div style={{ border: '1px dashed var(--border-light)', borderRadius: 'var(--radius-sm)', padding: 12, textAlign: 'center', cursor: 'pointer' }}
                  onClick={() => document.getElementById('font-file-upload').click()}>
                  <p style={{ fontSize: 12, color: 'var(--text-tertiary)' }}>
                    {fontFile ? fontFile.name : editingTemplate?.font_file_name ? `Current: ${editingTemplate.font_file_name} (click to replace)` : 'Upload font file (.zip, .ttf, .otf, .woff2)'}
                  </p>
                  <input id="font-file-upload" type="file" accept=".zip,.ttf,.otf,.woff,.woff2" hidden onChange={e => setFontFile(e.target.files[0])} />
                </div>
              </div>
              <div className="form-group">
                <label className="form-label">Has Voiceover?</label>
                <select className="form-select" value={form.has_voiceover} onChange={e => setForm({ ...form, has_voiceover: e.target.value })}>
                  <option value="false">No</option>
                  <option value="true">Yes</option>
                </select>
              </div>
              <div className="form-group">
                <label className="form-label">Photo Reference</label>
                <div style={{ border: '1px dashed var(--border-light)', borderRadius: 'var(--radius-sm)', padding: 16, textAlign: 'center', cursor: 'pointer' }}
                  onClick={() => document.getElementById('template-photo').click()}>
                  <Upload size={18} style={{ color: 'var(--text-tertiary)' }} />
                  <p style={{ fontSize: 12, color: 'var(--text-tertiary)', marginTop: 4 }}>
                    {photoFile ? photoFile.name : editingTemplate?.photo_reference_url ? 'Click to replace current photo' : 'Upload screenshot'}
                  </p>
                  <input id="template-photo" type="file" accept="image/*" hidden onChange={e => setPhotoFile(e.target.files[0])} />
                </div>
                {!photoFile && editingTemplate?.photo_reference_url && (
                  <img src={editingTemplate.photo_reference_url}
                    style={{ width: '100%', aspectRatio: '9/16', objectFit: 'cover', borderRadius: 'var(--radius-sm)', marginTop: 8 }} />
                )}
              </div>
              <div className="modal-actions">
                <button type="button" className="btn btn-secondary" onClick={() => setShowModal(false)}>Cancel</button>
                <button type="submit" className="btn btn-primary">{editingTemplate ? 'Save Changes' : 'Register Template'}</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default TemplatesPage;
