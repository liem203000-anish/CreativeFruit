import { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import api from '../services/api';
import { BarChart3, Users, FolderOpen, FileVideo, Layers, TrendingUp, AlertCircle, X, Download, Upload, Volume2, Type } from 'lucide-react';

const DashboardPage = () => {
  const { user } = useAuth();
  const [stats, setStats] = useState(null);
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedTask, setSelectedTask] = useState(null);

  useEffect(() => {
    const load = async () => {
      try {
        if (user.role === 'editor') {
          const data = await api.getMyTasks();
          setTasks(data.deliverables || []);
        } else {
          const data = await api.getOverview();
          setStats(data.stats);
        }
      } catch (err) {
        console.error('Dashboard load error:', err);
      } finally {
        setLoading(false);
      }
    };
    load();
  }, [user]);

  const handleStatusChange = async (id, status) => {
    try {
      await api.updateDeliverable(id, { status });
      const data = await api.getMyTasks();
      setTasks(data.deliverables || []);
      if (selectedTask?.id === id) setSelectedTask(prev => ({ ...prev, status }));
    } catch (err) { alert(err.message); }
  };

  const handleUploadVideo = async (id, file) => {
    try {
      const formData = new FormData();
      formData.append('video', file);
      await api.uploadVideo(id, formData);
      const data = await api.getMyTasks();
      setTasks(data.deliverables || []);
      const updated = data.deliverables.find(d => d.id === id);
      if (updated && selectedTask?.id === id) setSelectedTask(updated);
    } catch (err) { alert(err.message); }
  };

  if (loading) return <div className="page-content"><p style={{ color: 'var(--text-tertiary)' }}>Loading...</p></div>;

  // Editor view
  if (user.role === 'editor') {
    const pending = tasks.filter(t => ['get_started', 'in_progress', 'revision'].includes(t.status));
    const inReview = tasks.filter(t => t.status === 'review');
    const done = tasks.filter(t => ['approved', 'scheduled', 'posted'].includes(t.status));

    return (
      <div className="page-content">
        <h2 style={{ fontSize: 20, fontWeight: 600, marginBottom: 20 }}>My Tasks</h2>
        <div className="stat-grid">
          <div className="stat-card">
            <div className="stat-label">To Do</div>
            <div className="stat-value" style={{ color: 'var(--warning)' }}>{pending.length}</div>
          </div>
          <div className="stat-card">
            <div className="stat-label">In Review</div>
            <div className="stat-value" style={{ color: 'var(--accent-primary)' }}>{inReview.length}</div>
          </div>
          <div className="stat-card">
            <div className="stat-label">Completed</div>
            <div className="stat-value" style={{ color: 'var(--success)' }}>{done.length}</div>
          </div>
        </div>

        {pending.length > 0 && (
          <div className="card" style={{ marginBottom: 16 }}>
            <div className="card-header">
              <h3 className="card-title" style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                <AlertCircle size={16} style={{ color: 'var(--warning)' }} /> Action Required
              </h3>
            </div>
            <div className="table-container">
              <table className="data-table">
                <thead>
                  <tr>
                    <th>Client</th>
                    <th>Template</th>
                    <th>Variant</th>
                    <th>Status</th>
                    <th>Hook</th>
                  </tr>
                </thead>
                <tbody>
                  {pending.map(t => (
                    <tr key={t.id} onClick={() => setSelectedTask(t)} style={{ cursor: 'pointer' }}>
                      <td style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                        {t.client_logo
                          ? <img src={t.client_logo} className="client-logo" style={{ width: 28, height: 28 }} />
                          : <div className="client-logo-placeholder" style={{ width: 28, height: 28, fontSize: 12 }}>{t.client_name?.[0]}</div>}
                        {t.client_name}
                      </td>
                      <td><span style={{ fontFamily: 'var(--font-mono)', fontSize: 12 }}>{t.template_code}</span> {t.template_name}</td>
                      <td>{t.variant_number === 0 ? 'Parent' : `V${t.variant_number}`}</td>
                      <td><span className={`status-badge status-${t.status}`}>{t.status.replace('_', ' ')}</span></td>
                      <td style={{ maxWidth: 200, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{t.hook_variant_text || '—'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {done.length > 0 && (
          <div className="card">
            <div className="card-header">
              <h3 className="card-title" style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                <TrendingUp size={16} style={{ color: 'var(--success)' }} /> Completed
              </h3>
            </div>
            <div className="table-container">
              <table className="data-table">
                <thead>
                  <tr>
                    <th>Client</th>
                    <th>Template</th>
                    <th>Variant</th>
                    <th>Status</th>
                  </tr>
                </thead>
                <tbody>
                  {done.map(t => (
                    <tr key={t.id} onClick={() => setSelectedTask(t)} style={{ cursor: 'pointer' }}>
                      <td>{t.client_name}</td>
                      <td><span style={{ fontFamily: 'var(--font-mono)', fontSize: 12 }}>{t.template_code}</span> {t.template_name}</td>
                      <td>{t.variant_number === 0 ? 'Parent' : `V${t.variant_number}`}</td>
                      <td><span className={`status-badge status-${t.status}`}>{t.status.replace('_', ' ')}</span></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Task Detail Popup */}
        {selectedTask && (
          <div className="modal-overlay" onClick={() => setSelectedTask(null)}>
            <div className="modal" onClick={e => e.stopPropagation()} style={{ maxWidth: 650, maxHeight: '90vh', overflow: 'auto' }}>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16 }}>
                <div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                    <span style={{ fontFamily: 'var(--font-mono)', fontSize: 12, color: 'var(--accent-primary)', fontWeight: 600 }}>{selectedTask.template_code}</span>
                    <span style={{ fontSize: 16, fontWeight: 600 }}>{selectedTask.template_name}</span>
                    <span style={{ fontSize: 12, padding: '2px 8px', background: 'var(--accent-glow)', color: 'var(--accent-primary)', borderRadius: 10, fontWeight: 600 }}>
                      {selectedTask.variant_number === 0 ? 'Parent' : `V${selectedTask.variant_number}`}
                    </span>
                  </div>
                  <p style={{ fontSize: 12, color: 'var(--text-tertiary)', marginTop: 4 }}>{selectedTask.client_name} · {selectedTask.campaign_name}</p>
                </div>
                <button className="btn btn-icon" onClick={() => setSelectedTask(null)}><X size={18} /></button>
              </div>

              {/* Text Hook */}
              {selectedTask.hook_variant_text && (
                <div style={{ background: 'var(--bg-tertiary)', borderRadius: 'var(--radius-sm)', padding: 12, marginBottom: 12, borderLeft: '3px solid var(--info)' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 4, marginBottom: 6 }}>
                    <Type size={12} style={{ color: 'var(--info)' }} />
                    <span style={{ fontSize: 10, color: 'var(--info)', fontWeight: 600, textTransform: 'uppercase' }}>Text Hook (On Screen)</span>
                  </div>
                  <p style={{ fontSize: 14, fontWeight: 500, color: 'var(--text-primary)', lineHeight: 1.5 }}>{selectedTask.hook_variant_text}</p>
                </div>
              )}

              {/* Voiceover Script */}
              {(selectedTask.voiceover_hook || selectedTask.voiceover_script) && (
                <div style={{ background: 'var(--bg-tertiary)', borderRadius: 'var(--radius-sm)', padding: 12, marginBottom: 12, borderLeft: '3px solid var(--accent-primary)' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 4, marginBottom: 6 }}>
                    <Volume2 size={12} style={{ color: 'var(--accent-primary)' }} />
                    <span style={{ fontSize: 10, color: 'var(--accent-primary)', fontWeight: 600, textTransform: 'uppercase' }}>Voiceover Script</span>
                  </div>
                  {selectedTask.voiceover_hook ? (
                    <div>
                      <div style={{ marginBottom: 6 }}>
                        <span style={{ fontSize: 9, color: 'var(--warning)', fontWeight: 600, textTransform: 'uppercase' }}>Hook:</span>
                        <p style={{ fontSize: 13, color: 'var(--text-primary)', fontWeight: 500, marginTop: 2 }}>"{selectedTask.voiceover_hook}"</p>
                      </div>
                      {selectedTask.voiceover_body && (
                        <div>
                          <span style={{ fontSize: 9, color: 'var(--text-tertiary)', fontWeight: 600, textTransform: 'uppercase' }}>Body:</span>
                          <p style={{ fontSize: 12, color: 'var(--text-secondary)', lineHeight: 1.5, marginTop: 2 }}>"{selectedTask.voiceover_body}"</p>
                        </div>
                      )}
                    </div>
                  ) : (
                    <p style={{ fontSize: 12, color: 'var(--text-secondary)', lineHeight: 1.5 }}>"{selectedTask.voiceover_script}"</p>
                  )}
                </div>
              )}

              {/* Voiceover Audio */}
              {selectedTask.voiceover_url && (
                <div style={{ marginBottom: 12 }}>
                  <div style={{ fontSize: 10, color: 'var(--text-tertiary)', fontWeight: 600, textTransform: 'uppercase', marginBottom: 4 }}>Voiceover Audio</div>
                  <audio controls src={selectedTask.voiceover_url} style={{ width: '100%', height: 36 }} />
                  <a href={selectedTask.voiceover_url} download className="btn btn-secondary btn-sm" style={{ marginTop: 6, fontSize: 10 }}>
                    <Download size={10} /> Download Audio
                  </a>
                </div>
              )}

              {/* Template Preview */}
              {(selectedTask.photo_reference_url || selectedTask.template_name) && (
                <div style={{ background: 'var(--bg-tertiary)', borderRadius: 'var(--radius-sm)', padding: 12, marginBottom: 12, borderLeft: '3px solid var(--warning)' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 4, marginBottom: 6 }}>
                    <span style={{ fontSize: 10, color: 'var(--warning)', fontWeight: 600, textTransform: 'uppercase' }}>Template Reference</span>
                  </div>
                  <div style={{ display: 'flex', gap: 12, alignItems: 'flex-start' }}>
                    {selectedTask.photo_reference_url && (
                      <img src={selectedTask.photo_reference_url} style={{ width: 120, height: 160, objectFit: 'cover', borderRadius: 'var(--radius-sm)', border: '1px solid var(--border)' }} />
                    )}
                    <div style={{ fontSize: 12, color: 'var(--text-secondary)' }}>
                      <p style={{ fontWeight: 600 }}>{selectedTask.template_name}</p>
                      <p style={{ fontSize: 11, color: 'var(--accent-primary)', fontFamily: 'var(--font-mono)' }}>{selectedTask.template_code}</p>
                      {selectedTask.font_name && <p style={{ marginTop: 6 }}>Font: {selectedTask.font_name}</p>}
                      {selectedTask.text_position && <p>Position: {selectedTask.text_position}</p>}
                      {selectedTask.has_voiceover && <p style={{ color: 'var(--accent-primary)', marginTop: 4 }}>🎙 Voiceover Required</p>}
                    </div>
                  </div>
                </div>
              )}

              {/* Sub Text */}
              {selectedTask.sub_text && (
                <div style={{ background: 'var(--bg-tertiary)', borderRadius: 'var(--radius-sm)', padding: 12, marginBottom: 12 }}>
                  <div style={{ fontSize: 10, color: 'var(--text-tertiary)', fontWeight: 600, textTransform: 'uppercase', marginBottom: 4 }}>Sub Text</div>
                  <p style={{ fontSize: 13, color: 'var(--text-secondary)' }}>{selectedTask.sub_text}</p>
                </div>
              )}

              {/* Main Script */}
              {selectedTask.main_script && (
                <div style={{ background: 'var(--bg-tertiary)', borderRadius: 'var(--radius-sm)', padding: 12, marginBottom: 12 }}>
                  <div style={{ fontSize: 10, color: 'var(--text-tertiary)', fontWeight: 600, textTransform: 'uppercase', marginBottom: 4 }}>Main Script (Editor Guide)</div>
                  <p style={{ fontSize: 12, color: 'var(--text-secondary)', lineHeight: 1.6 }}>{selectedTask.main_script}</p>
                </div>
              )}

              {/* Status */}
              <div style={{ marginBottom: 12 }}>
                <div style={{ fontSize: 10, color: 'var(--text-tertiary)', fontWeight: 600, textTransform: 'uppercase', marginBottom: 4 }}>Status</div>
                <select className="form-select" value={selectedTask.status} onChange={e => handleStatusChange(selectedTask.id, e.target.value)}>
                  <option value="get_started">Get Started</option>
                  <option value="in_progress">In Progress</option>
                  <option value="review">Review</option>
                </select>
              </div>

              {/* Video Upload */}
              <div>
                <div style={{ fontSize: 10, color: 'var(--text-tertiary)', fontWeight: 600, textTransform: 'uppercase', marginBottom: 4 }}>Video</div>
                {selectedTask.video_url ? (
                  <div>
                    <video src={selectedTask.video_url} controls style={{ width: '100%', borderRadius: 'var(--radius-sm)', maxHeight: 300 }} />
                    <p style={{ fontSize: 10, color: 'var(--text-tertiary)', marginTop: 4 }}>{selectedTask.video_filename}</p>
                  </div>
                ) : (
                  <div style={{ border: '1px dashed var(--border-light)', borderRadius: 'var(--radius-sm)', padding: 20, textAlign: 'center', cursor: 'pointer' }}
                    onClick={() => document.getElementById('task-video-upload').click()}>
                    <Upload size={20} style={{ color: 'var(--text-tertiary)' }} />
                    <p style={{ fontSize: 12, color: 'var(--text-tertiary)', marginTop: 6 }}>Click to upload your finished video</p>
                    <input id="task-video-upload" type="file" accept="video/*" hidden
                      onChange={e => { if (e.target.files[0]) handleUploadVideo(selectedTask.id, e.target.files[0]); }} />
                  </div>
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    );
  }

  // Admin / PM / Lead view
  return (
    <div className="page-content">
      <h2 style={{ fontSize: 20, fontWeight: 600, marginBottom: 20 }}>Dashboard</h2>

      <div className="stat-grid">
        <div className="stat-card">
          <div className="stat-label">Clients</div>
          <div className="stat-value">{stats?.total_clients || 0}</div>
        </div>
        <div className="stat-card">
          <div className="stat-label">Deliverables</div>
          <div className="stat-value">{stats?.total_deliverables || 0}</div>
          <div className="stat-sub">{stats?.posted_deliverables || 0} posted</div>
        </div>
        <div className="stat-card">
          <div className="stat-label">Active Editors</div>
          <div className="stat-value">{stats?.active_editors || 0}</div>
        </div>
        <div className="stat-card">
          <div className="stat-label">Templates</div>
          <div className="stat-value">{stats?.total_templates || 0}</div>
        </div>
        <div className="stat-card">
          <div className="stat-label">Hooks</div>
          <div className="stat-value">{stats?.total_hooks || 0}</div>
        </div>
      </div>

      {stats?.deliverables_by_status && (
        <div className="card" style={{ marginBottom: 16 }}>
          <div className="card-header">
            <h3 className="card-title">Pipeline Status</h3>
          </div>
          <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
            {Object.entries(stats.deliverables_by_status).map(([status, count]) => (
              <div key={status} style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                <span className={`status-badge status-${status}`}>{status.replace('_', ' ')}</span>
                <span style={{ fontSize: 14, fontWeight: 600 }}>{count}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="grid-2">
        {stats?.top_template && (
          <div className="card">
            <div className="card-header">
              <h3 className="card-title" style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                <TrendingUp size={16} style={{ color: 'var(--success)' }} /> Top Template
              </h3>
            </div>
            <p style={{ fontSize: 16, fontWeight: 600 }}>{stats.top_template.name}</p>
            <p style={{ fontSize: 12, color: 'var(--text-tertiary)', fontFamily: 'var(--font-mono)' }}>{stats.top_template.code}</p>
            <p style={{ fontSize: 13, color: 'var(--success)', marginTop: 8 }}>Score: {Math.round(stats.top_template.score)}/100</p>
          </div>
        )}
        {stats?.top_hook && (
          <div className="card">
            <div className="card-header">
              <h3 className="card-title" style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                <TrendingUp size={16} style={{ color: 'var(--success)' }} /> Top Hook
              </h3>
            </div>
            <p style={{ fontSize: 16, fontWeight: 600 }}>{stats.top_hook.name}</p>
            <p style={{ fontSize: 13, color: 'var(--success)', marginTop: 8 }}>Score: {Math.round(stats.top_hook.score)}/100</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default DashboardPage;
