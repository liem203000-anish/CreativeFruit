import { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import api from '../services/api';
import { Plus, Key, UserX, Edit2, Trash2 } from 'lucide-react';

const UsersPage = () => {
  const { user: currentUser } = useAuth();
  const [users, setUsers] = useState([]);
  const [showCreate, setShowCreate] = useState(false);
  const [showReset, setShowReset] = useState(null);
  const [editingUser, setEditingUser] = useState(null);
  const [newUser, setNewUser] = useState({ username: '', email: '', password: '', full_name: '', role: 'editor' });
  const [newPassword, setNewPassword] = useState('');

  useEffect(() => { loadUsers(); }, []);

  const loadUsers = async () => {
    try {
      const data = await api.getUsers();
      setUsers(data.users || []);
    } catch (err) { console.error(err); }
  };

  const handleCreate = async (e) => {
    e.preventDefault();
    try {
      await api.createUser(newUser);
      setShowCreate(false);
      setNewUser({ username: '', email: '', password: '', full_name: '', role: 'editor' });
      loadUsers();
    } catch (err) { alert(err.message); }
  };

  const handleEditRole = async (e) => {
    e.preventDefault();
    try {
      await api.updateUser(editingUser.id, { role: editingUser.role, full_name: editingUser.full_name, email: editingUser.email });
      setEditingUser(null);
      loadUsers();
    } catch (err) { alert(err.message); }
  };

  const handleReset = async (e) => {
    e.preventDefault();
    try {
      await api.resetPassword(showReset.id, newPassword);
      setShowReset(null);
      setNewPassword('');
      alert('Password reset successfully');
    } catch (err) { alert(err.message); }
  };

  const handleDeactivate = async (id) => {
    if (!confirm('Deactivate this user?')) return;
    try {
      await api.deleteUser(id);
      loadUsers();
    } catch (err) { alert(err.message); }
  };

  const handleReactivate = async (id) => {
    try {
      await api.updateUser(id, { is_active: true });
      loadUsers();
    } catch (err) { alert(err.message); }
  };

  const handlePermanentDelete = async (id) => {
    if (!confirm('PERMANENTLY delete this user? This cannot be undone.')) return;
    try {
      await api.permanentDeleteUser(id);
      loadUsers();
    } catch (err) { alert(err.message); }
  };

  return (
    <div className="page-content">
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 20 }}>
        <h2 style={{ fontSize: 20, fontWeight: 600 }}>User Management</h2>
        {currentUser?.role === 'admin' && (
          <button className="btn btn-primary" onClick={() => setShowCreate(true)}>
            <Plus size={16} /> Add User
          </button>
        )}
      </div>

      <div className="card">
        <div className="table-container">
          <table className="data-table">
            <thead>
              <tr>
                <th>User</th>
                <th>Username</th>
                <th>Email</th>
                <th>Role</th>
                <th>Status</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {users.map(u => (
                <tr key={u.id}>
                  <td>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                      <div className="user-avatar">{u.full_name?.[0] || u.username[0]}</div>
                      {u.full_name || u.username}
                    </div>
                  </td>
                  <td style={{ fontFamily: 'var(--font-mono)', fontSize: 12 }}>{u.username}</td>
                  <td>{u.email || '—'}</td>
                  <td><span className={`status-badge status-${u.role === 'admin' ? 'posted' : u.role === 'project_manager' ? 'review' : u.role === 'lead_editor' ? 'scheduled' : u.role === 'social_media_manager' ? 'in_progress' : 'in_progress'}`}>{u.role.replace('_', ' ')}</span></td>
                  <td>{u.is_active ? <span style={{ color: 'var(--success)', fontSize: 12 }}>Active</span> : <span style={{ color: 'var(--danger)', fontSize: 12 }}>Inactive</span>}</td>
                  <td>
                    <div style={{ display: 'flex', gap: 4 }}>
                      <button className="btn btn-secondary btn-sm" onClick={() => setEditingUser({ id: u.id, full_name: u.full_name, email: u.email, role: u.role })} title="Edit user">
                        <Edit2 size={12} />
                      </button>
                      <button className="btn btn-secondary btn-sm" onClick={() => { setShowReset(u); setNewPassword(''); }} title="Reset password">
                        <Key size={12} />
                      </button>
                      {u.is_active ? (
                        <button className="btn btn-danger btn-sm" onClick={() => handleDeactivate(u.id)} title="Deactivate">
                          <UserX size={12} />
                        </button>
                      ) : (
                        <>
                          <button className="btn btn-sm" style={{ background: 'var(--success-bg)', color: 'var(--success)' }} onClick={() => handleReactivate(u.id)} title="Reactivate">
                            Activate
                          </button>
                          <button className="btn btn-danger btn-sm" onClick={() => handlePermanentDelete(u.id)} title="Permanently delete">
                            <Trash2 size={12} />
                          </button>
                        </>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Create User Modal */}
      {showCreate && (
        <div className="modal-overlay" onClick={() => setShowCreate(false)}>
          <div className="modal" onClick={e => e.stopPropagation()}>
            <h3 className="modal-title">Create New User</h3>
            <form onSubmit={handleCreate}>
              <div className="form-group">
                <label className="form-label">Full Name</label>
                <input className="form-input" value={newUser.full_name} onChange={e => setNewUser({ ...newUser, full_name: e.target.value })} required />
              </div>
              <div className="form-group">
                <label className="form-label">Username</label>
                <input className="form-input" value={newUser.username} onChange={e => setNewUser({ ...newUser, username: e.target.value })} required />
              </div>
              <div className="form-group">
                <label className="form-label">Email</label>
                <input className="form-input" type="email" value={newUser.email} onChange={e => setNewUser({ ...newUser, email: e.target.value })} />
              </div>
              <div className="form-group">
                <label className="form-label">Password</label>
                <input className="form-input" type="password" value={newUser.password} onChange={e => setNewUser({ ...newUser, password: e.target.value })} required />
              </div>
              <div className="form-group">
                <label className="form-label">Role</label>
                <select className="form-select" value={newUser.role} onChange={e => setNewUser({ ...newUser, role: e.target.value })}>
                  <option value="editor">Editor</option>
                  <option value="lead_editor">Lead Editor</option>
                  <option value="social_media_manager">Social Media Manager</option>
                  <option value="project_manager">Project Manager</option>
                  <option value="admin">Admin</option>
                </select>
              </div>
              <div className="modal-actions">
                <button type="button" className="btn btn-secondary" onClick={() => setShowCreate(false)}>Cancel</button>
                <button type="submit" className="btn btn-primary">Create User</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Reset Password Modal */}
      {showReset && (
        <div className="modal-overlay" onClick={() => setShowReset(null)}>
          <div className="modal" onClick={e => e.stopPropagation()}>
            <h3 className="modal-title">Reset Password for {showReset.username}</h3>
            <form onSubmit={handleReset}>
              <div className="form-group">
                <label className="form-label">New Password</label>
                <input className="form-input" type="password" value={newPassword} onChange={e => setNewPassword(e.target.value)} required />
              </div>
              <div className="modal-actions">
                <button type="button" className="btn btn-secondary" onClick={() => setShowReset(null)}>Cancel</button>
                <button type="submit" className="btn btn-primary">Reset Password</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Edit User Modal */}
      {editingUser && (
        <div className="modal-overlay" onClick={() => setEditingUser(null)}>
          <div className="modal" onClick={e => e.stopPropagation()}>
            <h3 className="modal-title">Edit User</h3>
            <form onSubmit={handleEditRole}>
              <div className="form-group">
                <label className="form-label">Full Name</label>
                <input className="form-input" value={editingUser.full_name || ''} onChange={e => setEditingUser({ ...editingUser, full_name: e.target.value })} />
              </div>
              <div className="form-group">
                <label className="form-label">Email</label>
                <input className="form-input" type="email" value={editingUser.email || ''} onChange={e => setEditingUser({ ...editingUser, email: e.target.value })} />
              </div>
              <div className="form-group">
                <label className="form-label">Role</label>
                <select className="form-select" value={editingUser.role} onChange={e => setEditingUser({ ...editingUser, role: e.target.value })}>
                  <option value="editor">Editor</option>
                  <option value="lead_editor">Lead Editor</option>
                  <option value="social_media_manager">Social Media Manager</option>
                  <option value="project_manager">Project Manager</option>
                  <option value="admin">Admin</option>
                </select>
              </div>
              <div className="modal-actions">
                <button type="button" className="btn btn-secondary" onClick={() => setEditingUser(null)}>Cancel</button>
                <button type="submit" className="btn btn-primary">Save Changes</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default UsersPage;
