import { useState } from 'react';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import Sidebar from './components/common/Sidebar';
import Topbar from './components/common/Topbar';
import LoginPage from './pages/LoginPage';
import DashboardPage from './pages/DashboardPage';
import ClientsPage from './pages/ClientsPage';
import ClientDetailPage from './pages/ClientDetailPage';
import CampaignDetailPage from './pages/CampaignDetailPage';
import UsersPage from './pages/UsersPage';
import TemplatesPage from './pages/TemplatesPage';
import HooksPage from './pages/HooksPage';
import KanbanPage from './pages/KanbanPage';
import AnalyticsPage from './pages/AnalyticsPage';
import SettingsPage from './pages/SettingsPage';
import PublishingPage from './pages/PublishingPage';
import TeamMemberTasksPage from './pages/TeamMemberTasksPage';

const PAGE_TITLES = {
  dashboard: 'Dashboard',
  clients: 'Client Portals',
  'client-detail': 'Client Portal',
  'campaign-detail': 'Campaign',
  templates: 'Template Registry',
  hooks: 'Hook Library',
  kanban: 'Kanban Board',
  analytics: 'Analytics',
  users: 'User Management',
  settings: 'Settings',
  publishing: 'Publishing Dashboard',
  'team-member': 'Team Member Tasks',
};

const AppContent = () => {
  const { user, loading } = useAuth();
  const [currentPage, setCurrentPage] = useState('dashboard');
  const [selectedClient, setSelectedClient] = useState(null);
  const [selectedCampaign, setSelectedCampaign] = useState(null);
  const [selectedMember, setSelectedMember] = useState(null);

  if (loading) {
    return (
      <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'var(--bg-primary)' }}>
        <div style={{ textAlign: 'center' }}>
          <div style={{ fontSize: 28, fontWeight: 700, background: 'linear-gradient(135deg, #7c5cfc, #a78bfa)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>Variant Flow</div>
          <p style={{ color: 'var(--text-tertiary)', marginTop: 8, fontSize: 13 }}>Loading...</p>
        </div>
      </div>
    );
  }

  if (!user) return <LoginPage />;

  const renderPage = () => {
    switch (currentPage) {
      case 'dashboard': return <DashboardPage />;
      case 'clients': return <ClientsPage onNavigate={setCurrentPage} setSelectedClient={setSelectedClient} />;
      case 'client-detail': return (
        <ClientDetailPage
          client={selectedClient}
          onBack={() => setCurrentPage('clients')}
          onOpenCampaign={(campaign) => { setSelectedCampaign(campaign); setCurrentPage('campaign-detail'); }}
        />
      );
      case 'campaign-detail': return (
        <CampaignDetailPage
          campaign={selectedCampaign}
          client={selectedClient}
          onBack={() => setCurrentPage('client-detail')}
        />
      );
      case 'templates': return <TemplatesPage />;
      case 'hooks': return <HooksPage />;
      case 'kanban': return <KanbanPage />;
      case 'analytics': return <AnalyticsPage />;
      case 'publishing': return <PublishingPage />;
      case 'users': return (user.role === 'admin' || user.role === 'project_manager') ? <UsersPage /> : <DashboardPage />;
      case 'settings': return <SettingsPage />;
      case 'team-member': return selectedMember ? (
        <TeamMemberTasksPage
          member={selectedMember}
          onBack={() => { setSelectedMember(null); setCurrentPage('dashboard'); }}
        />
      ) : <DashboardPage />;
      default: return <DashboardPage />;
    }
  };

  const pageTitle = currentPage === 'team-member' && selectedMember
    ? `${selectedMember.full_name || selectedMember.username}'s Tasks`
    : PAGE_TITLES[currentPage] || 'Variant Flow';

  return (
    <div className="app-layout">
      <Sidebar
        currentPage={currentPage}
        onNavigate={setCurrentPage}
        onSelectMember={setSelectedMember}
        selectedMemberId={selectedMember?.id}
      />
      <div className="main-content">
        <Topbar title={pageTitle} />
        {renderPage()}
      </div>
    </div>
  );
};

const App = () => (
  <AuthProvider>
    <AppContent />
  </AuthProvider>
);

export default App;
