import { useState, useEffect } from 'react';
import { Bell, X } from 'lucide-react';
import api from '../../services/api';

const Topbar = ({ title }) => {
  const [notifications, setNotifications] = useState([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [showPanel, setShowPanel] = useState(false);

  useEffect(() => {
    loadNotifications();
    const interval = setInterval(loadNotifications, 30000);
    return () => clearInterval(interval);
  }, []);

  const loadNotifications = async () => {
    try {
      const data = await api.getNotifications();
      setNotifications(data.notifications || []);
      setUnreadCount(data.unread_count || 0);
    } catch (err) { /* silent */ }
  };

  const markAllRead = async () => {
    try {
      await api.markAllRead();
      setUnreadCount(0);
      setNotifications(prev => prev.map(n => ({ ...n, is_read: true })));
    } catch (err) { /* silent */ }
  };

  return (
    <div className="topbar">
      <h2 className="topbar-title">{title}</h2>
      <div className="topbar-actions">
        <div style={{ position: 'relative' }}>
          <button className="btn btn-icon notification-badge" onClick={() => setShowPanel(!showPanel)}>
            <Bell size={18} />
            {unreadCount > 0 && <span className="notification-count">{unreadCount}</span>}
          </button>

          {showPanel && (
            <div style={{
              position: 'absolute', top: 40, right: 0, width: 320,
              background: 'var(--bg-secondary)', border: '1px solid var(--border)',
              borderRadius: 'var(--radius-lg)', boxShadow: 'var(--shadow-lg)',
              zIndex: 200, maxHeight: 400, overflow: 'hidden'
            }}>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '12px 16px', borderBottom: '1px solid var(--border)' }}>
                <span style={{ fontSize: 14, fontWeight: 600 }}>Notifications</span>
                <div style={{ display: 'flex', gap: 8 }}>
                  {unreadCount > 0 && (
                    <button className="btn btn-sm" onClick={markAllRead} style={{ fontSize: 11 }}>Mark all read</button>
                  )}
                  <button className="btn btn-icon btn-sm" onClick={() => setShowPanel(false)}><X size={14} /></button>
                </div>
              </div>
              <div style={{ maxHeight: 340, overflowY: 'auto' }}>
                {notifications.length === 0 ? (
                  <div style={{ padding: 24, textAlign: 'center', color: 'var(--text-tertiary)', fontSize: 13 }}>No notifications</div>
                ) : notifications.slice(0, 20).map(n => (
                  <div key={n.id} style={{
                    padding: '10px 16px', borderBottom: '1px solid var(--border)',
                    background: n.is_read ? 'transparent' : 'var(--accent-glow)',
                    cursor: 'pointer'
                  }} onClick={async () => {
                    if (!n.is_read) {
                      await api.markRead(n.id);
                      loadNotifications();
                    }
                  }}>
                    <div style={{ fontSize: 13, fontWeight: n.is_read ? 400 : 600 }}>{n.title}</div>
                    <div style={{ fontSize: 11, color: 'var(--text-tertiary)', marginTop: 2 }}>{n.message}</div>
                    <div style={{ fontSize: 10, color: 'var(--text-muted)', marginTop: 4 }}>
                      {new Date(n.created_at).toLocaleString()}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Topbar;
