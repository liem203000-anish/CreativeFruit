import { useState, useEffect } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import api from '../../services/api';
import {
  LayoutDashboard, Building2, FolderOpen, Layers, Anchor,
  FileVideo, BarChart3, Users, Bell, Settings, LogOut, Kanban, Send
} from 'lucide-react';

const navConfig = {
  admin: [
    { section: 'Main', items: [
      { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
      { id: 'clients', label: 'Clients', icon: Building2 },
      { id: 'kanban', label: 'Kanban Board', icon: Kanban },
    ]},
    { section: 'Content', items: [
      { id: 'templates', label: 'Templates', icon: Layers },
      { id: 'hooks', label: 'Hook Library', icon: Anchor },
    ]},
    { section: 'Publishing', items: [
      { id: 'publishing', label: 'Publishing', icon: Send },
    ]},
    { section: 'Analytics', items: [
      { id: 'analytics', label: 'Analytics', icon: BarChart3 },
    ]},
    { section: 'Admin', items: [
      { id: 'users', label: 'User Management', icon: Users },
      { id: 'settings', label: 'Settings', icon: Settings },
    ]},
  ],
  project_manager: [
    { section: 'Main', items: [
      { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
      { id: 'clients', label: 'Clients', icon: Building2 },
      { id: 'kanban', label: 'Kanban Board', icon: Kanban },
    ]},
    { section: 'Content', items: [
      { id: 'templates', label: 'Templates', icon: Layers },
      { id: 'hooks', label: 'Hook Library', icon: Anchor },
    ]},
    { section: 'Publishing', items: [
      { id: 'publishing', label: 'Publishing', icon: Send },
    ]},
    { section: 'Analytics', items: [
      { id: 'analytics', label: 'Analytics', icon: BarChart3 },
    ]},
    { section: 'Admin', items: [
      { id: 'users', label: 'User Management', icon: Users },
      { id: 'settings', label: 'Settings', icon: Settings },
    ]},
  ],
  lead_editor: [
    { section: 'Main', items: [
      { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
      { id: 'clients', label: 'Clients', icon: Building2 },
    ]},
    { section: 'Content', items: [
      { id: 'templates', label: 'Templates', icon: Layers },
      { id: 'hooks', label: 'Hook Library', icon: Anchor },
    ]},
    { section: 'Analytics', items: [
      { id: 'analytics', label: 'Analytics', icon: BarChart3 },
    ]},
  ],
  social_media_manager: [
    { section: 'Main', items: [
      { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
      { id: 'clients', label: 'Clients', icon: Building2 },
    ]},
    { section: 'Publishing', items: [
      { id: 'publishing', label: 'Publishing', icon: Send },
    ]},
    { section: 'Analytics', items: [
      { id: 'analytics', label: 'Analytics', icon: BarChart3 },
    ]},
  ],
  editor: [
    { section: 'Main', items: [
      { id: 'dashboard', label: 'My Tasks', icon: FileVideo },
    ]},
  ],
};

const Sidebar = ({ currentPage, onNavigate, onSelectMember, selectedMemberId }) => {
  const { user, logout } = useAuth();
  const sections = navConfig[user?.role] || navConfig.editor;
  const [teamMembers, setTeamMembers] = useState([]);
  const showTeam = user?.role === 'admin' || user?.role === 'project_manager';

  useEffect(() => {
    if (showTeam) {
      api.getUsers().then(data => setTeamMembers((data.users || []).filter(u => u.is_active && u.id !== user.id))).catch(() => {});
    }
  }, [showTeam]);

  return (
    <aside className="sidebar">
      <div className="sidebar-brand">
        <div style={{
          width: 32, height: 32, borderRadius: 8,
          background: 'linear-gradient(135deg, var(--accent-primary), #a78bfa)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontWeight: 700, fontSize: 14, color: 'white'
        }}>CF</div>
        <h1>Variant Flow</h1>
      </div>

      <nav className="sidebar-nav">
        {sections.map(section => (
          <div key={section.section} className="nav-section">
            <div className="nav-section-label">{section.section}</div>
            {section.items.map(item => {
              const Icon = item.icon;
              return (
                <button
                  key={item.id}
                  className={`nav-item ${currentPage === item.id && !selectedMemberId ? 'active' : ''}`}
                  onClick={() => { onNavigate(item.id); if (onSelectMember) onSelectMember(null); }}
                >
                  <Icon size={18} />
                  {item.label}
                </button>
              );
            })}
          </div>
        ))}

        {showTeam && teamMembers.length > 0 && (
          <div className="nav-section">
            <div className="nav-section-label">Team ({teamMembers.length})</div>
            {teamMembers.map(m => (
              <button
                key={m.id}
                className={`nav-item ${selectedMemberId === m.id ? 'active' : ''}`}
                onClick={() => { if (onSelectMember) onSelectMember(m); onNavigate('team-member'); }}
                style={{ gap: 8 }}
              >
                <div style={{
                  width: 22, height: 22, borderRadius: '50%', flexShrink: 0,
                  background: selectedMemberId === m.id ? 'var(--accent-primary)' : 'var(--bg-hover)',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  fontSize: 10, fontWeight: 600, color: selectedMemberId === m.id ? 'white' : 'var(--text-secondary)'
                }}>
                  {m.full_name?.[0] || m.username[0]}
                </div>
                <span style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                  {m.full_name || m.username}
                </span>
              </button>
            ))}
          </div>
        )}
      </nav>

      <div className="sidebar-footer">
        <div className="user-card">
          <div className="user-avatar">{user?.full_name?.[0] || user?.username?.[0] || '?'}</div>
          <div className="user-info">
            <div className="name">{user?.full_name || user?.username}</div>
            <div className="role">{user?.role?.replace('_', ' ')}</div>
          </div>
          <button onClick={logout} className="btn btn-icon" title="Sign out" style={{ color: 'var(--text-tertiary)' }}>
            <LogOut size={16} />
          </button>
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;
