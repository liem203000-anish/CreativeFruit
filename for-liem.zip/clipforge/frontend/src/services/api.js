const API_URL = '/api';

const getToken = () => localStorage.getItem('clipforge_token');

const headers = (isFormData = false) => {
  const h = {};
  if (!isFormData) h['Content-Type'] = 'application/json';
  const token = getToken();
  if (token) h['Authorization'] = `Bearer ${token}`;
  return h;
};

const handleResponse = async (res) => {
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Request failed');
  return data;
};

const api = {
  // Auth
  login: (username, password) =>
    fetch(`${API_URL}/auth/login`, { method: 'POST', headers: headers(), body: JSON.stringify({ username, password }) }).then(handleResponse),
  getMe: () =>
    fetch(`${API_URL}/auth/me`, { headers: headers() }).then(handleResponse),
  changePassword: (current_password, new_password) =>
    fetch(`${API_URL}/auth/change-password`, { method: 'PUT', headers: headers(), body: JSON.stringify({ current_password, new_password }) }).then(handleResponse),

  // Users
  getUsers: () =>
    fetch(`${API_URL}/users`, { headers: headers() }).then(handleResponse),
  createUser: (data) =>
    fetch(`${API_URL}/users`, { method: 'POST', headers: headers(), body: JSON.stringify(data) }).then(handleResponse),
  updateUser: (id, data) =>
    fetch(`${API_URL}/users/${id}`, { method: 'PUT', headers: headers(), body: JSON.stringify(data) }).then(handleResponse),
  resetPassword: (id, new_password) =>
    fetch(`${API_URL}/users/${id}/reset-password`, { method: 'PUT', headers: headers(), body: JSON.stringify({ new_password }) }).then(handleResponse),
  deleteUser: (id) =>
    fetch(`${API_URL}/users/${id}`, { method: 'DELETE', headers: headers() }).then(handleResponse),
  permanentDeleteUser: (id) =>
    fetch(`${API_URL}/users/${id}/permanent`, { method: 'DELETE', headers: headers() }).then(handleResponse),

  // Clients
  getClients: () =>
    fetch(`${API_URL}/clients`, { headers: headers() }).then(handleResponse),
  getClient: (id) =>
    fetch(`${API_URL}/clients/${id}`, { headers: headers() }).then(handleResponse),
  createClient: (formData) =>
    fetch(`${API_URL}/clients`, { method: 'POST', headers: { Authorization: `Bearer ${getToken()}` }, body: formData }).then(handleResponse),
  updateClient: (id, formData) =>
    fetch(`${API_URL}/clients/${id}`, { method: 'PUT', headers: { Authorization: `Bearer ${getToken()}` }, body: formData }).then(handleResponse),
  deleteClient: (id) =>
    fetch(`${API_URL}/clients/${id}`, { method: 'DELETE', headers: headers() }).then(handleResponse),
  addBurnerAccount: (clientId, data) =>
    fetch(`${API_URL}/clients/${clientId}/burner-accounts`, { method: 'POST', headers: headers(), body: JSON.stringify(data) }).then(handleResponse),

  // Folders
  createMonthlyFolder: (data) =>
    fetch(`${API_URL}/folders/monthly`, { method: 'POST', headers: headers(), body: JSON.stringify(data) }).then(handleResponse),
  deleteMonthlyFolder: (id) =>
    fetch(`${API_URL}/folders/monthly/${id}`, { method: 'DELETE', headers: headers() }).then(handleResponse),
  getCampaigns: (folderId) =>
    fetch(`${API_URL}/folders/monthly/${folderId}/campaigns`, { headers: headers() }).then(handleResponse),
  createCampaign: (data) =>
    fetch(`${API_URL}/folders/campaigns`, { method: 'POST', headers: headers(), body: JSON.stringify(data) }).then(handleResponse),
  updateCampaign: (id, data) =>
    fetch(`${API_URL}/folders/campaigns/${id}`, { method: 'PUT', headers: headers(), body: JSON.stringify(data) }).then(handleResponse),
  deleteCampaign: (id) =>
    fetch(`${API_URL}/folders/campaigns/${id}`, { method: 'DELETE', headers: headers() }).then(handleResponse),

  // Templates
  getTemplates: () =>
    fetch(`${API_URL}/templates`, { headers: headers() }).then(handleResponse),
  getTemplate: (id) =>
    fetch(`${API_URL}/templates/${id}`, { headers: headers() }).then(handleResponse),
  createTemplate: (formData) =>
    fetch(`${API_URL}/templates`, { method: 'POST', headers: { Authorization: `Bearer ${getToken()}` }, body: formData }).then(handleResponse),
  updateTemplate: (id, formData) =>
    fetch(`${API_URL}/templates/${id}`, { method: 'PUT', headers: { Authorization: `Bearer ${getToken()}` }, body: formData }).then(handleResponse),

  deleteTemplate: (id) =>
    fetch(`${API_URL}/templates/${id}`, { method: 'DELETE', headers: headers() }).then(handleResponse),

  // Hooks
  getHooks: () =>
    fetch(`${API_URL}/hooks`, { headers: headers() }).then(handleResponse),
  getHook: (id) =>
    fetch(`${API_URL}/hooks/${id}`, { headers: headers() }).then(handleResponse),
  createHook: (data) =>
    fetch(`${API_URL}/hooks`, { method: 'POST', headers: headers(), body: JSON.stringify(data) }).then(handleResponse),
  updateHook: (id, data) =>
    fetch(`${API_URL}/hooks/${id}`, { method: 'PUT', headers: headers(), body: JSON.stringify(data) }).then(handleResponse),

  deleteHook: (id) =>
    fetch(`${API_URL}/hooks/${id}`, { method: 'DELETE', headers: headers() }).then(handleResponse),

  // Deliverables
  getDeliverables: (campaignId) =>
    fetch(`${API_URL}/deliverables/campaign/${campaignId}`, { headers: headers() }).then(handleResponse),
  getMyTasks: () =>
    fetch(`${API_URL}/deliverables/my-tasks`, { headers: headers() }).then(handleResponse),
  getUserTasks: (userId) =>
    fetch(`${API_URL}/deliverables/user-tasks/${userId}`, { headers: headers() }).then(handleResponse),
  createDeliverableSet: (data) =>
    fetch(`${API_URL}/deliverables/create-set`, { method: 'POST', headers: headers(), body: JSON.stringify(data) }).then(handleResponse),
  updateDeliverable: (id, data) =>
    fetch(`${API_URL}/deliverables/${id}`, { method: 'PUT', headers: headers(), body: JSON.stringify(data) }).then(handleResponse),
  deleteDeliverable: (id) =>
    fetch(`${API_URL}/deliverables/${id}`, { method: 'DELETE', headers: headers() }).then(handleResponse),
  deleteDeliverableSet: (setId) =>
    fetch(`${API_URL}/deliverables/set/${setId}`, { method: 'DELETE', headers: headers() }).then(handleResponse),
  uploadVideo: (id, formData) =>
    fetch(`${API_URL}/deliverables/${id}/upload-video`, { method: 'POST', headers: { Authorization: `Bearer ${getToken()}` }, body: formData }).then(handleResponse),
  getKanban: (clientId) =>
    fetch(`${API_URL}/deliverables/kanban/${clientId}`, { headers: headers() }).then(handleResponse),

  // Reviews
  getComments: (deliverableId) =>
    fetch(`${API_URL}/reviews/deliverable/${deliverableId}`, { headers: headers() }).then(handleResponse),
  addComment: (data) =>
    fetch(`${API_URL}/reviews`, { method: 'POST', headers: headers(), body: JSON.stringify(data) }).then(handleResponse),
  resolveComment: (id) =>
    fetch(`${API_URL}/reviews/${id}/resolve`, { method: 'PUT', headers: headers() }).then(handleResponse),

  // AI
  generateHooks: (data) =>
    fetch(`${API_URL}/ai/generate-hooks`, { method: 'POST', headers: headers(), body: JSON.stringify(data) }).then(handleResponse),
  regenerateVariant: (deliverable_id) =>
    fetch(`${API_URL}/ai/regenerate-variant`, { method: 'POST', headers: headers(), body: JSON.stringify({ deliverable_id }) }).then(handleResponse),
  getVoices: () =>
    fetch(`${API_URL}/ai/voices`, { headers: headers() }).then(handleResponse),
  generateVoiceover: (data) =>
    fetch(`${API_URL}/ai/generate-voiceover`, { method: 'POST', headers: headers(), body: JSON.stringify(data) }).then(handleResponse),
  clearVoiceover: (deliverable_id) =>
    fetch(`${API_URL}/ai/clear-voiceover`, { method: 'POST', headers: headers(), body: JSON.stringify({ deliverable_id }) }).then(handleResponse),

  // Publishing
  getPublishConfig: (deliverableId) =>
    fetch(`${API_URL}/publishing/config/${deliverableId}`, { headers: headers() }).then(handleResponse),
  savePublishConfig: (deliverableId, config) =>
    fetch(`${API_URL}/publishing/config/${deliverableId}`, { method: 'POST', headers: headers(), body: JSON.stringify(config) }).then(handleResponse),
  publishToplatform: (deliverableId, data) =>
    fetch(`${API_URL}/publishing/publish/${deliverableId}`, { method: 'POST', headers: headers(), body: JSON.stringify(data) }).then(handleResponse),
  getPublishHistory: (deliverableId) =>
    fetch(`${API_URL}/publishing/history/${deliverableId}`, { headers: headers() }).then(handleResponse),

  // Analytics
  getTemplateAnalytics: () =>
    fetch(`${API_URL}/analytics/templates`, { headers: headers() }).then(handleResponse),
  getVariantAnalytics: (templateId) =>
    fetch(`${API_URL}/analytics/templates/${templateId}/variants`, { headers: headers() }).then(handleResponse),
  getHookAnalytics: () =>
    fetch(`${API_URL}/analytics/hooks`, { headers: headers() }).then(handleResponse),
  getAccountAnalytics: () =>
    fetch(`${API_URL}/analytics/accounts`, { headers: headers() }).then(handleResponse),
  getPlatformAnalytics: () =>
    fetch(`${API_URL}/analytics/platform`, { headers: headers() }).then(handleResponse),
  getOverview: () =>
    fetch(`${API_URL}/analytics/overview`, { headers: headers() }).then(handleResponse),

  // Notifications
  getNotifications: () =>
    fetch(`${API_URL}/notifications`, { headers: headers() }).then(handleResponse),
  markRead: (id) =>
    fetch(`${API_URL}/notifications/${id}/read`, { method: 'PUT', headers: headers() }).then(handleResponse),
  markAllRead: () =>
    fetch(`${API_URL}/notifications/read-all`, { method: 'PUT', headers: headers() }).then(handleResponse),
};

export default api;
